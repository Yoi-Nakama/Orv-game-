// ORV Game - Pathfinding
// Lightweight grid A* pathfinding for enemies and NPCs

const Pathfinding = (function() {
    const TILE = GameConfig.world.tileSize || 40;
    let grid = null;
    let gridW = 0, gridH = 0;

    function setGrid(passableGrid, width, height) {
        grid = passableGrid;
        gridW = width;
        gridH = height;
    }

    function worldToGrid(wx, wy) {
        return { gx: Math.floor(wx / TILE), gy: Math.floor(wy / TILE) };
    }

    function gridToWorld(gx, gy) {
        return { wx: gx * TILE + TILE/2, wy: gy * TILE + TILE/2 };
    }

    function isPassable(gx, gy) {
        if (!grid) return true;
        if (gx < 0 || gy < 0 || gx >= gridW || gy >= gridH) return false;
        return grid[gy * gridW + gx] !== 0;
    }

    function heuristic(ax, ay, bx, by) {
        return Math.abs(ax - bx) + Math.abs(ay - by);
    }

    function findPath(startWx, startWy, endWx, endWy, maxSteps) {
        maxSteps = maxSteps || 100;
        const start = worldToGrid(startWx, startWy);
        const end = worldToGrid(endWx, endWy);

        if (!isPassable(end.gx, end.gy)) return null;
        if (start.gx === end.gx && start.gy === end.gy) return [];

        const open = [];
        const closed = new Set();
        const cameFrom = {};
        const gScore = {};
        const fScore = {};

        const key = (x, y) => `${x},${y}`;
        const sk = key(start.gx, start.gy);
        gScore[sk] = 0;
        fScore[sk] = heuristic(start.gx, start.gy, end.gx, end.gy);
        open.push({ gx: start.gx, gy: start.gy, f: fScore[sk] });

        let steps = 0;
        while (open.length > 0 && steps < maxSteps) {
            steps++;
            // Pop node with lowest f
            open.sort((a, b) => a.f - b.f);
            const current = open.shift();
            const ck = key(current.gx, current.gy);

            if (current.gx === end.gx && current.gy === end.gy) {
                return reconstructPath(cameFrom, current, start, end);
            }

            closed.add(ck);

            // Neighbors (4-directional)
            const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
            for (const [dx, dy] of dirs) {
                const nx = current.gx + dx;
                const ny = current.gy + dy;
                const nk = key(nx, ny);
                if (closed.has(nk) || !isPassable(nx, ny)) continue;
                const tentG = (gScore[ck] || 0) + 1;
                if (tentG < (gScore[nk] || Infinity)) {
                    cameFrom[nk] = { gx: current.gx, gy: current.gy };
                    gScore[nk] = tentG;
                    fScore[nk] = tentG + heuristic(nx, ny, end.gx, end.gy);
                    if (!open.find(o => o.gx === nx && o.gy === ny)) {
                        open.push({ gx: nx, gy: ny, f: fScore[nk] });
                    }
                }
            }
        }
        return null; // No path
    }

    function reconstructPath(cameFrom, current, start, end) {
        const path = [];
        let cur = { gx: current.gx, gy: current.gy };
        while (cur) {
            const wp = gridToWorld(cur.gx, cur.gy);
            path.unshift(wp);
            const k = `${cur.gx},${cur.gy}`;
            cur = cameFrom[k] || null;
        }
        return path;
    }

    // Smooth path: follow path points
    function followPath(entity, path, speed, dt) {
        if (!path || path.length === 0) return true; // Done
        const next = path[0];
        const dx = next.wx - (entity.x + entity.width/2);
        const dy = next.wy - (entity.y + entity.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 10) {
            path.shift();
            return path.length === 0;
        }
        entity.vx = (dx/dist) * speed;
        entity.vy = (dy/dist) * speed;
        entity.facing = dx > 0 ? 1 : -1;
        return false;
    }

    return { setGrid, findPath, followPath, worldToGrid, gridToWorld, isPassable };
})();
