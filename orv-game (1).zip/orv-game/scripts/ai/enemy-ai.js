// ORV Game - Enemy AI
// State-machine based enemy AI: patrol, chase, attack, flee

const EnemyAI = (function() {
    const STATES = { IDLE: 'idle', PATROL: 'patrol', CHASE: 'chase', ATTACK: 'attack', FLEE: 'flee', DEAD: 'dead' };
    const DETECTION_RANGE = 180;
    const ATTACK_RANGE = 55;
    const LOSE_TARGET_RANGE = 350;
    const PATROL_PAUSE = 1.5;

    function createEnemy(defId, x, y, overrides) {
        const def = EnemiesData.getEnemy(defId);
        if (!def) return null;
        const stats = StatsSystem.buildEnemyStats(def);
        const enemy = {
            id: defId + '_' + Date.now() + '_' + Math.floor(Math.random()*1000),
            defId,
            type: defId,
            name: def.name,
            x, y,
            width: def.width || 40,
            height: def.height || 48,
            vx: 0, vy: 0,
            stats,
            level: def.level || 1,
            state: STATES.PATROL,
            target: null,
            spawnX: x, spawnY: y,
            patrolPoints: generatePatrolPoints(x, y, def.patrolRange || 80),
            patrolIndex: 0,
            patrolTimer: 0,
            attackCooldown: 0,
            attackWarmup: 0,
            aggroRange: def.aggroRange || DETECTION_RANGE,
            attackRange: def.attackRange || ATTACK_RANGE,
            attackDamage: def.attackDamage || def.stats?.ATK || 15,
            attackSpeed: def.attackSpeed || 1.5,
            moveSpeed: def.moveSpeed || 100,
            alive: true,
            expReward: def.expReward || 20,
            drops: def.drops || [],
            immunities: def.immunities || [],
            resistances: def.resistances || {},
            weaknesses: def.weaknesses || {},
            facing: 1,
            hitFlash: 0,
            isBoss: false,
            animator: AnimationSystem.createAnimator('enemy_default', 'idle'),
            statusEffects: [],
            buffs: [],
            alertLevel: 0, // 0=calm, 1=suspicious, 2=hostile
            aiType: def.aiType || 'standard',
        };
        // Override with passed props
        if (overrides) Object.assign(enemy, overrides);
        return enemy;
    }

    function generatePatrolPoints(cx, cy, range) {
        const count = 3 + Math.floor(Math.random() * 3);
        const points = [];
        for (let i = 0; i < count; i++) {
            points.push({
                x: cx + (Math.random() - 0.5) * range * 2,
                y: cy + (Math.random() - 0.5) * range * 2
            });
        }
        return points;
    }

    function update(enemy, dt, player, allEnemies) {
        if (!enemy.alive) { updateDead(enemy, dt); return; }

        // Hit flash timer
        if (enemy.hitFlash > 0) enemy.hitFlash -= dt;

        // Update cooldowns
        if (enemy.attackCooldown > 0) enemy.attackCooldown -= dt;

        // Update status effects
        CombatSystem.updateStatuses(enemy, dt);
        CombatSystem.updateBuffs(enemy, dt);

        // Update animation
        AnimationSystem.update(enemy.animator, dt);

        // Check if stunned/frozen
        if (hasStatusEffect(enemy, 'stun') || hasStatusEffect(enemy, 'freeze')) {
            AnimationSystem.play(enemy.animator, 'idle');
            enemy.vx = 0; enemy.vy = 0;
            return;
        }

        // State machine
        switch (enemy.state) {
            case STATES.IDLE: updateIdle(enemy, dt, player); break;
            case STATES.PATROL: updatePatrol(enemy, dt, player); break;
            case STATES.CHASE: updateChase(enemy, dt, player); break;
            case STATES.ATTACK: updateAttack(enemy, dt, player); break;
            case STATES.FLEE: updateFlee(enemy, dt, player); break;
        }

        // Move
        enemy.x += enemy.vx * dt;
        enemy.y += enemy.vy * dt;
        enemy.vx *= 0.75;
        enemy.vy *= 0.75;
    }

    function updateIdle(enemy, dt, player) {
        enemy.patrolTimer += dt;
        if (enemy.patrolTimer >= PATROL_PAUSE) {
            enemy.state = STATES.PATROL;
            enemy.patrolTimer = 0;
        }
        // Check aggro
        if (player && detectPlayer(enemy, player)) {
            aggro(enemy, player);
        }
        AnimationSystem.play(enemy.animator, 'idle');
    }

    function updatePatrol(enemy, dt, player) {
        // Check aggro
        if (player && detectPlayer(enemy, player)) {
            aggro(enemy, player);
            return;
        }
        const target = enemy.patrolPoints[enemy.patrolIndex];
        if (!target) { enemy.state = STATES.IDLE; return; }
        const dx = target.x - enemy.x;
        const dy = target.y - enemy.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 16) {
            enemy.patrolIndex = (enemy.patrolIndex + 1) % enemy.patrolPoints.length;
            enemy.state = STATES.IDLE;
            enemy.patrolTimer = 0;
        } else {
            const speed = enemy.moveSpeed * 0.6;
            enemy.vx = (dx / dist) * speed;
            enemy.vy = (dy / dist) * speed;
            enemy.facing = dx > 0 ? 1 : -1;
            enemy.animator.flipX = enemy.facing < 0;
            AnimationSystem.play(enemy.animator, 'walk');
        }
    }

    function updateChase(enemy, dt, player) {
        if (!player) { enemy.state = STATES.PATROL; return; }
        const dx = (player.x + player.width/2) - (enemy.x + enemy.width/2);
        const dy = (player.y + player.height/2) - (enemy.y + enemy.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);

        // Lose target?
        if (dist > LOSE_TARGET_RANGE) {
            enemy.target = null;
            enemy.state = STATES.PATROL;
            enemy.alertLevel = 0;
            return;
        }

        enemy.facing = dx > 0 ? 1 : -1;
        enemy.animator.flipX = enemy.facing < 0;

        if (dist <= enemy.attackRange) {
            enemy.vx = 0; enemy.vy = 0;
            enemy.state = STATES.ATTACK;
            AnimationSystem.play(enemy.animator, 'idle');
        } else {
            const speed = enemy.moveSpeed;
            enemy.vx = (dx / dist) * speed;
            enemy.vy = (dy / dist) * speed;
            AnimationSystem.play(enemy.animator, 'run');
        }
    }

    function updateAttack(enemy, dt, player) {
        if (!player) { enemy.state = STATES.PATROL; return; }
        const dx = (player.x + player.width/2) - (enemy.x + enemy.width/2);
        const dy = (player.y + player.height/2) - (enemy.y + enemy.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);

        enemy.facing = dx > 0 ? 1 : -1;
        enemy.animator.flipX = enemy.facing < 0;

        // Player moved out of range
        if (dist > enemy.attackRange * 1.3) {
            enemy.state = STATES.CHASE;
            return;
        }

        // Attack
        if (enemy.attackCooldown <= 0) {
            performAttack(enemy, player);
        }
        AnimationSystem.play(enemy.animator, 'idle');
    }

    function updateFlee(enemy, dt, player) {
        if (!player) { enemy.state = STATES.PATROL; return; }
        const dx = (player.x + player.width/2) - (enemy.x + enemy.width/2);
        const dy = (player.y + player.height/2) - (enemy.y + enemy.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist > LOSE_TARGET_RANGE) { enemy.state = STATES.PATROL; return; }
        const speed = enemy.moveSpeed * 1.2;
        enemy.vx = -(dx / dist) * speed;
        enemy.vy = -(dy / dist) * speed;
        AnimationSystem.play(enemy.animator, 'run');
    }

    function performAttack(enemy, player) {
        enemy.attackCooldown = enemy.attackSpeed;
        AnimationSystem.play(enemy.animator, 'attack', true);

        // Vary attack based on AI type
        let damage = enemy.attackDamage;
        switch(enemy.aiType) {
            case 'swarm':
                damage = Math.floor(damage * 0.6); // weaker but fast
                enemy.attackCooldown *= 0.5;
                break;
            case 'ranged':
                // Don't need to be in melee range
                break;
            case 'tank':
                damage = Math.floor(damage * 1.3);
                enemy.attackCooldown *= 1.5;
                break;
        }

        CombatSystem.applyDamage(player, damage, 'physical', enemy);
        enemy.vx += (player.x - enemy.x) * 0.3; // Lunge
    }

    function updateDead(enemy, dt) {
        if (enemy.animator) AnimationSystem.play(enemy.animator, 'death');
        enemy.deathTimer = (enemy.deathTimer || 0) + dt;
        // Fade out
        if (enemy.animator) enemy.animator.alpha = Math.max(0, 1 - enemy.deathTimer / 2);
    }

    function detectPlayer(enemy, player) {
        if (!player || !player.alive) return false;
        const dx = (player.x + player.width/2) - (enemy.x + enemy.width/2);
        const dy = (player.y + player.height/2) - (enemy.y + enemy.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist > enemy.aggroRange) return false;
        // Line of sight (simplified)
        return !PhysicsSystem.raycast(
            enemy.x + enemy.width/2, enemy.y + enemy.height/2,
            player.x + player.width/2, player.y + player.height/2
        ).hit;
    }

    function aggro(enemy, player) {
        enemy.target = player;
        enemy.state = STATES.CHASE;
        enemy.alertLevel = 2;
        EventSystem.emit(EventSystem.EVENTS.ENEMY_AGGRO, { enemy, player });
        if (!CombatSystem.isInCombat()) CombatSystem.setInCombat(true);
        // Alert nearby enemies
        // (handled by world system)
    }

    function hasStatusEffect(enemy, id) {
        return enemy.statusEffects && enemy.statusEffects.some(s => s.id === id);
    }

    function draw(ctx, enemy) {
        if (!enemy) return;
        if ((enemy.deathTimer || 0) > 2.0) return; // Fully faded

        ctx.save();
        ctx.globalAlpha = enemy.animator?.alpha ?? 1;

        // Hit flash
        if (enemy.hitFlash > 0) {
            ctx.filter = 'brightness(3) saturate(0)';
        }

        AnimationSystem.draw(ctx, enemy.animator, enemy.x, enemy.y, enemy.width, enemy.height);
        ctx.filter = 'none';

        // HP bar (show when damaged)
        if (enemy.alive && enemy.stats.HP < enemy.stats.maxHP) {
            const barW = enemy.width + 8;
            const barX = enemy.x - 4;
            const barY = enemy.y - 10;
            ctx.fillStyle = '#300';
            ctx.fillRect(barX, barY, barW, 5);
            const pct = StatsSystem.hpPercent(enemy.stats);
            ctx.fillStyle = pct > 0.5 ? '#0f0' : pct > 0.25 ? '#ff0' : '#f00';
            ctx.fillRect(barX, barY, barW * pct, 5);
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 1;
            ctx.strokeRect(barX, barY, barW, 5);
        }

        // Status icons
        if (enemy.alive && enemy.statusEffects && enemy.statusEffects.length > 0) {
            ctx.font = '11px sans-serif';
            enemy.statusEffects.forEach((s, i) => {
                const def = CombatSystem.getStatusDef(s.id);
                ctx.fillText(def.icon || '?', enemy.x + i * 12, enemy.y - 14);
            });
        }

        ctx.restore();
    }

    return { createEnemy, update, draw, STATES, aggro };
})();
