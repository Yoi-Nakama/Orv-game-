// Stub: functionality merged into core systems
