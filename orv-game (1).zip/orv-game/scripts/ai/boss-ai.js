// ORV Game - Boss AI
// Multi-phase boss state machine with telegraphed attacks, enrage, and special mechanics

const BossAI = (function() {
    const STATES = { INTRO: 'intro', IDLE: 'idle', APPROACH: 'approach', ATTACK: 'attack', SPECIAL: 'special', PHASE_TRANSITION: 'phase_transition', ENRAGE: 'enrage', DEAD: 'dead' };

    function createBoss(bossId, x, y) {
        const def = BossesData.getBoss(bossId);
        if (!def) { console.error('[BossAI] Unknown boss:', bossId); return null; }

        const stats = {
            HP: def.stats.HP, maxHP: def.stats.HP,
            MP: def.stats.MP || 500, maxMP: def.stats.MP || 500,
            SP: 100, maxSP: 100,
            ATK: def.stats.ATK, DEF: def.stats.DEF,
            MATK: def.stats.MATK || def.stats.ATK,
            MDEF: def.stats.MDEF || def.stats.DEF,
            SPEED: def.stats.SPEED || 120,
            CRIT: def.stats.CRIT || 15,
            CRITDMG: 180, EVASION: def.stats.EVASION || 5,
            ACCURACY: 90
        };

        return {
            id: bossId,
            type: bossId,
            name: def.name,
            title: def.title,
            x, y,
            width: def.width || 80,
            height: def.height || 100,
            vx: 0, vy: 0,
            stats,
            level: def.level || 50,
            phase: 1,
            maxPhase: def.phases ? def.phases.length : 2,
            state: STATES.INTRO,
            target: null,
            alive: true,
            isBoss: true,
            spawnX: x, spawnY: y,
            introTimer: 3.0,
            attackCooldown: 0,
            specialCooldown: 0,
            specialIndex: 0,
            moveSpeed: def.stats.SPEED || 120,
            enraged: false,
            enrageThreshold: def.enrageThreshold || 0.3,
            resistances: def.resistances || {},
            immunities: def.immunities || [],
            drops: def.drops || [],
            expReward: def.expReward || 500,
            animator: AnimationSystem.createAnimator(bossId, 'idle'),
            statusEffects: [],
            buffs: [],
            hitFlash: 0,
            deathTimer: 0,
            facing: 1,
            phaseTransitionTimer: 0,
            attackPattern: def.attackPattern || 'melee',
            specialAttacks: def.specialAttacks || [],
            phaseHealthThresholds: def.phases ? def.phases.map(p => p.hpThreshold) : [0.5],
            weaknessRevealed: false,
        };
    }

    function update(boss, dt, player) {
        if (!boss.alive) { updateDead(boss, dt); return; }

        if (boss.hitFlash > 0) boss.hitFlash -= dt;
        if (boss.attackCooldown > 0) boss.attackCooldown -= dt;
        if (boss.specialCooldown > 0) boss.specialCooldown -= dt;

        CombatSystem.updateStatuses(boss, dt);
        CombatSystem.updateBuffs(boss, dt);
        AnimationSystem.update(boss.animator, dt);

        // Check phase transitions
        checkPhaseTransition(boss);

        switch (boss.state) {
            case STATES.INTRO: updateIntro(boss, dt); break;
            case STATES.IDLE: updateIdle(boss, dt, player); break;
            case STATES.APPROACH: updateApproach(boss, dt, player); break;
            case STATES.ATTACK: updateAttackState(boss, dt, player); break;
            case STATES.SPECIAL: updateSpecial(boss, dt, player); break;
            case STATES.PHASE_TRANSITION: updatePhaseTransition(boss, dt); break;
            case STATES.ENRAGE: updateEnrage(boss, dt, player); break;
        }

        boss.x += boss.vx * dt;
        boss.y += boss.vy * dt;
        boss.vx *= 0.7;
        boss.vy *= 0.7;

        updateBossHUD(boss);
    }

    function checkPhaseTransition(boss) {
        if (boss.state === STATES.PHASE_TRANSITION || boss.state === STATES.INTRO) return;
        const hpPct = boss.stats.HP / boss.stats.maxHP;
        const threshold = boss.phaseHealthThresholds[boss.phase - 1];
        if (threshold && hpPct <= threshold && boss.phase < boss.maxPhase) {
            triggerPhaseTransition(boss);
        }
        // Enrage check
        if (!boss.enraged && hpPct <= boss.enrageThreshold) {
            triggerEnrage(boss);
        }
    }

    function triggerPhaseTransition(boss) {
        boss.state = STATES.PHASE_TRANSITION;
        boss.phaseTransitionTimer = 3.0;
        boss.phase++;
        boss.vx = 0; boss.vy = 0;

        CameraSystem.shake(18, 1.5);
        ParticleSystem.emit('boss_phase', boss.x + boss.width/2, boss.y + boss.height/2);
        AudioSystem.playSFX('boss_hit');

        EventSystem.emit(EventSystem.EVENTS.BOSS_PHASE, { bossId: boss.id, phase: boss.phase });

        // Heal boss slightly on phase transition
        boss.stats.HP = Math.min(boss.stats.maxHP, boss.stats.HP + Math.floor(boss.stats.maxHP * 0.1));

        // Apply phase bonuses
        const def = BossesData.getBoss(boss.id);
        const phaseData = def?.phases?.[boss.phase - 1];
        if (phaseData) {
            if (phaseData.atkMultiplier) {
                CombatSystem.applyBuff(boss, { id: 'phase_power', name: 'Phase Power', atkMultiplier: phaseData.atkMultiplier, duration: 99999 });
            }
            EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
                text: phaseData.message || `${boss.name} enters Phase ${boss.phase}!`,
                type: 'boss_phase'
            });
        }

        AnimationSystem.play(boss.animator, 'phase', true);
    }

    function triggerEnrage(boss) {
        boss.enraged = true;
        boss.moveSpeed *= 1.4;
        CombatSystem.applyBuff(boss, { id: 'enrage', name: 'Enrage', atkMultiplier: 1.5, speedMultiplier: 1.4, duration: 99999 });
        CameraSystem.shake(12, 1.0);
        ParticleSystem.emit('boss_phase', boss.x + boss.width/2, boss.y + boss.height/2, { count: 30, color: ['#ff0000','#ff4400'] });
        EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, { text: `${boss.name} has been enraged!`, type: 'boss_enrage' });
        AnimationSystem.play(boss.animator, 'roar', true);
    }

    function updateIntro(boss, dt) {
        boss.introTimer -= dt;
        AnimationSystem.play(boss.animator, 'idle');
        boss.vx = 0; boss.vy = 0;
        if (boss.introTimer <= 0) {
            boss.state = STATES.APPROACH;
            AudioSystem.playMusic('boss');
        }
    }

    function updateIdle(boss, dt, player) {
        AnimationSystem.play(boss.animator, 'idle');
        if (player) boss.state = STATES.APPROACH;
    }

    function updateApproach(boss, dt, player) {
        if (!player) return;
        const dx = (player.x + player.width/2) - (boss.x + boss.width/2);
        const dy = (player.y + player.height/2) - (boss.y + boss.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);
        boss.facing = dx > 0 ? 1 : -1;
        boss.animator.flipX = boss.facing < 0;

        const attackDist = 90 + boss.width * 0.3;
        if (dist <= attackDist) {
            boss.state = STATES.ATTACK;
            boss.vx = 0; boss.vy = 0;
        } else {
            boss.vx = (dx / dist) * boss.moveSpeed;
            boss.vy = (dy / dist) * boss.moveSpeed;
            AnimationSystem.play(boss.animator, 'walk');
        }

        // Check special attack
        if (boss.specialCooldown <= 0 && boss.specialAttacks.length > 0) {
            boss.state = STATES.SPECIAL;
        }
    }

    function updateAttackState(boss, dt, player) {
        if (!player) return;
        const dx = (player.x + player.width/2) - (boss.x + boss.width/2);
        const dy = (player.y + player.height/2) - (boss.y + boss.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);
        boss.facing = dx > 0 ? 1 : -1;
        boss.animator.flipX = boss.facing < 0;

        if (dist > 120) { boss.state = STATES.APPROACH; return; }
        if (boss.specialCooldown <= 0 && boss.specialAttacks.length > 0) { boss.state = STATES.SPECIAL; return; }

        if (boss.attackCooldown <= 0) {
            doMeleeAttack(boss, player);
        }
        AnimationSystem.play(boss.animator, 'idle');
    }

    function doMeleeAttack(boss, player) {
        boss.attackCooldown = 1.0 / (boss.enraged ? 1.6 : 1.0);
        AnimationSystem.play(boss.animator, 'attack', true, () => {
            AnimationSystem.play(boss.animator, 'idle');
        });
        const damage = boss.stats.ATK + Math.floor(Math.random() * boss.stats.ATK * 0.3);
        CombatSystem.applyDamage(player, damage, 'physical', boss);
        // Knockback
        const dx = player.x - boss.x;
        const dy = player.y - boss.y;
        const d = Math.sqrt(dx*dx+dy*dy) || 1;
        player.vx = (dx/d) * 200;
        player.vy = (dy/d) * 200;
    }

    function updateSpecial(boss, dt, player) {
        if (!player) { boss.state = STATES.APPROACH; return; }
        const sa = boss.specialAttacks[boss.specialIndex % boss.specialAttacks.length];
        boss.specialIndex++;
        boss.specialCooldown = sa.cooldown || 8;
        executeSpecialAttack(boss, sa, player);
        boss.state = STATES.APPROACH;
    }

    function executeSpecialAttack(boss, sa, player) {
        AnimationSystem.play(boss.animator, 'attack', true);
        ParticleSystem.emit('boss_phase', boss.x + boss.width/2, boss.y + boss.height/2, { count: 15 });
        CameraSystem.shake(10, 0.5);

        switch (sa.type) {
            case 'aoe':
                // Area blast
                CombatSystem.applyDamage(player, sa.damage || boss.stats.ATK * 2, sa.damageType || 'physical', boss);
                ParticleSystem.emit('skill_fire', boss.x + boss.width/2, boss.y + boss.height/2, { spread: 80, count: 25 });
                break;
            case 'charge':
                // Rush at player
                const dx2 = player.x - boss.x, dy2 = player.y - boss.y;
                const d2 = Math.sqrt(dx2*dx2+dy2*dy2) || 1;
                boss.vx = (dx2/d2) * 500;
                boss.vy = (dy2/d2) * 500;
                setTimeout(() => { CombatSystem.applyDamage(player, sa.damage || boss.stats.ATK * 1.5, 'physical', boss); }, 400);
                break;
            case 'summon':
                // Spawn adds
                if (window.GameState?.world && sa.summons) {
                    sa.summons.forEach(summonId => {
                        const offset = (Math.random()-0.5)*120;
                        GameState.world.spawnEnemy(summonId, boss.x + offset, boss.y + offset);
                    });
                }
                EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, { text: `${boss.name} summons reinforcements!`, type: 'boss' });
                break;
            case 'debuff':
                CombatSystem.applyStatus(player, sa.status || 'curse', sa.duration || 5, boss);
                break;
            case 'heal_self':
                const healAmt = Math.floor(boss.stats.maxHP * 0.08);
                boss.stats.HP = Math.min(boss.stats.maxHP, boss.stats.HP + healAmt);
                ParticleSystem.emit('heal', boss.x + boss.width/2, boss.y + boss.height/2);
                break;
            case 'meteor':
                // Delayed meteor strike at player position
                const tx = player.x, ty = player.y;
                EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, { text: 'Dragon Meteor Strike!', type: 'boss' });
                setTimeout(() => {
                    CombatSystem.applyDamage(player, sa.damage || boss.stats.ATK * 3, 'magical', boss);
                    CameraSystem.shake(20, 1.0);
                    ParticleSystem.emit('skill_fire', tx + 20, ty + 20, { spread: 60, count: 40 });
                }, 1500);
                break;
            case 'soul_devour':
                // Demon King special - drains MP and deals damage
                if (player.stats) {
                    const mpDrain = Math.floor(player.stats.MP * 0.4);
                    player.stats.MP -= mpDrain;
                    CombatSystem.applyDamage(player, sa.damage || boss.stats.ATK * 1.8, 'true', boss);
                    boss.stats.HP = Math.min(boss.stats.maxHP, boss.stats.HP + mpDrain);
                }
                EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, { text: `${boss.name}: "Your soul energy belongs to me!"`, type: 'boss' });
                break;
        }
    }

    function updatePhaseTransition(boss, dt) {
        boss.phaseTransitionTimer -= dt;
        boss.vx = 0; boss.vy = 0;
        if (boss.phaseTransitionTimer <= 0) {
            boss.state = STATES.APPROACH;
        }
    }

    function updateEnrage(boss, dt, player) {
        // Enrage is handled as a buff, normal movement continues
        boss.state = STATES.APPROACH;
    }

    function updateDead(boss, dt) {
        boss.deathTimer += dt;
        if (boss.animator) {
            boss.animator.alpha = Math.max(0, 1 - boss.deathTimer / 3);
            AnimationSystem.play(boss.animator, 'death');
        }
    }

    function updateBossHUD(boss) {
        const hpBar = document.getElementById('boss-hp-fill');
        const hpText = document.getElementById('boss-hp-text');
        const nameEl = document.getElementById('boss-name');
        const phaseEl = document.getElementById('boss-phase');
        const bossHud = document.getElementById('boss-hp-bar');

        if (!bossHud) return;
        bossHud.style.display = boss.alive ? 'block' : 'none';
        if (!boss.alive) return;

        const pct = Math.max(0, boss.stats.HP / boss.stats.maxHP * 100);
        if (hpBar) hpBar.style.width = `${pct}%`;
        if (hpText) hpText.textContent = `${Math.floor(boss.stats.HP).toLocaleString()} / ${boss.stats.maxHP.toLocaleString()}`;
        if (nameEl) nameEl.textContent = `${boss.name}${boss.enraged ? ' [ENRAGED]' : ''}`;
        if (phaseEl) phaseEl.textContent = boss.maxPhase > 1 ? `Phase ${boss.phase}/${boss.maxPhase}` : '';
    }

    function hideBossHUD() {
        const bossHud = document.getElementById('boss-hp-bar');
        if (bossHud) bossHud.style.display = 'none';
    }

    function draw(ctx, boss) {
        if (!boss) return;
        if (boss.deathTimer > 3) return;

        ctx.save();
        ctx.globalAlpha = boss.animator?.alpha ?? 1;
        if (boss.hitFlash > 0) ctx.filter = 'brightness(3) saturate(0)';

        // Draw boss sprite (larger procedural)
        const bossColors = {
            king_of_trolls: '#886644', dragon_lord_fafnir: '#cc2200',
            demon_king_asmodeus: '#440033', secretive_plotter_avatar: '#222266',
            yoo_jonghyuk_corrupted: '#ff2222', outer_god_fragment: '#000011',
            default: '#661122'
        };
        const color = bossColors[boss.id] || bossColors.default;
        const glowColor = boss.enraged ? '#ff0000' : color;

        ctx.shadowBlur = 20 + Math.sin(Date.now()/400)*5;
        ctx.shadowColor = glowColor;

        // Body
        ctx.fillStyle = color;
        ctx.fillRect(boss.x + boss.width*0.1, boss.y + boss.height*0.3, boss.width*0.8, boss.height*0.6);
        // Head
        ctx.beginPath();
        ctx.arc(boss.x + boss.width*0.5, boss.y + boss.height*0.22, boss.width*0.28, 0, Math.PI*2);
        ctx.fill();
        // Eyes glow
        ctx.shadowBlur = 15;
        ctx.shadowColor = boss.enraged ? '#ff0000' : '#ffcc00';
        ctx.fillStyle = boss.enraged ? '#ff0000' : '#ffcc00';
        const ex = boss.facing > 0 ? boss.x + boss.width*0.55 : boss.x + boss.width*0.35;
        const ex2 = boss.facing > 0 ? boss.x + boss.width*0.68 : boss.x + boss.width*0.22;
        ctx.fillRect(ex, boss.y + boss.height*0.18, 8, 8);
        ctx.fillRect(ex2, boss.y + boss.height*0.18, 8, 8);
        ctx.shadowBlur = 0;
        ctx.filter = 'none';
        ctx.globalAlpha = 1;

        // Phase indicator rings
        for (let i = 0; i < boss.phase - 1; i++) {
            ctx.beginPath();
            ctx.arc(boss.x + boss.width/2, boss.y + boss.height/2, boss.width*0.5 + i*8 + Math.sin(Date.now()/500)*3, 0, Math.PI*2);
            ctx.strokeStyle = glowColor + '66';
            ctx.lineWidth = 2;
            ctx.stroke();
        }
        ctx.restore();

        // HP bar
        const barW = boss.width + 20;
        const barX = boss.x - 10;
        const barY = boss.y - 14;
        ctx.fillStyle = '#300';
        ctx.fillRect(barX, barY, barW, 7);
        const pct = StatsSystem.hpPercent(boss.stats);
        ctx.fillStyle = pct > 0.5 ? '#0f0' : pct > 0.25 ? '#ff8800' : '#ff0000';
        ctx.fillRect(barX, barY, barW * pct, 7);
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 1;
        ctx.strokeRect(barX, barY, barW, 7);
    }

    return { createBoss, update, draw, hideBossHUD, STATES };
})();
