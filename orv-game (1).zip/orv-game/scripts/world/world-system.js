// ORV Game - World System
// Manages the active map, entities, spawning, drops, zone transitions, and NPC placement

const WorldSystem = (function() {
    let currentMapId = null;
    let currentMapDef = null;
    let entities = [];      // enemies, items, npcs
    let dropItems = [];     // world-space loot
    let npcs = [];
    let spawnTimers = {};
    let zoneTransitions = [];
    let activeTriggers = [];

    function loadMap(mapId, playerSpawnOverride) {
        currentMapId = mapId;
        const def = MapsData.getMap(mapId);
        if (!def) { console.error('[WorldSystem] Unknown map:', mapId); return false; }
        currentMapDef = def;

        // Clear world
        entities = [];
        dropItems = [];
        npcs = [];
        spawnTimers = {};
        zoneTransitions = [];
        PhysicsSystem.clearStaticColliders();
        PhysicsSystem.clearTriggers();

        // Set camera bounds
        CameraSystem.setBounds(0, 0, def.width, def.height);

        // Load collision from zones
        if (def.zones) {
            def.zones.forEach(zone => {
                if (zone.walls) {
                    zone.walls.forEach(w => {
                        PhysicsSystem.addStaticCollider(w.x, w.y, w.w, w.h, 'wall');
                    });
                }
            });
        }

        // Load border walls
        const T = 20;
        PhysicsSystem.addStaticCollider(-T, -T, T, def.height + T*2, 'border');
        PhysicsSystem.addStaticCollider(def.width, -T, T, def.height + T*2, 'border');
        PhysicsSystem.addStaticCollider(-T, -T, def.width + T*2, T, 'border');
        PhysicsSystem.addStaticCollider(-T, def.height, def.width + T*2, T, 'border');

        // Load exits as triggers
        if (def.exits) {
            def.exits.forEach(exit => {
                const trigger = PhysicsSystem.addTrigger(
                    exit.x, exit.y, exit.width || 60, exit.height || 60,
                    (body) => {
                        if (body.owner && body.owner.isPlayer) {
                            triggerMapTransition(exit.targetMap || exit.target, exit.targetSpawn, exit.id);
                        }
                    },
                    null, 'exit_' + exit.id
                );
                zoneTransitions.push({ trigger, exit });
            });
        }

        // Load zone triggers
        if (def.zones) {
            def.zones.forEach(zone => {
                if (zone.trigger) {
                    PhysicsSystem.addTrigger(
                        zone.x, zone.y, zone.width || 100, zone.height || 100,
                        (body) => {
                            if (body.owner?.isPlayer) {
                                EventSystem.emit(EventSystem.EVENTS.ZONE_ENTER, { zoneId: zone.id, zoneName: zone.name });
                            }
                        },
                        null, zone.id
                    );
                }
            });
        }

        // Spawn initial enemies — support both formats
        const spawnList = def.enemySpawns || (def.spawns ? def.spawns.map(s => ({
            enemyId: s.enemy || s.enemyId,
            x: s.x || (s.zone ? getZoneCenter(def, s.zone).x : def.width / 2),
            y: s.y || (s.zone ? getZoneCenter(def, s.zone).y : def.height / 2),
            count: s.count || 1,
            radius: s.radius || 60,
            respawn: s.respawn || false,
            respawnTime: s.respawnTime || 30,
            id: s.enemy + '_spawn_' + Math.random()
        })) : []);

        function getZoneCenter(md, zoneId) {
            const z = (md.zones||[]).find(z=>z.id===zoneId);
            if (!z) return { x: md.width/2, y: md.height/2 };
            return { x:(z.x||0)+(z.w||z.width||100)/2, y:(z.y||0)+(z.h||z.height||100)/2 };
        }

        spawnList.forEach(spawn => {
            for (let i = 0; i < (spawn.count || 1); i++) {
                const ox = (Math.random()-0.5) * (spawn.radius || 60);
                const oy = (Math.random()-0.5) * (spawn.radius || 60);
                if (spawn.enemyId) spawnEnemy(spawn.enemyId, (spawn.x||100) + ox, (spawn.y||100) + oy);
            }
        });

        // Spawn NPCs
        if (def.npcs) {
            def.npcs.forEach(npcDef => {
                const npc = createNPC(npcDef);
                if (npc) npcs.push(npc);
            });
        }

        // Spawn items
        if (def.items) {
            def.items.forEach(item => {
                spawnDropItem(item.itemId, item.quantity || 1, item.x, item.y);
            });
        }

        EventSystem.emit(EventSystem.EVENTS.SCENE_LOADED, { mapId });
        return true;
    }

    function spawnEnemy(defId, x, y, overrides) {
        const enemy = EnemyAI.createEnemy(defId, x, y, overrides);
        if (!enemy) return null;
        // Add physics body
        enemy.physBody = PhysicsSystem.createBody({
            x, y, width: enemy.width, height: enemy.height,
            layer: PhysicsSystem.collisionLayers.ENEMY,
            mask: PhysicsSystem.collisionLayers.PLAYER | PhysicsSystem.collisionLayers.TERRAIN,
            owner: enemy, maxSpeed: enemy.moveSpeed * 1.5
        });
        entities.push(enemy);
        EventSystem.emit(EventSystem.EVENTS.ENEMY_SPAWN, { enemy });
        return enemy;
    }

    function spawnBoss(bossId, x, y) {
        const boss = BossAI.createBoss(bossId, x, y);
        if (!boss) return null;
        boss.physBody = PhysicsSystem.createBody({
            x, y, width: boss.width, height: boss.height,
            layer: PhysicsSystem.collisionLayers.ENEMY,
            mask: PhysicsSystem.collisionLayers.PLAYER | PhysicsSystem.collisionLayers.TERRAIN,
            owner: boss, maxSpeed: boss.moveSpeed * 2
        });
        entities.push(boss);
        EventSystem.emit(EventSystem.EVENTS.BOSS_START, { bossId, boss });
        BossAI.updateBossHUD && (document.getElementById('boss-hp-bar').style.display = 'block');
        return boss;
    }

    function createNPC(def) {
        const charDef = CharactersData.getCharacter(def.characterId);
        return {
            id: def.id || def.characterId,
            characterId: def.characterId,
            name: charDef?.name || def.name || 'NPC',
            x: def.x, y: def.y,
            width: 36, height: 48,
            vx: 0, vy: 0,
            dialogueTree: def.dialogueTree,
            shopId: def.shopId,
            questGiver: def.questGiver || [],
            isNPC: true,
            facing: def.facing || 1,
            animator: AnimationSystem.createAnimator('npc_default', 'idle'),
            interactRadius: def.interactRadius || 60,
            alive: true,
            stats: { HP: 1, maxHP: 1 }
        };
    }

    function spawnDropItem(itemId, quantity, x, y) {
        const def = ItemsData.getItem(itemId);
        if (!def) return;
        dropItems.push({
            id: 'drop_' + Date.now() + '_' + Math.random(),
            itemId,
            quantity,
            x: x + (Math.random()-0.5)*20,
            y: y + (Math.random()-0.5)*20,
            width: 24, height: 24,
            bobTimer: Math.random() * Math.PI * 2,
            glowPulse: 0,
            rarity: def.rarity || 'common',
            animator: AnimationSystem.createAnimator('item', 'idle')
        });
    }

    function update(dt, player) {
        // Update enemies
        const liveEnemies = entities.filter(e => e.alive || !e.isBoss);
        entities.forEach(e => {
            if (e.isBoss) {
                BossAI.update(e, dt, player);
            } else {
                EnemyAI.update(e, dt, player, liveEnemies.filter(le => le !== e && le.alive));
            }
            // Sync physics body
            if (e.physBody) {
                e.physBody.x = e.x;
                e.physBody.y = e.y;
                e.physBody.vx = e.vx;
                e.physBody.vy = e.vy;
            }
        });

        // Remove fully dead entities
        entities = entities.filter(e => {
            if (!e.alive && (e.deathTimer || 0) > (e.isBoss ? 3 : 2.5)) {
                if (e.physBody) PhysicsSystem.removeBody(e.physBody.id);
                return false;
            }
            return true;
        });

        // Update NPCs
        npcs.forEach(npc => {
            AnimationSystem.update(npc.animator, dt);
            // Idle bob
            npc.y += Math.sin(Date.now()/600 + npc.x) * 0.02;
        });

        // Update drop items
        dropItems.forEach(item => {
            item.bobTimer += dt * 2;
            item.glowPulse += dt * 3;
            // Check player pickup
            if (player && player.alive) {
                const dx = (player.x + player.width/2) - (item.x + item.width/2);
                const dy = (player.y + player.height/2) - (item.y + item.height/2);
                if (dx*dx + dy*dy < 36*36) {
                    collectItem(item, player);
                }
            }
        });
        dropItems = dropItems.filter(i => !i.collected);

        // Check NPC interactions
        if (player) checkNPCInteractions(player);

        // Spawn timer updates
        updateRespawnTimers(dt);

        // Check combat state
        const anyAlive = entities.some(e => e.alive && !e.isNPC);
        if (!anyAlive && CombatSystem.isInCombat()) {
            CombatSystem.setInCombat(false);
        }
    }

    function collectItem(dropItem, player) {
        dropItem.collected = true;
        InventorySystem.addItem(dropItem.itemId, dropItem.quantity);
        ParticleSystem.emit('item_pickup', dropItem.x + 12, dropItem.y + 12);
        AudioSystem.playSFX('pickup');
    }

    function checkNPCInteractions(player) {
        npcs.forEach(npc => {
            const dx = (player.x + player.width/2) - (npc.x + npc.width/2);
            const dy = (player.y + player.height/2) - (npc.y + npc.height/2);
            const dist = Math.sqrt(dx*dx + dy*dy);
            const inRange = dist < npc.interactRadius;
            if (inRange) {
                showInteractPrompt(npc.name);
            }
        });
    }

    function showInteractPrompt(name) {
        const el = document.getElementById('interact-prompt');
        if (el) {
            el.textContent = `[F] Talk to ${name}`;
            el.style.display = 'block';
            clearTimeout(el._hideTimer);
            el._hideTimer = setTimeout(() => { el.style.display = 'none'; }, 200);
        }
    }

    function interactWithNearest(player) {
        let nearest = null, minDist = 80;
        npcs.forEach(npc => {
            const dx = player.x - npc.x, dy = player.y - npc.y;
            const d = Math.sqrt(dx*dx + dy*dy);
            if (d < minDist) { minDist = d; nearest = npc; }
        });
        if (nearest && nearest.dialogueTree) {
            DialogueSystem.startDialogue(nearest.dialogueTree, nearest);
        }
        return nearest;
    }

    function updateRespawnTimers(dt) {
        if (!currentMapDef?.enemySpawns) return;
        currentMapDef.enemySpawns.forEach(spawn => {
            if (!spawn.respawn) return;
            if (!spawnTimers[spawn.id]) spawnTimers[spawn.id] = 0;
            const alive = entities.filter(e => e.defId === spawn.enemyId && e.alive).length;
            if (alive < (spawn.count || 1)) {
                spawnTimers[spawn.id] += dt;
                if (spawnTimers[spawn.id] > (spawn.respawnTime || 30)) {
                    spawnTimers[spawn.id] = 0;
                    spawnEnemy(spawn.enemyId, spawn.x + (Math.random()-0.5)*60, spawn.y + (Math.random()-0.5)*60);
                }
            }
        });
    }

    function triggerMapTransition(targetMapId, targetSpawn, exitId) {
        EventSystem.emit(EventSystem.EVENTS.SCENE_CHANGE, { targetMapId, targetSpawn, exitId });
    }

    function draw(ctx, camera) {
        if (!currentMapDef) return;
        // Draw floor
        drawFloor(ctx);
        // Draw drop items
        drawDropItems(ctx);
        // Draw NPCs
        npcs.forEach(npc => {
            if (!CameraSystem.isVisible(npc.x, npc.y, npc.width, npc.height)) return;
            AnimationSystem.draw(ctx, npc.animator, npc.x, npc.y, npc.width, npc.height);
            ctx.fillStyle = '#aaffaa';
            ctx.font = '10px Rajdhani';
            ctx.textAlign = 'center';
            ctx.fillText(npc.name, npc.x + npc.width/2, npc.y - 8);
            // Dialogue bubble
            ctx.fillStyle = '#fff';
            ctx.font = '14px sans-serif';
            ctx.fillText('💬', npc.x + npc.width - 8, npc.y - 4);
        });
        // Draw enemies and bosses
        entities.forEach(e => {
            if (!CameraSystem.isVisible(e.x, e.y, e.width, e.height)) return;
            if (e.isBoss) BossAI.draw(ctx, e);
            else EnemyAI.draw(ctx, e);
        });
    }

    function drawFloor(ctx) {
        const def = currentMapDef;
        const camX = CameraSystem.getX(), camY = CameraSystem.getY();
        const viewW = 800 / CameraSystem.getZoom();
        const viewH = 600 / CameraSystem.getZoom();
        const TILE = GameConfig.world.tileSize;

        const startX = Math.max(0, Math.floor(camX / TILE));
        const startY = Math.max(0, Math.floor(camY / TILE));
        const endX = Math.min(Math.ceil(def.width / TILE), Math.ceil((camX + viewW) / TILE) + 1);
        const endY = Math.min(Math.ceil(def.height / TILE), Math.ceil((camY + viewH) / TILE) + 1);

        // Tile patterns based on map type
        const tileColors = getTileColors(def.id);
        for (let ty = startY; ty < endY; ty++) {
            for (let tx = startX; tx < endX; tx++) {
                const wx = tx * TILE, wy = ty * TILE;
                const checker = (tx + ty) % 2;
                ctx.fillStyle = checker ? tileColors.a : tileColors.b;
                ctx.fillRect(wx, wy, TILE, TILE);
                // Grid lines
                ctx.strokeStyle = tileColors.line;
                ctx.lineWidth = 0.5;
                ctx.strokeRect(wx, wy, TILE, TILE);
            }
        }

        // Draw zone names
        if (def.zones) {
            ctx.font = 'italic 11px Rajdhani';
            ctx.fillStyle = 'rgba(255,255,255,0.15)';
            ctx.textAlign = 'left';
            def.zones.forEach(zone => {
                if (zone.x && zone.y) ctx.fillText(zone.name, zone.x + 5, zone.y + 20);
            });
        }
    }

    function getTileColors(mapId) {
        const palettes = {
            subway_line_2: { a: '#1a1a2a', b: '#151520', line: '#33334466' },
            seoul_streets: { a: '#2a2a20', b: '#222218', line: '#44443344' },
            han_river_bridge: { a: '#203040', b: '#1a2a38', line: '#33445566' },
            dragon_mountain: { a: '#2a1818', b: '#221214', line: '#554433aa' },
            demon_realm_gate: { a: '#1a0822', b: '#12041a', line: '#55225588' },
            constellation_realm: { a: '#0a0820', b: '#060618', line: '#2244aa44' },
        };
        return palettes[mapId] || palettes.seoul_streets;
    }

    function drawDropItems(ctx) {
        dropItems.forEach(item => {
            const def = ItemsData.getItem(item.itemId);
            if (!def) return;
            const bob = Math.sin(item.bobTimer) * 3;
            const glow = (Math.sin(item.glowPulse) + 1) / 2;
            const rarityColors = GameConfig.rarityColors || {};
            const color = rarityColors[item.rarity] || '#ffcc00';
            ctx.shadowBlur = 8 + glow * 8;
            ctx.shadowColor = color;
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(item.x + 12, item.y + 12 + bob, 8, 0, Math.PI*2);
            ctx.fill();
            ctx.shadowBlur = 0;
            // Item label
            ctx.font = '9px Rajdhani';
            ctx.fillStyle = color;
            ctx.textAlign = 'center';
            ctx.fillText(def.name.slice(0,10), item.x + 12, item.y + 28 + bob);
        });
    }

    function getEnemiesInRadius(cx, cy, radius) {
        return entities.filter(e => {
            if (!e.alive || e.isNPC) return false;
            const dx = (e.x + e.width/2) - cx;
            const dy = (e.y + e.height/2) - cy;
            return dx*dx + dy*dy <= radius*radius;
        });
    }

    function getEnemies() { return entities.filter(e => !e.isNPC); }
    function getNPCs() { return npcs; }
    function getNPC(id) { return npcs.find(n => n.id === id || n.characterId === id); }
    function getCurrentMap() { return currentMapDef; }
    function getCurrentMapId() { return currentMapId; }

    function serialize() {
        return { currentMapId };
    }

    function deserialize(data) {
        if (data?.currentMapId) loadMap(data.currentMapId);
    }

    return {
        loadMap, spawnEnemy, spawnBoss, spawnDropItem,
        update, draw, interactWithNearest,
        getEnemiesInRadius, getEnemies, getNPCs, getNPC,
        getCurrentMap, getCurrentMapId,
        serialize, deserialize
    };
})();
