// ORV Game - Minimap
// Renders a small overview map with player, enemies, NPCs, and exits

const Minimap = (function() {
    let canvas = null;
    let ctx = null;
    let visible = true;

    function init() {
        canvas = document.getElementById('minimap-canvas');
        if (!canvas) return;
        ctx = canvas.getContext('2d');
    }

    function draw(player, worldSystem) {
        if (!canvas || !ctx || !visible) return;
        const mapDef = worldSystem.getCurrentMap();
        if (!mapDef) return;

        const W = canvas.width, H = canvas.height;
        ctx.clearRect(0, 0, W, H);

        // Background
        ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
        ctx.fillRect(0, 0, W, H);
        ctx.strokeStyle = '#4a9eff44';
        ctx.lineWidth = 1;
        ctx.strokeRect(0, 0, W, H);

        const scaleX = W / mapDef.width;
        const scaleY = H / mapDef.height;

        // Draw zones
        if (mapDef.zones) {
            mapDef.zones.forEach(zone => {
                if (!zone.x) return;
                ctx.fillStyle = '#33445522';
                ctx.fillRect(zone.x * scaleX, zone.y * scaleY,
                    (zone.width || 200) * scaleX, (zone.height || 200) * scaleY);
            });
        }

        // Draw exits
        if (mapDef.exits) {
            ctx.fillStyle = '#00ff8866';
            mapDef.exits.forEach(exit => {
                ctx.fillRect(exit.x * scaleX, exit.y * scaleY,
                    Math.max(4, exit.width * scaleX), Math.max(4, exit.height * scaleY));
            });
        }

        // Draw enemies
        const enemies = worldSystem.getEnemies();
        enemies.forEach(e => {
            if (!e.alive) return;
            ctx.fillStyle = e.isBoss ? '#ff0000' : '#ff444488';
            ctx.fillRect(e.x * scaleX - 1.5, e.y * scaleY - 1.5, 3, 3);
        });

        // Draw NPCs
        const npcs = worldSystem.getNPCs();
        ctx.fillStyle = '#44ff8888';
        npcs.forEach(npc => {
            ctx.fillRect(npc.x * scaleX - 1.5, npc.y * scaleY - 1.5, 3, 3);
        });

        // Draw player
        if (player) {
            const px = (player.x + player.width/2) * scaleX;
            const py = (player.y + player.height/2) * scaleY;
            // Pulse
            const pulse = (Math.sin(Date.now()/300) + 1) / 2;
            ctx.shadowBlur = 4 + pulse * 4;
            ctx.shadowColor = '#4a9eff';
            ctx.fillStyle = '#4a9eff';
            ctx.beginPath();
            ctx.arc(px, py, 3, 0, Math.PI*2);
            ctx.fill();
            ctx.shadowBlur = 0;

            // Camera viewport rect
            const camW = (800 / CameraSystem.getZoom()) * scaleX;
            const camH = (600 / CameraSystem.getZoom()) * scaleY;
            ctx.strokeStyle = '#4a9eff33';
            ctx.lineWidth = 0.5;
            ctx.strokeRect(CameraSystem.getX() * scaleX, CameraSystem.getY() * scaleY, camW, camH);
        }

        // Border
        ctx.strokeStyle = '#4a9eff66';
        ctx.lineWidth = 1;
        ctx.strokeRect(0, 0, W, H);

        // Map name
        ctx.fillStyle = '#4a9eff88';
        ctx.font = '8px Rajdhani';
        ctx.textAlign = 'left';
        ctx.fillText(mapDef.name || '', 3, 9);
    }

    function toggle() {
        visible = !visible;
        if (canvas) canvas.style.opacity = visible ? '1' : '0';
    }

    function setVisible(v) { visible = v; }

    return { init, draw, toggle, setVisible };
})();
