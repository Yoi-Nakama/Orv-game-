// ORV Game - Combat System
// Real-time damage calculation, status effects, buffs, debuffs, combat flow

const CombatSystem = (function() {
    let inCombat = false;
    let combatTargets = [];
    let activeCombatants = [];

    // --- Damage Application ---
    function applyDamage(target, rawDamage, damageType, source) {
        if (!target || !target.stats || target.stats.HP <= 0) return 0;
        // Invincibility check
        if (hasBuff(target, 'invincible')) {
            ParticleSystem.emitText('IMMUNE', target.x + target.width/2, target.y - 10, '#aaddff', 14);
            return 0;
        }

        let damage = rawDamage;
        // Defense reduction
        if (damageType === 'physical') {
            damage = Math.max(1, damage - Math.floor(target.stats.DEF * 0.5));
        } else if (damageType === 'magical') {
            damage = Math.max(1, damage - Math.floor(target.stats.MDEF * 0.5));
        }
        // True damage bypasses defense
        // else damage is unchanged

        // Check evasion
        if (damageType !== 'true' && checkEvasion(target, source)) {
            ParticleSystem.emitText('MISS', target.x + target.width/2, target.y - 10, '#aaa', 14);
            EventSystem.emit(EventSystem.EVENTS.COMBAT_MISS, { target, source });
            return 0;
        }

        // Check crit
        let isCrit = false;
        const critChance = source?.stats?.CRIT || 5;
        if (Math.random() * 100 < critChance) {
            isCrit = true;
            const critMultiplier = (source?.stats?.CRITDMG || 150) / 100;
            damage = Math.floor(damage * critMultiplier);
        }

        // Resistance check
        const resist = target.resistances?.[damageType] || 0;
        damage = Math.floor(damage * (1 - resist / 100));

        // Fourth Wall passive absorption
        if (target.isPlayer) {
            const fw = getBuff(target, 'fourth_wall');
            if (fw) {
                const absorbed = Math.floor(damage * fw.damageAbsorb);
                damage -= absorbed;
                fw.absorbed = (fw.absorbed || 0) + absorbed;
            }
        }

        damage = Math.max(1, damage);

        // Apply damage
        target.stats.HP = Math.max(0, target.stats.HP - damage);

        // Visual feedback
        const color = isCrit ? '#ffcc00' : (damageType === 'magical' ? '#8888ff' : '#ff4444');
        const prefix = isCrit ? '💥 ' : '';
        ParticleSystem.emitText(prefix + damage, target.x + target.width/2, target.y - 8, color, isCrit ? 22 : 16);
        ParticleSystem.emit(isCrit ? 'hit_crit' : 'hit_normal', target.x + target.width/2, target.y + target.height/2);
        AudioSystem.playSFX(isCrit ? 'crit' : 'hit');

        EventSystem.emit(EventSystem.EVENTS.DAMAGE_DEALT, { target, source, damage, damageType, isCrit });
        EventSystem.emit(EventSystem.EVENTS.COMBAT_HIT, { target, source, damage, isCrit });

        // Check death
        if (target.stats.HP <= 0) handleDeath(target, source);

        // Player hurt feedback
        if (target.isPlayer) {
            EventSystem.emit(EventSystem.EVENTS.PLAYER_HURT, { damage, isCrit });
            CameraSystem.shake(isCrit ? 8 : 4, 0.25);
            updatePlayerHUD();
        }

        return damage;
    }

    function checkEvasion(target, source) {
        const evasion = target.stats?.EVASION || 0;
        const accuracy = source?.stats?.ACCURACY || 80;
        const hitChance = Math.max(5, Math.min(95, accuracy - evasion));
        return Math.random() * 100 > hitChance;
    }

    // --- Healing ---
    function applyHeal(target, amount, source) {
        if (!target || !target.stats) return 0;
        const oldHP = target.stats.HP;
        target.stats.HP = Math.min(target.stats.maxHP, target.stats.HP + amount);
        const healed = target.stats.HP - oldHP;
        ParticleSystem.emitText(`+${healed}`, target.x + target.width/2, target.y - 8, '#00ff88', 16);
        ParticleSystem.emit('heal', target.x + target.width/2, target.y + target.height/2);
        EventSystem.emit(EventSystem.EVENTS.HEAL_APPLIED, { target, amount: healed, source });
        if (target.isPlayer) updatePlayerHUD();
        return healed;
    }

    // --- Status Effects ---
    function applyStatus(target, statusId, duration, source) {
        if (!target.statusEffects) target.statusEffects = [];
        // Immunity check
        if (target.immunities && target.immunities.includes(statusId)) return;
        // Check if already has status (refresh or stack)
        const existing = target.statusEffects.find(s => s.id === statusId);
        if (existing) { existing.duration = Math.max(existing.duration, duration); return; }

        const def = getStatusDef(statusId);
        const effect = {
            id: statusId,
            name: def.name,
            icon: def.icon,
            duration,
            elapsed: 0,
            tickTimer: 0,
            tickInterval: def.tickInterval || 1,
            source
        };
        target.statusEffects.push(effect);

        // Apply immediate stat changes
        if (def.statMods) {
            Object.entries(def.statMods).forEach(([key, val]) => {
                StatsSystem.addMod(target.stats, key, val);
            });
            StatsSystem.compute(target.stats, target.level || 1);
        }

        EventSystem.emit(EventSystem.EVENTS.STATUS_APPLIED, { target, statusId, def });
        ParticleSystem.emitText(def.icon + ' ' + def.name, target.x + target.width/2, target.y - 20, def.color || '#ffcc00', 12);
    }

    function updateStatuses(entity, dt) {
        if (!entity.statusEffects) return;
        for (let i = entity.statusEffects.length - 1; i >= 0; i--) {
            const effect = entity.statusEffects[i];
            effect.elapsed += dt;
            effect.duration -= dt;
            // Tick effects
            effect.tickTimer += dt;
            if (effect.tickTimer >= effect.tickInterval) {
                effect.tickTimer -= effect.tickInterval;
                applyStatusTick(entity, effect);
            }
            if (effect.duration <= 0) {
                removeStatus(entity, i, effect);
            }
        }
    }

    function applyStatusTick(entity, effect) {
        const def = getStatusDef(effect.id);
        if (!def) return;
        if (def.damagePerTick) {
            const dmg = Math.floor(def.damagePerTick + (effect.source?.stats?.MATK || 0) * 0.1);
            entity.stats.HP = Math.max(0, entity.stats.HP - dmg);
            ParticleSystem.emitText(`-${dmg}`, entity.x + entity.width/2, entity.y - 6, def.color || '#ff8800', 12);
            if (entity.stats.HP <= 0) handleDeath(entity, effect.source);
        }
        if (def.healPerTick) {
            const heal = def.healPerTick;
            entity.stats.HP = Math.min(entity.stats.maxHP, entity.stats.HP + heal);
        }
    }

    function removeStatus(entity, index, effect) {
        const def = getStatusDef(effect.id);
        // Remove stat mods
        if (def && def.statMods) {
            Object.entries(def.statMods).forEach(([key, val]) => {
                StatsSystem.removeMod(entity.stats, key, val);
            });
            StatsSystem.compute(entity.stats, entity.level || 1);
        }
        entity.statusEffects.splice(index, 1);
        EventSystem.emit(EventSystem.EVENTS.STATUS_REMOVED, { entity, statusId: effect.id });
    }

    function getStatusDef(id) {
        const defs = {
            poison: { name: 'Poison', icon: '☠', color: '#88ff44', tickInterval: 1, damagePerTick: 5 },
            burn: { name: 'Burn', icon: '🔥', color: '#ff4400', tickInterval: 0.5, damagePerTick: 8 },
            freeze: { name: 'Freeze', icon: '❄', color: '#88aaff', statMods: { SPEED: -30, AGI: -5 } },
            shock: { name: 'Shock', icon: '⚡', color: '#ffffaa', tickInterval: 0.8, damagePerTick: 4, statMods: { AGI: -3 } },
            stun: { name: 'Stun', icon: '💫', color: '#ffff00', statMods: { SPEED: -100, AGI: -20 } },
            slow: { name: 'Slow', icon: '🐢', color: '#aaaaaa', statMods: { SPEED: -15, AGI: -3 } },
            haste: { name: 'Haste', icon: '⚡', color: '#ffff00', statMods: { SPEED: 20, AGI: 5 } },
            bleed: { name: 'Bleed', icon: '🩸', color: '#cc0000', tickInterval: 1.5, damagePerTick: 6 },
            curse: { name: 'Curse', icon: '💀', color: '#8800ff', statMods: { STR: -5, AGI: -5, END: -5 } },
            regen: { name: 'Regen', icon: '💚', color: '#00ff88', tickInterval: 1, healPerTick: 10 },
            shield: { name: 'Shield', icon: '🛡', color: '#aaddff', statMods: { DEF: 20, MDEF: 20 } },
            power_up: { name: 'Power Up', icon: '⬆', color: '#ffcc00', statMods: { STR: 10, ATK: 15 } },
            fourth_wall: { name: 'Fourth Wall', icon: '📖', color: '#4a9eff', damageAbsorb: 0.5 },
            omniscience: { name: 'Omniscience', icon: '👁', color: '#c8a951', statMods: { STR: 20, AGI: 20, INT: 30, PER: 20 } },
        };
        return defs[id] || { name: id, icon: '?', color: '#fff' };
    }

    // --- Buffs (beneficial, longer lasting) ---
    function applyBuff(target, buffDef) {
        if (!target.buffs) target.buffs = [];
        const existing = target.buffs.find(b => b.id === buffDef.id);
        if (existing) { existing.duration = Math.max(existing.duration, buffDef.duration || 10); return; }
        target.buffs.push({ ...buffDef, elapsed: 0 });
        // Apply stat multipliers
        if (buffDef.atkMultiplier) StatsSystem.addMultMod(target.stats, 'ATK', buffDef.atkMultiplier);
        if (buffDef.speedMultiplier) StatsSystem.addMultMod(target.stats, 'SPEED', buffDef.speedMultiplier);
        StatsSystem.compute(target.stats, target.level || 1);
    }

    function updateBuffs(entity, dt) {
        if (!entity.buffs) return;
        for (let i = entity.buffs.length - 1; i >= 0; i--) {
            const b = entity.buffs[i];
            b.elapsed += dt;
            b.duration -= dt;
            if (b.duration <= 0) {
                if (b.atkMultiplier) StatsSystem.removeMultMod(entity.stats, 'ATK', b.atkMultiplier);
                if (b.speedMultiplier) StatsSystem.removeMultMod(entity.stats, 'SPEED', b.speedMultiplier);
                entity.buffs.splice(i, 1);
                StatsSystem.compute(entity.stats, entity.level || 1);
            }
        }
    }

    function hasBuff(entity, buffId) {
        return entity.buffs && entity.buffs.some(b => b.id === buffId);
    }

    function getBuff(entity, buffId) {
        return entity.buffs && entity.buffs.find(b => b.id === buffId);
    }

    // --- Death Handling ---
    function handleDeath(entity, killer) {
        entity.stats.HP = 0;
        entity.alive = false;

        if (entity.isPlayer) {
            EventSystem.emit(EventSystem.EVENTS.PLAYER_DEATH, { killer });
            AudioSystem.playSFX('death');
            AudioSystem.fadeOutMusic(2000);
        } else if (entity.isBoss) {
            EventSystem.emit(EventSystem.EVENTS.BOSS_DEATH, { bossId: entity.id, killer });
            AudioSystem.playSFX('boss_hit');
            CameraSystem.shake(20, 1.5);
            // Drop loot
            if (entity.drops) {
                const drops = InventorySystem.generateDrops(entity);
                spawnDropsAtPosition(drops, entity.x, entity.y);
            }
            // Grant exp
            if (entity.expReward) {
                if (window.GameState?.player) GameState.player.gainExp(entity.expReward);
            }
            ConstellationSystem.reactToAction('boss_kill', entity.expReward || 100);
        } else {
            EventSystem.emit(EventSystem.EVENTS.ENEMY_DEATH, { enemy: entity, killer });
            // Drop loot
            if (entity.drops) {
                const drops = InventorySystem.generateDrops(entity);
                spawnDropsAtPosition(drops, entity.x, entity.y);
            }
            // Grant exp
            if (entity.expReward) {
                if (window.GameState?.player) GameState.player.gainExp(entity.expReward);
            }
        }
        ParticleSystem.emit('death_enemy', entity.x + entity.width/2, entity.y + entity.height/2);
    }

    function spawnDropsAtPosition(drops, x, y) {
        if (window.GameState?.world) {
            drops.forEach(drop => {
                GameState.world.spawnDropItem(drop.itemId, drop.quantity, x + (Math.random()-0.5)*40, y + (Math.random()-0.5)*20);
            });
        }
    }

    function updatePlayerHUD() {
        EventSystem.emit(EventSystem.EVENTS.HUD_UPDATE, { type: 'player' });
    }

    function setInCombat(val) {
        inCombat = val;
        if (val) EventSystem.emit(EventSystem.EVENTS.COMBAT_START, {});
        else EventSystem.emit(EventSystem.EVENTS.COMBAT_END, {});
    }

    function isInCombat() { return inCombat; }

    return {
        applyDamage, applyHeal,
        applyStatus, updateStatuses, removeStatus,
        applyBuff, updateBuffs, hasBuff, getBuff,
        handleDeath, setInCombat, isInCombat,
        getStatusDef
    };
})();
