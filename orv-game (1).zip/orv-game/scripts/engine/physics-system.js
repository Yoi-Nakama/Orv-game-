// ORV Game - Physics System
// 2D AABB collision detection, movement resolution, trigger zones

const PhysicsSystem = (function() {
    const bodies = new Map();
    let bodyIdCounter = 0;
    const collisionLayers = {
        PLAYER: 1,
        ENEMY: 2,
        NPC: 4,
        PROJECTILE: 8,
        TERRAIN: 16,
        TRIGGER: 32,
        ITEM: 64
    };

    // Collision mask definitions
    const collisionMasks = {
        PLAYER: collisionLayers.ENEMY | collisionLayers.TERRAIN | collisionLayers.TRIGGER | collisionLayers.ITEM | collisionLayers.NPC,
        ENEMY: collisionLayers.PLAYER | collisionLayers.TERRAIN,
        NPC: collisionLayers.PLAYER | collisionLayers.TERRAIN,
        PROJECTILE: collisionLayers.ENEMY | collisionLayers.TERRAIN,
        TERRAIN: 0,
        TRIGGER: collisionLayers.PLAYER,
        ITEM: collisionLayers.PLAYER
    };

    function createBody(opts) {
        const id = ++bodyIdCounter;
        const body = {
            id,
            x: opts.x || 0,
            y: opts.y || 0,
            vx: 0, vy: 0,
            width: opts.width || 32,
            height: opts.height || 32,
            layer: opts.layer || collisionLayers.PLAYER,
            mask: opts.mask !== undefined ? opts.mask : collisionMasks.PLAYER,
            solid: opts.solid !== false,
            trigger: opts.trigger || false,
            active: true,
            friction: opts.friction !== undefined ? opts.friction : 0.85,
            maxSpeed: opts.maxSpeed || 300,
            onCollide: opts.onCollide || null,
            onTrigger: opts.onTrigger || null,
            owner: opts.owner || null
        };
        bodies.set(id, body);
        return body;
    }

    function removeBody(id) {
        bodies.delete(id);
    }

    function getBody(id) {
        return bodies.get(id);
    }

    // AABB overlap test
    function overlaps(a, b) {
        return a.x < b.x + b.width &&
               a.x + a.width > b.x &&
               a.y < b.y + b.height &&
               a.y + a.height > b.y;
    }

    // Check if two layers can interact
    function canInteract(a, b) {
        return (a.mask & b.layer) !== 0;
    }

    // Resolve AABB collision (push out)
    function resolveCollision(dynamic, solid) {
        const overlapX = Math.min(dynamic.x + dynamic.width - solid.x, solid.x + solid.width - dynamic.x);
        const overlapY = Math.min(dynamic.y + dynamic.height - solid.y, solid.y + solid.height - dynamic.y);
        if (overlapX < overlapY) {
            if (dynamic.x < solid.x) dynamic.x -= overlapX;
            else dynamic.x += overlapX;
            dynamic.vx = 0;
        } else {
            if (dynamic.y < solid.y) dynamic.y -= overlapY;
            else dynamic.y += overlapY;
            dynamic.vy = 0;
        }
    }

    // Static colliders (walls, terrain tiles)
    const staticColliders = [];

    function addStaticCollider(x, y, w, h, tag) {
        staticColliders.push({ x, y, width: w, height: h, tag: tag || 'wall', layer: collisionLayers.TERRAIN });
    }

    function clearStaticColliders() {
        staticColliders.length = 0;
    }

    // Trigger zones
    const triggers = [];

    function addTrigger(x, y, w, h, onEnter, onExit, tag) {
        const t = { x, y, width: w, height: h, onEnter, onExit, tag: tag || 'trigger', active: true, entitiesInside: new Set() };
        triggers.push(t);
        return t;
    }

    function clearTriggers() {
        triggers.length = 0;
    }

    // Main update
    function update(dt) {
        bodies.forEach(body => {
            if (!body.active || body.layer === collisionLayers.TERRAIN) return;

            // Apply friction
            body.vx *= body.friction;
            body.vy *= body.friction;

            // Clamp velocity
            const speed = Math.sqrt(body.vx * body.vx + body.vy * body.vy);
            if (speed > body.maxSpeed) {
                body.vx = (body.vx / speed) * body.maxSpeed;
                body.vy = (body.vy / speed) * body.maxSpeed;
            }

            // Integrate position
            body.x += body.vx * dt;
            body.y += body.vy * dt;

            // Collide with static colliders
            if (body.solid) {
                for (const sc of staticColliders) {
                    if (overlaps(body, sc)) {
                        resolveCollision(body, sc);
                    }
                }
            }

            // Check triggers
            triggers.forEach(trigger => {
                if (!trigger.active) return;
                if (overlaps(body, trigger)) {
                    if (!trigger.entitiesInside.has(body.id)) {
                        trigger.entitiesInside.add(body.id);
                        if (trigger.onEnter) trigger.onEnter(body, trigger);
                    }
                } else {
                    if (trigger.entitiesInside.has(body.id)) {
                        trigger.entitiesInside.delete(body.id);
                        if (trigger.onExit) trigger.onExit(body, trigger);
                    }
                }
            });
        });

        // Dynamic vs dynamic collision
        const bodyArr = Array.from(bodies.values()).filter(b => b.active && b.solid && b.layer !== collisionLayers.TERRAIN);
        for (let i = 0; i < bodyArr.length; i++) {
            for (let j = i + 1; j < bodyArr.length; j++) {
                const a = bodyArr[i], b = bodyArr[j];
                if (!canInteract(a, b) && !canInteract(b, a)) continue;
                if (overlaps(a, b)) {
                    if (a.trigger || b.trigger) {
                        if (a.onTrigger) a.onTrigger(b);
                        if (b.onTrigger) b.onTrigger(a);
                    } else {
                        resolveCollision(a, b);
                    }
                    if (a.onCollide) a.onCollide(b);
                    if (b.onCollide) b.onCollide(a);
                }
            }
        }
    }

    // Raycast (simple, grid-based approximation)
    function raycast(x1, y1, x2, y2, steps) {
        steps = steps || 20;
        const dx = (x2 - x1) / steps;
        const dy = (y2 - y1) / steps;
        for (let i = 0; i < steps; i++) {
            const rx = x1 + dx * i;
            const ry = y1 + dy * i;
            for (const sc of staticColliders) {
                if (rx >= sc.x && rx <= sc.x + sc.width && ry >= sc.y && ry <= sc.y + sc.height) {
                    return { hit: true, x: rx, y: ry, collider: sc };
                }
            }
        }
        return { hit: false };
    }

    // Circle overlap
    function circleOverlap(x1, y1, r1, x2, y2, r2) {
        const dx = x2 - x1, dy = y2 - y1;
        return dx * dx + dy * dy < (r1 + r2) * (r1 + r2);
    }

    return {
        createBody, removeBody, getBody,
        addStaticCollider, clearStaticColliders,
        addTrigger, clearTriggers,
        update, raycast, overlaps, circleOverlap,
        collisionLayers
    };
})();
