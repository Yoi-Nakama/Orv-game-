// ORV Game - Particle System
// Pool-based particle engine for hit effects, skills, auras, weather

const ParticleSystem = (function() {
    const MAX_PARTICLES = 500;
    const pool = [];
    const active = [];
    let quality = 1.0; // 0=off, 0.5=low, 1=full

    // Pre-fill pool
    for (let i = 0; i < MAX_PARTICLES; i++) {
        pool.push(createBlankParticle());
    }

    function createBlankParticle() {
        return {
            active: false,
            x: 0, y: 0,
            vx: 0, vy: 0,
            size: 4, startSize: 4, endSize: 0,
            color: '#fff', endColor: null,
            alpha: 1, startAlpha: 1, endAlpha: 0,
            life: 0, maxLife: 1,
            rotation: 0, rotSpeed: 0,
            gravity: 0,
            type: 'circle', // circle, square, star, spark, text
            text: '',
            glow: false,
            blendMode: 'source-over'
        };
    }

    function getParticle() {
        if (pool.length > 0) return pool.pop();
        // Recycle oldest active
        if (active.length > 0) {
            const old = active.shift();
            Object.assign(old, createBlankParticle());
            return old;
        }
        return null;
    }

    function recycle(p) {
        p.active = false;
        pool.push(p);
    }

    // Emit particles from a preset
    function emit(preset, x, y, overrides) {
        if (quality === 0) return;
        const def = PRESETS[preset];
        if (!def) return;
        const count = Math.floor((def.count || 5) * quality);
        for (let i = 0; i < count; i++) {
            const p = getParticle();
            if (!p) return;
            const opts = Object.assign({}, def, overrides);
            p.active = true;
            p.x = x + (Math.random() - 0.5) * (opts.spread || 0);
            p.y = y + (Math.random() - 0.5) * (opts.spread || 0);
            const angle = (opts.angle !== undefined ? opts.angle : Math.random() * Math.PI * 2);
            const speed = opts.speed + (Math.random() - 0.5) * (opts.speedVariance || 0);
            p.vx = Math.cos(angle) * speed;
            p.vy = Math.sin(angle) * speed;
            p.size = opts.size || 4;
            p.startSize = p.size;
            p.endSize = opts.endSize !== undefined ? opts.endSize : 0;
            p.color = Array.isArray(opts.color) ? opts.color[Math.floor(Math.random() * opts.color.length)] : (opts.color || '#fff');
            p.endColor = opts.endColor || null;
            p.alpha = 1;
            p.startAlpha = 1;
            p.endAlpha = opts.endAlpha !== undefined ? opts.endAlpha : 0;
            p.life = 0;
            p.maxLife = opts.life + (Math.random() - 0.5) * (opts.lifeVariance || 0);
            p.gravity = opts.gravity || 0;
            p.rotation = Math.random() * Math.PI * 2;
            p.rotSpeed = (Math.random() - 0.5) * (opts.rotSpeed || 0);
            p.type = opts.type || 'circle';
            p.text = opts.text || '';
            p.glow = opts.glow || false;
            p.blendMode = opts.blendMode || 'source-over';
            active.push(p);
        }
    }

    function emitText(text, x, y, color, size) {
        const p = getParticle();
        if (!p) return;
        p.active = true;
        p.x = x; p.y = y;
        p.vx = (Math.random() - 0.5) * 20;
        p.vy = -60;
        p.gravity = 20;
        p.type = 'text';
        p.text = text;
        p.color = color || '#fff';
        p.size = size || 16;
        p.startSize = p.size;
        p.endSize = p.size * 0.7;
        p.alpha = 1; p.startAlpha = 1; p.endAlpha = 0;
        p.life = 0; p.maxLife = 1.2;
        active.push(p);
    }

    function update(dt) {
        for (let i = active.length - 1; i >= 0; i--) {
            const p = active[i];
            if (!p.active) { active.splice(i, 1); recycle(p); continue; }
            p.life += dt;
            if (p.life >= p.maxLife) { active.splice(i, 1); recycle(p); continue; }
            const t = p.life / p.maxLife;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.vy += p.gravity * dt;
            p.vx *= 0.98;
            p.vy *= 0.98;
            p.rotation += p.rotSpeed * dt;
            p.alpha = p.startAlpha + (p.endAlpha - p.startAlpha) * t;
            p.size = p.startSize + (p.endSize - p.startSize) * t;
        }
    }

    function draw(ctx) {
        ctx.save();
        active.forEach(p => {
            if (!p.active || p.alpha <= 0 || p.size <= 0) return;
            ctx.globalAlpha = Math.max(0, Math.min(1, p.alpha));
            ctx.globalCompositeOperation = p.blendMode;
            if (p.glow) {
                ctx.shadowBlur = p.size * 2;
                ctx.shadowColor = p.color;
            } else {
                ctx.shadowBlur = 0;
            }
            ctx.fillStyle = p.color;
            ctx.strokeStyle = p.color;
            if (p.type === 'text') {
                ctx.font = `bold ${Math.floor(p.size)}px Rajdhani, sans-serif`;
                ctx.textAlign = 'center';
                ctx.strokeStyle = 'rgba(0,0,0,0.8)';
                ctx.lineWidth = 3;
                ctx.strokeText(p.text, p.x, p.y);
                ctx.fillText(p.text, p.x, p.y);
            } else if (p.type === 'circle') {
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size / 2, 0, Math.PI * 2);
                ctx.fill();
            } else if (p.type === 'square') {
                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rotation);
                ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size);
                ctx.restore();
            } else if (p.type === 'spark') {
                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(Math.atan2(p.vy, p.vx));
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.lineTo(-p.size * 2, p.size * 0.3);
                ctx.lineTo(-p.size * 2, -p.size * 0.3);
                ctx.closePath();
                ctx.fill();
                ctx.restore();
            }
        });
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = 'source-over';
        ctx.shadowBlur = 0;
        ctx.restore();
    }

    function clear() {
        while (active.length > 0) {
            const p = active.pop();
            recycle(p);
        }
    }

    function setQuality(q) { quality = q; }
    function getActiveCount() { return active.length; }

    // --- Preset Library ---
    const PRESETS = {
        hit_normal: {
            count: 8, type: 'spark', color: ['#fff', '#ffcc00', '#ff9900'],
            speed: 80, speedVariance: 40, spread: 8, gravity: 100,
            size: 6, endSize: 2, life: 0.3, lifeVariance: 0.1,
            endAlpha: 0, glow: false
        },
        hit_crit: {
            count: 16, type: 'spark', color: ['#ffcc00', '#ff6600', '#fff'],
            speed: 130, speedVariance: 60, spread: 10, gravity: 80,
            size: 8, endSize: 2, life: 0.5, lifeVariance: 0.15,
            endAlpha: 0, glow: true, blendMode: 'lighter'
        },
        hit_dark: {
            count: 12, type: 'circle', color: ['#8800ff', '#4400aa', '#cc00ff'],
            speed: 60, speedVariance: 30, spread: 12, gravity: -20,
            size: 8, endSize: 0, life: 0.6, lifeVariance: 0.2,
            endAlpha: 0, glow: true
        },
        heal: {
            count: 10, type: 'circle', color: ['#00ff88', '#00cc66', '#88ffcc'],
            speed: 40, speedVariance: 20, spread: 16, gravity: -60,
            angle: -Math.PI / 2, size: 7, endSize: 3,
            life: 0.8, lifeVariance: 0.2, endAlpha: 0, glow: true
        },
        death_enemy: {
            count: 20, type: 'circle', color: ['#ff4444', '#ff0000', '#880000'],
            speed: 100, speedVariance: 50, spread: 20, gravity: 60,
            size: 10, endSize: 0, life: 0.8, lifeVariance: 0.3, endAlpha: 0
        },
        levelup: {
            count: 30, type: 'circle', color: ['#ffcc00', '#fff', '#ffffaa'],
            speed: 80, speedVariance: 40, spread: 30, gravity: -30,
            size: 8, endSize: 4, life: 1.2, lifeVariance: 0.4,
            endAlpha: 0, glow: true, blendMode: 'lighter'
        },
        skill_fire: {
            count: 20, type: 'circle', color: ['#ff4400', '#ff8800', '#ffcc00'],
            speed: 70, speedVariance: 30, spread: 0, gravity: -40,
            size: 12, endSize: 2, life: 0.6, lifeVariance: 0.2,
            endAlpha: 0, glow: true
        },
        skill_lightning: {
            count: 15, type: 'spark', color: ['#4499ff', '#88ccff', '#fff'],
            speed: 150, speedVariance: 80, spread: 5, gravity: 0,
            size: 5, endSize: 0, life: 0.2, lifeVariance: 0.1,
            endAlpha: 0, glow: true, blendMode: 'lighter'
        },
        fourth_wall: {
            count: 25, type: 'square', color: ['#4a9eff', '#2266cc', '#88bbff'],
            speed: 50, speedVariance: 30, spread: 40, gravity: 0,
            size: 10, endSize: 2, life: 1.0, lifeVariance: 0.3,
            endAlpha: 0, glow: true
        },
        aura_constellation: {
            count: 5, type: 'circle', color: ['#c8a951', '#ffe080', '#fff8e0'],
            speed: 20, speedVariance: 10, spread: 24, gravity: -10,
            size: 6, endSize: 2, life: 1.5, lifeVariance: 0.5,
            endAlpha: 0, glow: true
        },
        boss_phase: {
            count: 50, type: 'circle', color: ['#ff0000', '#ff4400', '#880000', '#fff'],
            speed: 120, speedVariance: 80, spread: 60, gravity: -20,
            size: 14, endSize: 0, life: 1.5, lifeVariance: 0.5,
            endAlpha: 0, glow: true, blendMode: 'lighter'
        },
        item_pickup: {
            count: 8, type: 'circle', color: ['#ffcc00', '#fff', '#ffee88'],
            speed: 30, speedVariance: 15, spread: 8, gravity: -20,
            size: 5, endSize: 2, life: 0.5, lifeVariance: 0.1,
            endAlpha: 0, glow: true
        },
        step_dust: {
            count: 2, type: 'circle', color: ['#888', '#aaa'],
            speed: 15, speedVariance: 8, spread: 4, gravity: -5,
            size: 4, endSize: 0, life: 0.3, lifeVariance: 0.1, endAlpha: 0
        }
    };

    return {
        emit, emitText, update, draw, clear,
        setQuality, getActiveCount, PRESETS
    };
})();
