// ORV Game - Audio System
// Web Audio API driven sound system with BGM, SFX, volume control

const AudioSystem = (function() {
    let audioCtx = null;
    let masterGain = null;
    let musicGain = null;
    let sfxGain = null;
    let currentMusic = null;
    let currentMusicKey = null;
    let initialized = false;
    let muted = false;

    const sfxBuffers = {};
    const settings = {
        masterVolume: 0.8,
        musicVolume: 0.6,
        sfxVolume: 0.9
    };

    function init() {
        if (initialized) return;
        try {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            audioCtx = new AC();
            masterGain = audioCtx.createGain();
            musicGain = audioCtx.createGain();
            sfxGain = audioCtx.createGain();
            musicGain.connect(masterGain);
            sfxGain.connect(masterGain);
            masterGain.connect(audioCtx.destination);
            setVolumes();
            initialized = true;
        } catch(e) {
            console.warn('[AudioSystem] Web Audio API not available:', e);
        }
    }

    function resume() {
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    }

    function setVolumes() {
        if (!initialized) return;
        masterGain.gain.value = muted ? 0 : settings.masterVolume;
        musicGain.gain.value = settings.musicVolume;
        sfxGain.gain.value = settings.sfxVolume;
    }

    function setMasterVolume(v) { settings.masterVolume = Math.max(0, Math.min(1, v)); setVolumes(); }
    function setMusicVolume(v) { settings.musicVolume = Math.max(0, Math.min(1, v)); setVolumes(); }
    function setSfxVolume(v) { settings.sfxVolume = Math.max(0, Math.min(1, v)); setVolumes(); }

    function mute() { muted = true; if (masterGain) masterGain.gain.value = 0; }
    function unmute() { muted = false; setVolumes(); }
    function toggleMute() { muted ? unmute() : mute(); }
    function isMuted() { return muted; }

    // --- Procedurally generate tones for SFX (no asset files needed) ---
    function createOscillatorBuffer(frequency, duration, type, volume) {
        if (!audioCtx) return null;
        const sampleRate = audioCtx.sampleRate;
        const length = Math.floor(sampleRate * duration);
        const buffer = audioCtx.createBuffer(1, length, sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < length; i++) {
            let t = i / sampleRate;
            let sample = 0;
            if (type === 'sine') sample = Math.sin(2 * Math.PI * frequency * t);
            else if (type === 'square') sample = Math.sin(2 * Math.PI * frequency * t) > 0 ? 1 : -1;
            else if (type === 'sawtooth') sample = 2 * (t * frequency - Math.floor(0.5 + t * frequency));
            else if (type === 'triangle') sample = Math.abs(2 * (t * frequency - Math.floor(0.5 + t * frequency))) * 2 - 1;
            // Envelope
            const attack = 0.01;
            const release = duration * 0.3;
            let env = 1;
            if (t < attack) env = t / attack;
            else if (t > duration - release) env = (duration - t) / release;
            data[i] = sample * env * (volume || 0.5);
        }
        return buffer;
    }

    // Procedural SFX library
    const SFX_DEFS = {
        click: () => createOscillatorBuffer(800, 0.05, 'sine', 0.3),
        confirm: () => createOscillatorBuffer(600, 0.1, 'sine', 0.4),
        cancel: () => createOscillatorBuffer(300, 0.08, 'sine', 0.3),
        hit: () => createOscillatorBuffer(150, 0.12, 'square', 0.5),
        crit: () => createOscillatorBuffer(800, 0.15, 'sawtooth', 0.6),
        miss: () => createOscillatorBuffer(200, 0.08, 'triangle', 0.2),
        levelup: () => createOscillatorBuffer(880, 0.5, 'sine', 0.6),
        pickup: () => createOscillatorBuffer(1000, 0.08, 'sine', 0.3),
        skill: () => createOscillatorBuffer(440, 0.2, 'sawtooth', 0.5),
        death: () => createOscillatorBuffer(80, 0.8, 'sawtooth', 0.7),
        boss_hit: () => createOscillatorBuffer(60, 0.3, 'square', 0.8),
        notification: () => createOscillatorBuffer(1200, 0.12, 'sine', 0.3),
        open_menu: () => createOscillatorBuffer(500, 0.1, 'sine', 0.25),
        scenario_start: () => createOscillatorBuffer(220, 0.6, 'sawtooth', 0.5),
        dialogue: () => createOscillatorBuffer(900, 0.04, 'sine', 0.15),
    };

    function preloadSFX() {
        if (!initialized) return;
        Object.entries(SFX_DEFS).forEach(([key, fn]) => {
            sfxBuffers[key] = fn();
        });
    }

    function playSFX(key) {
        if (!initialized || muted) return;
        resume();
        let buffer = sfxBuffers[key];
        if (!buffer) {
            if (SFX_DEFS[key]) buffer = SFX_DEFS[key]();
            else return;
        }
        const src = audioCtx.createBufferSource();
        src.buffer = buffer;
        src.connect(sfxGain);
        src.start();
    }

    // --- Procedural music generator ---
    let musicNodes = [];
    let musicScheduler = null;

    const MUSIC_THEMES = {
        main_menu: { tempo: 80, scale: [261.63, 293.66, 329.63, 349.23, 392, 440, 493.88], mood: 'epic' },
        exploration: { tempo: 90, scale: [220, 246.94, 261.63, 293.66, 329.63, 349.23, 392], mood: 'calm' },
        combat: { tempo: 140, scale: [130.81, 146.83, 164.81, 174.61, 196, 220, 246.94], mood: 'intense' },
        boss: { tempo: 160, scale: [98, 110, 130.81, 146.83, 164.81, 196, 220], mood: 'boss' },
        sad: { tempo: 60, scale: [196, 220, 261.63, 293.66, 329.63, 392, 440], mood: 'melancholy' },
        victory: { tempo: 120, scale: [261.63, 329.63, 392, 523.25, 659.25, 783.99], mood: 'triumph' },
        subway: { tempo: 100, scale: [220, 246.94, 261.63, 293.66, 329.63], mood: 'tense' },
    };

    let currentTheme = null;
    let musicPlaying = false;
    let musicBeat = 0;
    let musicTimer = null;

    function playMusic(key) {
        if (!initialized) return;
        if (currentMusicKey === key && musicPlaying) return;
        stopMusic();
        currentMusicKey = key;
        const theme = MUSIC_THEMES[key] || MUSIC_THEMES.exploration;
        currentTheme = theme;
        musicPlaying = true;
        musicBeat = 0;
        const beatDuration = 60000 / theme.tempo;
        scheduleMusicBeat(theme, beatDuration);
        musicTimer = setInterval(() => {
            musicBeat++;
            scheduleMusicBeat(theme, beatDuration);
        }, beatDuration);
    }

    function scheduleMusicBeat(theme, duration) {
        if (!audioCtx || !musicPlaying) return;
        resume();
        const scale = theme.scale;
        const note = scale[Math.floor(Math.random() * scale.length)];
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = theme.mood === 'intense' || theme.mood === 'boss' ? 'sawtooth' : 'sine';
        osc.frequency.value = note;
        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration / 1000 * 0.8);
        osc.connect(gain);
        gain.connect(musicGain);
        osc.start(audioCtx.currentTime);
        osc.stop(audioCtx.currentTime + duration / 1000);
    }

    function stopMusic() {
        musicPlaying = false;
        currentMusicKey = null;
        currentTheme = null;
        if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
    }

    function fadeOutMusic(duration) {
        if (!initialized || !musicGain) return stopMusic();
        const start = musicGain.gain.value;
        const steps = 30;
        const stepTime = duration / steps;
        let step = 0;
        const fade = setInterval(() => {
            step++;
            musicGain.gain.value = start * (1 - step / steps);
            if (step >= steps) {
                clearInterval(fade);
                stopMusic();
                musicGain.gain.value = settings.musicVolume;
            }
        }, stepTime);
    }

    // Event-driven integration
    function bindEvents() {
        EventSystem.on(EventSystem.EVENTS.PLAY_SFX, (data) => playSFX(data.key || data));
        EventSystem.on(EventSystem.EVENTS.PLAY_MUSIC, (data) => playMusic(data.key || data));
        EventSystem.on(EventSystem.EVENTS.STOP_MUSIC, () => stopMusic());
        EventSystem.on(EventSystem.EVENTS.COMBAT_START, () => playMusic('combat'));
        EventSystem.on(EventSystem.EVENTS.COMBAT_END, () => playMusic('exploration'));
        EventSystem.on(EventSystem.EVENTS.BOSS_START, () => playMusic('boss'));
        EventSystem.on(EventSystem.EVENTS.BOSS_DEATH, () => { fadeOutMusic(2000); setTimeout(() => playMusic('victory'), 2500); });
        EventSystem.on(EventSystem.EVENTS.COMBAT_HIT, () => playSFX('hit'));
        EventSystem.on(EventSystem.EVENTS.COMBAT_CRIT, () => playSFX('crit'));
        EventSystem.on(EventSystem.EVENTS.PLAYER_LEVEL_UP, () => playSFX('levelup'));
        EventSystem.on(EventSystem.EVENTS.ITEM_PICKUP, () => playSFX('pickup'));
        EventSystem.on(EventSystem.EVENTS.UI_NOTIFICATION, () => playSFX('notification'));
        EventSystem.on(EventSystem.EVENTS.DIALOGUE_START, () => playSFX('dialogue'));
        EventSystem.on(EventSystem.EVENTS.SCENARIO_START, () => playSFX('scenario_start'));
    }

    function getSettings() { return { ...settings, muted }; }

    return {
        init, resume, preloadSFX,
        playSFX, playMusic, stopMusic, fadeOutMusic,
        setMasterVolume, setMusicVolume, setSfxVolume,
        mute, unmute, toggleMute, isMuted,
        getSettings, bindEvents
    };
})();
