// ORV Game - Resource Manager
// Handles loading, caching, and unloading of game assets

const ResourceManager = (function() {
    const cache = {
        images: {},
        audio: {},
        json: {},
        fonts: {}
    };

    const loadQueue = [];
    let totalToLoad = 0;
    let totalLoaded = 0;
    let onProgressCb = null;
    let onCompleteCb = null;

    // --- Image Loading ---
    function loadImage(key, src) {
        return new Promise((resolve, reject) => {
            if (cache.images[key]) { resolve(cache.images[key]); return; }
            const img = new Image();
            img.onload = () => { cache.images[key] = img; resolve(img); };
            img.onerror = () => {
                // Create placeholder canvas image on error
                const canvas = document.createElement('canvas');
                canvas.width = 64; canvas.height = 64;
                const ctx = canvas.getContext('2d');
                ctx.fillStyle = '#4a9eff22';
                ctx.fillRect(0,0,64,64);
                ctx.strokeStyle = '#4a9eff';
                ctx.strokeRect(2,2,60,60);
                ctx.fillStyle = '#4a9eff';
                ctx.font = '10px monospace';
                ctx.fillText(key.slice(0,6), 4, 36);
                cache.images[key] = canvas;
                resolve(canvas);
            };
            img.src = src;
        });
    }

    // --- Audio Loading ---
    function loadAudio(key, src) {
        return new Promise((resolve) => {
            if (cache.audio[key]) { resolve(cache.audio[key]); return; }
            if (!window.AudioContext && !window.webkitAudioContext) { resolve(null); return; }
            const audio = new Audio();
            audio.oncanplaythrough = () => { cache.audio[key] = audio; resolve(audio); };
            audio.onerror = () => { cache.audio[key] = null; resolve(null); };
            audio.src = src;
            audio.load();
        });
    }

    // --- JSON Loading ---
    function loadJSON(key, src) {
        return new Promise((resolve, reject) => {
            if (cache.json[key]) { resolve(cache.json[key]); return; }
            fetch(src)
                .then(r => r.json())
                .then(data => { cache.json[key] = data; resolve(data); })
                .catch(() => { cache.json[key] = {}; resolve({}); });
        });
    }

    // --- Batch Queue ---
    function queue(type, key, src) {
        loadQueue.push({ type, key, src });
    }

    function setProgress(cb) { onProgressCb = cb; }
    function setComplete(cb) { onCompleteCb = cb; }

    async function processQueue() {
        totalToLoad = loadQueue.length;
        totalLoaded = 0;
        if (totalToLoad === 0) { if (onCompleteCb) onCompleteCb(); return; }

        for (const item of loadQueue) {
            try {
                if (item.type === 'image') await loadImage(item.key, item.src);
                else if (item.type === 'audio') await loadAudio(item.key, item.src);
                else if (item.type === 'json') await loadJSON(item.key, item.src);
            } catch(e) {
                console.warn(`[ResourceManager] Failed to load ${item.key}:`, e);
            }
            totalLoaded++;
            if (onProgressCb) onProgressCb(totalLoaded / totalToLoad, item.key);
        }
        loadQueue.length = 0;
        if (onCompleteCb) onCompleteCb();
    }

    // --- Getters ---
    function getImage(key) { return cache.images[key] || null; }
    function getAudio(key) { return cache.audio[key] || null; }
    function getJSON(key) { return cache.json[key] || null; }

    // --- Preload essential game assets (placeholders for browser) ---
    function preloadEssentials() {
        // These would be real asset paths in production
        // For browser-only build, we use procedural generation
        return Promise.resolve();
    }

    // --- Unload ---
    function unload(key) {
        delete cache.images[key];
        delete cache.audio[key];
        delete cache.json[key];
    }

    function getProgress() {
        return totalToLoad > 0 ? totalLoaded / totalToLoad : 1;
    }

    // Create colored placeholder sprite on canvas
    function createSprite(color, size, label) {
        const canvas = document.createElement('canvas');
        canvas.width = size || 48;
        canvas.height = size || 48;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = color || '#4a9eff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        if (label) {
            ctx.fillStyle = '#fff';
            ctx.font = `${Math.floor(canvas.width/5)}px monospace`;
            ctx.fillText(label.slice(0,3), 4, canvas.height/2 + 4);
        }
        return canvas;
    }

    return {
        loadImage, loadAudio, loadJSON,
        queue, processQueue,
        setProgress, setComplete,
        getImage, getAudio, getJSON,
        preloadEssentials, unload, getProgress,
        createSprite
    };
})();
