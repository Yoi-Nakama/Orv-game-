// ORV Game - Animation System
// Manages sprite animation states, frame timing, and transitions

const AnimationSystem = (function() {
    // Animation definitions per entity type
    const animDefs = {};
    // Active animators
    const animators = new Map();
    let animIdCounter = 0;

    // Register animation definition for an entity type
    function define(type, animations) {
        animDefs[type] = animations;
    }

    // Create an animator instance
    function createAnimator(type, defaultAnim) {
        const id = ++animIdCounter;
        const defs = animDefs[type] || {};
        const animator = {
            id, type,
            currentAnim: defaultAnim || 'idle',
            prevAnim: null,
            frame: 0,
            frameTimer: 0,
            playing: true,
            loops: true,
            onComplete: null,
            flipX: false,
            flipY: false,
            alpha: 1,
            scale: 1,
            defs
        };
        animators.set(id, animator);
        return animator;
    }

    function removeAnimator(id) {
        animators.delete(id);
    }

    function play(animator, animName, force, onComplete) {
        if (!animator) return;
        if (!force && animator.currentAnim === animName) return;
        const def = animator.defs[animName];
        if (!def) return;
        animator.prevAnim = animator.currentAnim;
        animator.currentAnim = animName;
        animator.frame = 0;
        animator.frameTimer = 0;
        animator.playing = true;
        animator.loops = def.loop !== false;
        animator.onComplete = onComplete || null;
    }

    function update(animator, dt) {
        if (!animator || !animator.playing) return;
        const def = animator.defs[animator.currentAnim];
        if (!def) return;
        animator.frameTimer += dt;
        const frameDuration = def.frameDuration || (1 / (def.fps || 8));
        if (animator.frameTimer >= frameDuration) {
            animator.frameTimer -= frameDuration;
            animator.frame++;
            if (animator.frame >= def.frames) {
                if (animator.loops) {
                    animator.frame = def.loopStart || 0;
                } else {
                    animator.frame = def.frames - 1;
                    animator.playing = false;
                    if (animator.onComplete) animator.onComplete(animator);
                    // Return to default anim
                    if (def.returnTo) play(animator, def.returnTo);
                }
            }
        }
    }

    // Draw an entity using its animator (procedural sprites via canvas)
    function draw(ctx, animator, x, y, w, h) {
        if (!animator) return;
        const def = animator.defs[animator.currentAnim];
        if (!def) return;

        ctx.save();
        ctx.globalAlpha = animator.alpha;
        if (animator.flipX) {
            ctx.translate(x + w, y);
            ctx.scale(-1, 1);
            x = 0; y = 0;
        }

        // Draw procedural sprite based on type and animation
        if (def.draw) {
            def.draw(ctx, x, y, w, h, animator.frame);
        } else {
            drawProceduralSprite(ctx, animator.type, animator.currentAnim, x, y, w, h, animator.frame);
        }

        ctx.restore();
    }

    // Procedural sprite drawing for all entity types
    function drawProceduralSprite(ctx, type, anim, x, y, w, h, frame) {
        const cx = x + w / 2;
        const cy = y + h / 2;
        const bob = Math.sin(Date.now() / 300) * 2; // idle bob
        const isMoving = anim === 'walk' || anim === 'run';
        const isAttack = anim === 'attack';
        const isHurt = anim === 'hurt';

        // Color palette per type
        const palettes = {
            player: { body: '#2244aa', hair: '#111', skin: '#f4c4a0', accent: '#4a9eff' },
            yoo_jonghyuk: { body: '#333', hair: '#111', skin: '#e8c4a0', accent: '#ff4444' },
            lee_hyunsung: { body: '#4a6688', hair: '#553322', skin: '#f0c4a0', accent: '#88aadd' },
            jung_heewon: { body: '#aa2244', hair: '#cc3366', skin: '#f0c4a0', accent: '#ff8888' },
            shin_yoosung: { body: '#aa44aa', hair: '#8822aa', skin: '#f0c4a0', accent: '#cc88ff' },
            enemy_default: { body: '#884422', skin: '#664411', accent: '#ff4400' },
            boss_default: { body: '#440011', skin: '#220008', accent: '#ff0000' },
            npc_default: { body: '#336633', skin: '#e8c090', accent: '#66aa66' },
            item: { body: '#ffcc00', accent: '#ffee88' },
        };
        const pal = palettes[type] || palettes.npc_default;

        if (type === 'item') {
            // Draw item orb
            const grd = ctx.createRadialGradient(cx, cy - bob, 2, cx, cy - bob, w * 0.4);
            grd.addColorStop(0, '#fff');
            grd.addColorStop(0.4, pal.body);
            grd.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.beginPath();
            ctx.arc(cx, cy - bob, w * 0.35, 0, Math.PI * 2);
            ctx.fillStyle = grd;
            ctx.fill();
            // Shadow
            ctx.beginPath();
            ctx.ellipse(cx, y + h - 4, w * 0.25, 4, 0, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(0,0,0,0.3)';
            ctx.fill();
            return;
        }

        // Human character sprite
        const legOffset = isMoving ? Math.sin(Date.now() / 120) * 5 : 0;
        const armOffset = isMoving ? Math.sin(Date.now() / 120 + Math.PI) * 4 : 0;
        const attackLean = isAttack ? 6 : 0;
        const hurtShake = isHurt ? (Math.random() - 0.5) * 4 : 0;

        ctx.save();
        ctx.translate(hurtShake, 0);

        // Shadow
        ctx.beginPath();
        ctx.ellipse(cx, y + h - 2, w * 0.3, 5, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.fill();

        // Body
        const bodyY = y + h * 0.35 + bob * 0.3;
        const bodyH = h * 0.3;
        ctx.fillStyle = pal.body;
        ctx.fillRect(cx - w * 0.2 + attackLean, bodyY, w * 0.4, bodyH);

        // Legs
        ctx.fillStyle = pal.body;
        ctx.fillRect(cx - w * 0.15, bodyY + bodyH, w * 0.14, h * 0.2 + legOffset);
        ctx.fillRect(cx + w * 0.01, bodyY + bodyH, w * 0.14, h * 0.2 - legOffset);

        // Arms
        ctx.fillStyle = pal.skin;
        ctx.fillRect(cx - w * 0.35 + attackLean, bodyY + 2, w * 0.15, bodyH * 0.7 + armOffset);
        ctx.fillRect(cx + w * 0.2 + attackLean, bodyY + 2, w * 0.15, bodyH * 0.7 - armOffset);

        // Head
        ctx.fillStyle = pal.skin;
        const headR = w * 0.18;
        const headY = y + h * 0.22 + bob * 0.5;
        ctx.beginPath();
        ctx.arc(cx, headY, headR, 0, Math.PI * 2);
        ctx.fill();

        // Hair
        ctx.fillStyle = pal.hair;
        ctx.beginPath();
        ctx.arc(cx, headY - headR * 0.2, headR, Math.PI, Math.PI * 2);
        ctx.fill();

        // Eyes
        ctx.fillStyle = isHurt ? '#ff0000' : '#222';
        ctx.fillRect(cx - headR * 0.5, headY - headR * 0.1, headR * 0.3, headR * 0.25);
        ctx.fillRect(cx + headR * 0.2, headY - headR * 0.1, headR * 0.3, headR * 0.25);

        // Accent glow for player / special
        if (type === 'player' || anim === 'skill') {
            ctx.shadowBlur = 12;
            ctx.shadowColor = pal.accent;
            ctx.beginPath();
            ctx.arc(cx, headY, headR + 2, 0, Math.PI * 2);
            ctx.strokeStyle = pal.accent + '44';
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.shadowBlur = 0;
        }

        ctx.restore();
    }

    // Batch update all registered animators
    function updateAll(dt) {
        animators.forEach(anim => update(anim, dt));
    }

    // Predefined animation sets
    function registerDefaults() {
        const humanAnims = {
            idle: { frames: 4, fps: 6, loop: true },
            walk: { frames: 8, fps: 12, loop: true },
            run: { frames: 8, fps: 16, loop: true },
            attack: { frames: 4, fps: 12, loop: false, returnTo: 'idle' },
            hurt: { frames: 3, fps: 10, loop: false, returnTo: 'idle' },
            death: { frames: 6, fps: 8, loop: false },
            skill: { frames: 6, fps: 12, loop: false, returnTo: 'idle' },
            cast: { frames: 8, fps: 10, loop: false, returnTo: 'idle' },
        };
        ['player','yoo_jonghyuk','lee_hyunsung','jung_heewon','shin_yoosung',
         'lee_gilyoung','han_sooyoung','npc_default'].forEach(type => {
            define(type, humanAnims);
        });

        // Boss anims
        const bossAnims = {
            idle: { frames: 6, fps: 4, loop: true },
            walk: { frames: 8, fps: 6, loop: true },
            attack: { frames: 8, fps: 10, loop: false, returnTo: 'idle' },
            hurt: { frames: 4, fps: 12, loop: false, returnTo: 'idle' },
            phase: { frames: 8, fps: 8, loop: false, returnTo: 'idle' },
            death: { frames: 10, fps: 6, loop: false },
            roar: { frames: 6, fps: 8, loop: false, returnTo: 'idle' },
        };
        ['king_of_trolls','dragon_lord_fafnir','demon_king_asmodeus',
         'secretive_plotter_avatar','yoo_jonghyuk_corrupted','boss_default'].forEach(type => {
            define(type, bossAnims);
        });

        // Enemy anims
        const enemyAnims = {
            idle: { frames: 4, fps: 5, loop: true },
            walk: { frames: 6, fps: 8, loop: true },
            attack: { frames: 4, fps: 10, loop: false, returnTo: 'idle' },
            hurt: { frames: 3, fps: 10, loop: false, returnTo: 'idle' },
            death: { frames: 6, fps: 8, loop: false },
        };
        define('enemy_default', enemyAnims);
        define('subway_troll', enemyAnims);
        define('dark_spirit', enemyAnims);

        // Item
        define('item', {
            idle: { frames: 8, fps: 6, loop: true },
            pickup: { frames: 4, fps: 12, loop: false },
        });
    }

    registerDefaults();

    return {
        define, createAnimator, removeAnimator,
        play, update, updateAll, draw
    };
})();
