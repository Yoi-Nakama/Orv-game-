// ORV Game - Input System
// Handles keyboard, mouse, touch, and virtual joystick inputs

const InputSystem = (function() {
    const keys = {};
    const mouse = { x: 0, y: 0, down: false, rightDown: false };
    const touch = { active: false, x: 0, y: 0 };
    let canvas = null;

    // Virtual joystick state
    const joystick = {
        active: false,
        startX: 0, startY: 0,
        currentX: 0, currentY: 0,
        deltaX: 0, deltaY: 0,
        magnitude: 0,
        angle: 0,
        touchId: null
    };

    // Action button states
    const actions = {
        attack: false, skill1: false, skill2: false,
        skill3: false, dodge: false, interact: false,
        jump: false, menu: false, inventory: false,
        questlog: false, worldmap: false, pause: false
    };

    // Axis values (-1 to 1)
    const axes = { horizontal: 0, vertical: 0 };

    const JOYSTICK_DEAD_ZONE = 0.15;
    const JOYSTICK_RADIUS = 50;
    let isMobileMode = false;

    function init(gameCanvas) {
        canvas = gameCanvas;
        isMobileMode = ('ontouchstart' in window) || window.innerWidth <= 600;
        bindKeyboard();
        bindMouse();
        bindTouch();
        bindVirtualButtons();
    }

    // --- Keyboard ---
    function bindKeyboard() {
        document.addEventListener('keydown', e => {
            keys[e.code] = true;
            keys[e.key] = true;
            handleKeyAction(e.code, true);
            // Prevent default for game keys
            if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) {
                e.preventDefault();
            }
        });
        document.addEventListener('keyup', e => {
            keys[e.code] = false;
            keys[e.key] = false;
            handleKeyAction(e.code, false);
        });
    }

    function handleKeyAction(code, pressed) {
        switch(code) {
            case 'Space': actions.attack = pressed; break;
            case 'KeyQ': actions.skill1 = pressed; break;
            case 'KeyW': actions.skill2 = pressed; break;
            case 'KeyE': actions.skill3 = pressed; break;
            case 'ShiftLeft': case 'ShiftRight': actions.dodge = pressed; break;
            case 'KeyF': actions.interact = pressed; if(pressed) EventSystem.emit(EventSystem.EVENTS.PLAYER_INTERACT, {}); break;
            case 'KeyI': actions.inventory = pressed; if(pressed) togglePanel('inventory'); break;
            case 'KeyJ': actions.questlog = pressed; if(pressed) togglePanel('questlog'); break;
            case 'KeyM': actions.worldmap = pressed; if(pressed) togglePanel('worldmap'); break;
            case 'Escape': actions.pause = pressed; if(pressed) togglePause(); break;
        }
        updateAxesFromKeyboard();
    }

    function updateAxesFromKeyboard() {
        axes.horizontal = 0;
        axes.vertical = 0;
        if (keys['ArrowLeft'] || keys['KeyA']) axes.horizontal -= 1;
        if (keys['ArrowRight'] || keys['KeyD']) axes.horizontal += 1;
        if (keys['ArrowUp'] || keys['KeyW'] && !actions.skill2) axes.vertical -= 1;
        if (keys['ArrowDown'] || keys['KeyS']) axes.vertical += 1;
        // Normalize diagonal
        if (axes.horizontal !== 0 && axes.vertical !== 0) {
            axes.horizontal *= 0.707;
            axes.vertical *= 0.707;
        }
    }

    // --- Mouse ---
    function bindMouse() {
        if (!canvas) return;
        canvas.addEventListener('mousedown', e => {
            mouse.down = e.button === 0;
            mouse.rightDown = e.button === 2;
            const rect = canvas.getBoundingClientRect();
            mouse.x = e.clientX - rect.left;
            mouse.y = e.clientY - rect.top;
            if (e.button === 0) actions.attack = true;
        });
        canvas.addEventListener('mouseup', e => {
            if (e.button === 0) { mouse.down = false; actions.attack = false; }
            if (e.button === 2) mouse.rightDown = false;
        });
        canvas.addEventListener('mousemove', e => {
            const rect = canvas.getBoundingClientRect();
            mouse.x = e.clientX - rect.left;
            mouse.y = e.clientY - rect.top;
        });
        canvas.addEventListener('contextmenu', e => e.preventDefault());
    }

    // --- Touch ---
    function bindTouch() {
        const joystickArea = document.getElementById('virtual-joystick-area');
        if (!joystickArea) return;

        joystickArea.addEventListener('touchstart', e => {
            e.preventDefault();
            const t = e.changedTouches[0];
            joystick.active = true;
            joystick.touchId = t.identifier;
            joystick.startX = t.clientX;
            joystick.startY = t.clientY;
            joystick.currentX = t.clientX;
            joystick.currentY = t.clientY;
            updateJoystick();
        }, { passive: false });

        joystickArea.addEventListener('touchmove', e => {
            e.preventDefault();
            for (let i = 0; i < e.changedTouches.length; i++) {
                const t = e.changedTouches[i];
                if (t.identifier === joystick.touchId) {
                    joystick.currentX = t.clientX;
                    joystick.currentY = t.clientY;
                    updateJoystick();
                    break;
                }
            }
        }, { passive: false });

        joystickArea.addEventListener('touchend', e => {
            e.preventDefault();
            for (let i = 0; i < e.changedTouches.length; i++) {
                if (e.changedTouches[i].identifier === joystick.touchId) {
                    resetJoystick();
                    break;
                }
            }
        }, { passive: false });
    }

    function updateJoystick() {
        const dx = joystick.currentX - joystick.startX;
        const dy = joystick.currentY - joystick.startY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        joystick.magnitude = Math.min(1, dist / JOYSTICK_RADIUS);
        joystick.angle = Math.atan2(dy, dx);

        const normDx = dist > 0 ? dx / dist : 0;
        const normDy = dist > 0 ? dy / dist : 0;

        if (joystick.magnitude > JOYSTICK_DEAD_ZONE) {
            axes.horizontal = normDx * joystick.magnitude;
            axes.vertical = normDy * joystick.magnitude;
        } else {
            axes.horizontal = 0;
            axes.vertical = 0;
        }

        // Update visual joystick thumb
        const thumb = document.getElementById('joystick-thumb');
        if (thumb) {
            const clampedDist = Math.min(dist, JOYSTICK_RADIUS);
            const tx = Math.cos(joystick.angle) * clampedDist;
            const ty = Math.sin(joystick.angle) * clampedDist;
            thumb.style.transform = `translate(${tx}px, ${ty}px)`;
        }
    }

    function resetJoystick() {
        joystick.active = false;
        joystick.touchId = null;
        joystick.magnitude = 0;
        axes.horizontal = 0;
        axes.vertical = 0;
        const thumb = document.getElementById('joystick-thumb');
        if (thumb) thumb.style.transform = 'translate(0, 0)';
    }

    // --- Virtual Buttons ---
    function bindVirtualButtons() {
        const buttonMap = {
            'btn-attack': 'attack',
            'btn-skill1': 'skill1',
            'btn-skill2': 'skill2',
            'btn-skill3': 'skill3',
            'btn-dodge': 'dodge',
            'btn-interact': 'interact',
        };
        Object.entries(buttonMap).forEach(([id, action]) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.addEventListener('touchstart', e => {
                e.preventDefault();
                actions[action] = true;
                AudioSystem.playSFX('click');
                if (action === 'interact') EventSystem.emit(EventSystem.EVENTS.PLAYER_INTERACT, {});
            }, { passive: false });
            el.addEventListener('touchend', e => {
                e.preventDefault();
                actions[action] = false;
            }, { passive: false });
        });

        // HUD buttons
        const hudBtns = {
            'hud-inventory': () => togglePanel('inventory'),
            'hud-quest': () => togglePanel('questlog'),
            'hud-map': () => togglePanel('worldmap'),
            'hud-menu': () => togglePause(),
        };
        Object.entries(hudBtns).forEach(([id, fn]) => {
            const el = document.getElementById(id);
            if (el) {
                el.addEventListener('click', fn);
                el.addEventListener('touchend', e => { e.preventDefault(); fn(); }, { passive: false });
            }
        });
    }

    function togglePanel(name) {
        const panels = { inventory: 'inventory-panel', questlog: 'quest-panel', worldmap: 'map-panel' };
        const id = panels[name];
        if (!id) return;
        const el = document.getElementById(id);
        if (!el) return;
        const isOpen = el.classList.contains('open');
        // Close all panels first
        Object.values(panels).forEach(pid => {
            const p = document.getElementById(pid);
            if (p) p.classList.remove('open');
        });
        if (!isOpen) {
            el.classList.add('open');
            AudioSystem.playSFX('open_menu');
            EventSystem.emit(EventSystem.EVENTS['INVENTORY_OPEN'] || `${name}:open`, {});
        } else {
            AudioSystem.playSFX('cancel');
        }
    }

    function togglePause() {
        EventSystem.emit(EventSystem.EVENTS.GAME_PAUSE, {});
    }

    // --- Public API ---
    function isKeyDown(key) { return !!keys[key]; }
    function isActionDown(action) { return !!actions[action]; }
    function getAxes() { return { ...axes }; }
    function getMouse() { return { ...mouse }; }
    function getJoystick() { return { ...joystick }; }

    function isMoving() {
        return Math.abs(axes.horizontal) > JOYSTICK_DEAD_ZONE || Math.abs(axes.vertical) > JOYSTICK_DEAD_ZONE;
    }

    function getMovementVector() {
        const ax = Math.abs(axes.horizontal) > JOYSTICK_DEAD_ZONE ? axes.horizontal : 0;
        const ay = Math.abs(axes.vertical) > JOYSTICK_DEAD_ZONE ? axes.vertical : 0;
        return { x: ax, y: ay };
    }

    function detectMobile() {
        isMobileMode = ('ontouchstart' in window) || window.innerWidth <= 600;
        const mobileControls = document.getElementById('mobile-controls');
        if (mobileControls) {
            mobileControls.style.display = isMobileMode ? 'flex' : 'none';
        }
        return isMobileMode;
    }

    window.addEventListener('resize', detectMobile);

    return {
        init, detectMobile,
        isKeyDown, isActionDown,
        getAxes, getMouse, getJoystick,
        isMoving, getMovementVector,
        togglePanel, togglePause,
        isMobileMode: () => isMobileMode
    };
})();
