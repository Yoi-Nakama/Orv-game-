// ORV Game - Camera System
// 2D camera with smooth follow, zoom, shake, and bounds clamping

const CameraSystem = (function() {
    const camera = {
        x: 0, y: 0,           // World position (top-left of view)
        targetX: 0, targetY: 0,
        width: 800, height: 600,
        zoom: 1,
        targetZoom: 1,
        shakeX: 0, shakeY: 0,
        shakeMag: 0, shakeDuration: 0, shakeTimer: 0,
        bounds: { minX: 0, minY: 0, maxX: 10000, maxY: 10000 },
        smoothing: 0.08,
        zoomSmoothing: 0.05,
    };

    function init(canvasWidth, canvasHeight) {
        camera.width = canvasWidth;
        camera.height = canvasHeight;
    }

    function setTarget(x, y) {
        camera.targetX = x - camera.width / 2;
        camera.targetY = y - camera.height / 2;
    }

    function setBounds(minX, minY, maxX, maxY) {
        camera.bounds = { minX, minY, maxX, maxY };
    }

    function setZoom(z) {
        camera.targetZoom = Math.max(0.5, Math.min(3, z));
    }

    function shake(magnitude, duration) {
        camera.shakeMag = magnitude;
        camera.shakeDuration = duration;
        camera.shakeTimer = duration;
    }

    function update(dt) {
        // Smooth follow
        const dx = camera.targetX - camera.x;
        const dy = camera.targetY - camera.y;
        camera.x += dx * camera.smoothing;
        camera.y += dy * camera.smoothing;

        // Clamp to bounds
        const viewW = camera.width / camera.zoom;
        const viewH = camera.height / camera.zoom;
        camera.x = Math.max(camera.bounds.minX, Math.min(camera.bounds.maxX - viewW, camera.x));
        camera.y = Math.max(camera.bounds.minY, Math.min(camera.bounds.maxY - viewH, camera.y));

        // Smooth zoom
        const dz = camera.targetZoom - camera.zoom;
        camera.zoom += dz * camera.zoomSmoothing;

        // Screen shake
        if (camera.shakeTimer > 0) {
            camera.shakeTimer -= dt;
            const progress = camera.shakeTimer / camera.shakeDuration;
            camera.shakeX = (Math.random() * 2 - 1) * camera.shakeMag * progress;
            camera.shakeY = (Math.random() * 2 - 1) * camera.shakeMag * progress;
        } else {
            camera.shakeX = 0;
            camera.shakeY = 0;
        }
    }

    // Apply camera transform to canvas context
    function apply(ctx) {
        ctx.save();
        ctx.translate(camera.shakeX, camera.shakeY);
        ctx.scale(camera.zoom, camera.zoom);
        ctx.translate(-camera.x, -camera.y);
    }

    function restore(ctx) {
        ctx.restore();
    }

    // Convert screen coords to world coords
    function screenToWorld(sx, sy) {
        return {
            x: sx / camera.zoom + camera.x,
            y: sy / camera.zoom + camera.y
        };
    }

    // Convert world coords to screen coords
    function worldToScreen(wx, wy) {
        return {
            x: (wx - camera.x) * camera.zoom,
            y: (wy - camera.y) * camera.zoom
        };
    }

    // Check if world rect is visible
    function isVisible(wx, wy, w, h) {
        const viewW = camera.width / camera.zoom;
        const viewH = camera.height / camera.zoom;
        return wx + w > camera.x && wx < camera.x + viewW &&
               wy + h > camera.y && wy < camera.y + viewH;
    }

    function snap(x, y) {
        camera.x = x - camera.width / 2;
        camera.y = y - camera.height / 2;
        camera.targetX = camera.x;
        camera.targetY = camera.y;
    }

    function resize(w, h) {
        camera.width = w;
        camera.height = h;
    }

    function getState() { return { ...camera }; }
    function getX() { return camera.x; }
    function getY() { return camera.y; }
    function getZoom() { return camera.zoom; }

    return {
        init, update, apply, restore,
        setTarget, setBounds, setZoom, snap, resize,
        shake, screenToWorld, worldToScreen, isVisible,
        getState, getX, getY, getZoom
    };
})();
