// ORV Game - Save System
// Manages save slots, autosave, manual save/load via localStorage

const SaveSystem = (function() {
    const SAVE_KEY = 'orv_save';
    const SLOT_COUNT = GameConfig.save.slots;
    const AUTOSAVE_INTERVAL = GameConfig.save.autosaveInterval * 1000;
    let autosaveTimer = null;
    let gameStateProvider = null; // function that returns current game state
    let gameStateLoader = null;   // function that receives loaded state

    // --- Structure ---
    function getEmptySave() {
        return {
            version: '1.0.0',
            timestamp: Date.now(),
            playtime: 0,
            playerName: 'Kim Dokja',
            level: 1,
            location: GameConfig.world.startLocation,
            scenario: GameConfig.world.startScenario,
            player: null,
            world: null,
            quests: null,
            inventory: null,
            skills: null,
            companions: null,
            constellations: null,
            flags: {},
            screenshot: null
        };
    }

    // --- Load all save data from localStorage ---
    function getAllSaves() {
        try {
            const raw = localStorage.getItem(SAVE_KEY);
            if (!raw) return { slots: Array(SLOT_COUNT).fill(null), settings: {} };
            return JSON.parse(raw);
        } catch(e) {
            console.error('[SaveSystem] Failed to read saves:', e);
            return { slots: Array(SLOT_COUNT).fill(null), settings: {} };
        }
    }

    function writeAllSaves(data) {
        try {
            localStorage.setItem(SAVE_KEY, JSON.stringify(data));
            return true;
        } catch(e) {
            console.error('[SaveSystem] Failed to write saves:', e);
            return false;
        }
    }

    // --- Save to slot ---
    function save(slotIndex, gameState) {
        EventSystem.emit(EventSystem.EVENTS.SAVE_START, { slot: slotIndex });
        const all = getAllSaves();
        if (!all.slots) all.slots = Array(SLOT_COUNT).fill(null);
        const saveData = Object.assign(getEmptySave(), gameState, {
            timestamp: Date.now()
        });
        all.slots[slotIndex] = saveData;
        const success = writeAllSaves(all);
        EventSystem.emit(EventSystem.EVENTS.SAVE_COMPLETE, { slot: slotIndex, success });
        if (success) {
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
                message: `Game saved to Slot ${slotIndex + 1}`,
                type: 'success',
                duration: 2000
            });
        }
        return success;
    }

    // --- Autosave ---
    function autosave() {
        if (!gameStateProvider) return;
        const state = gameStateProvider();
        if (!state) return;
        const all = getAllSaves();
        if (!all.autosave) all.autosave = {};
        all.autosave = Object.assign(getEmptySave(), state, {
            timestamp: Date.now(),
            isAutosave: true
        });
        writeAllSaves(all);
        EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
            message: 'Autosaved',
            type: 'info',
            duration: 1500
        });
    }

    function startAutosave() {
        stopAutosave();
        autosaveTimer = setInterval(autosave, AUTOSAVE_INTERVAL);
    }

    function stopAutosave() {
        if (autosaveTimer) { clearInterval(autosaveTimer); autosaveTimer = null; }
    }

    // --- Load from slot ---
    function load(slotIndex) {
        EventSystem.emit(EventSystem.EVENTS.LOAD_START, { slot: slotIndex });
        const all = getAllSaves();
        const saveData = slotIndex === 'autosave' ? all.autosave : (all.slots && all.slots[slotIndex]);
        if (!saveData) {
            console.warn('[SaveSystem] No save data in slot', slotIndex);
            return null;
        }
        EventSystem.emit(EventSystem.EVENTS.LOAD_COMPLETE, { slot: slotIndex, data: saveData });
        if (gameStateLoader) gameStateLoader(saveData);
        return saveData;
    }

    // --- Delete slot ---
    function deleteSave(slotIndex) {
        const all = getAllSaves();
        if (all.slots) all.slots[slotIndex] = null;
        writeAllSaves(all);
    }

    // --- Get slot info (for save/load UI) ---
    function getSlotInfo(slotIndex) {
        const all = getAllSaves();
        const slot = all.slots && all.slots[slotIndex];
        if (!slot) return null;
        return {
            exists: true,
            playerName: slot.playerName || 'Kim Dokja',
            level: slot.level || 1,
            location: slot.location || 'Unknown',
            scenario: slot.scenario || '',
            playtime: slot.playtime || 0,
            timestamp: slot.timestamp || 0,
            timestampStr: new Date(slot.timestamp || 0).toLocaleString()
        };
    }

    function getAllSlotInfo() {
        return Array.from({ length: SLOT_COUNT }, (_, i) => getSlotInfo(i));
    }

    function getAutosaveInfo() {
        const all = getAllSaves();
        if (!all.autosave) return null;
        const s = all.autosave;
        return {
            exists: true,
            playerName: s.playerName || 'Kim Dokja',
            level: s.level || 1,
            location: s.location || 'Unknown',
            timestamp: s.timestamp || 0,
            timestampStr: new Date(s.timestamp || 0).toLocaleString()
        };
    }

    // --- Settings persistence ---
    function saveSettings(settings) {
        const all = getAllSaves();
        all.settings = settings;
        writeAllSaves(all);
    }

    function loadSettings() {
        const all = getAllSaves();
        return all.settings || {};
    }

    // --- Providers ---
    function setStateProvider(fn) { gameStateProvider = fn; }
    function setStateLoader(fn) { gameStateLoader = fn; }

    // Format playtime
    function formatPlaytime(ms) {
        const s = Math.floor(ms / 1000);
        const h = Math.floor(s / 3600);
        const m = Math.floor((s % 3600) / 60);
        const sec = s % 60;
        return `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`;
    }

    return {
        save, load, deleteSave, autosave,
        startAutosave, stopAutosave,
        getAllSlotInfo, getSlotInfo, getAutosaveInfo,
        saveSettings, loadSettings,
        setStateProvider, setStateLoader,
        formatPlaytime
    };
})();
