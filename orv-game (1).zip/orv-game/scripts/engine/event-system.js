// ORV Game - Event System
// Pub/Sub event bus for decoupled communication between all game systems

const EventSystem = (function() {
    const listeners = {};
    const onceListeners = {};
    const eventLog = [];
    const MAX_LOG = 200;

    function on(event, callback, context) {
        if (!listeners[event]) listeners[event] = [];
        listeners[event].push({ callback, context: context || null });
    }

    function once(event, callback, context) {
        if (!onceListeners[event]) onceListeners[event] = [];
        onceListeners[event].push({ callback, context: context || null });
    }

    function off(event, callback) {
        if (listeners[event]) {
            listeners[event] = listeners[event].filter(l => l.callback !== callback);
        }
        if (onceListeners[event]) {
            onceListeners[event] = onceListeners[event].filter(l => l.callback !== callback);
        }
    }

    function emit(event, data) {
        // Log event
        eventLog.push({ event, data, time: Date.now() });
        if (eventLog.length > MAX_LOG) eventLog.shift();

        // Fire persistent listeners
        if (listeners[event]) {
            listeners[event].forEach(l => {
                try {
                    l.callback.call(l.context, data);
                } catch(e) {
                    console.error(`[EventSystem] Error in listener for '${event}':`, e);
                }
            });
        }

        // Fire once listeners then remove
        if (onceListeners[event]) {
            const toFire = onceListeners[event].slice();
            onceListeners[event] = [];
            toFire.forEach(l => {
                try {
                    l.callback.call(l.context, data);
                } catch(e) {
                    console.error(`[EventSystem] Error in once-listener for '${event}':`, e);
                }
            });
        }
    }

    function clear(event) {
        if (event) {
            delete listeners[event];
            delete onceListeners[event];
        } else {
            Object.keys(listeners).forEach(k => delete listeners[k]);
            Object.keys(onceListeners).forEach(k => delete onceListeners[k]);
        }
    }

    function getLog() { return eventLog.slice(); }

    // Named game events constants
    const EVENTS = {
        // Game lifecycle
        GAME_START: 'game:start',
        GAME_PAUSE: 'game:pause',
        GAME_RESUME: 'game:resume',
        GAME_OVER: 'game:over',
        SCENE_CHANGE: 'scene:change',
        SCENE_LOADED: 'scene:loaded',

        // Player
        PLAYER_MOVE: 'player:move',
        PLAYER_ATTACK: 'player:attack',
        PLAYER_HURT: 'player:hurt',
        PLAYER_DEATH: 'player:death',
        PLAYER_LEVEL_UP: 'player:levelup',
        PLAYER_SKILL_USE: 'player:skill',
        PLAYER_INTERACT: 'player:interact',
        PLAYER_STAT_CHANGE: 'player:stat',

        // Combat
        COMBAT_START: 'combat:start',
        COMBAT_END: 'combat:end',
        COMBAT_HIT: 'combat:hit',
        COMBAT_MISS: 'combat:miss',
        COMBAT_CRIT: 'combat:crit',
        COMBAT_KILL: 'combat:kill',
        DAMAGE_DEALT: 'combat:damage',
        HEAL_APPLIED: 'combat:heal',
        STATUS_APPLIED: 'combat:status',
        STATUS_REMOVED: 'combat:status_removed',

        // Enemies / Bosses
        ENEMY_SPAWN: 'enemy:spawn',
        ENEMY_DEATH: 'enemy:death',
        ENEMY_AGGRO: 'enemy:aggro',
        BOSS_START: 'boss:start',
        BOSS_PHASE: 'boss:phase',
        BOSS_DEATH: 'boss:death',

        // Quests
        QUEST_START: 'quest:start',
        QUEST_UPDATE: 'quest:update',
        QUEST_COMPLETE: 'quest:complete',
        QUEST_FAIL: 'quest:fail',
        OBJECTIVE_COMPLETE: 'quest:objective',

        // Dialogue
        DIALOGUE_START: 'dialogue:start',
        DIALOGUE_END: 'dialogue:end',
        DIALOGUE_CHOICE: 'dialogue:choice',

        // Inventory / Items
        ITEM_PICKUP: 'item:pickup',
        ITEM_USE: 'item:use',
        ITEM_EQUIP: 'item:equip',
        ITEM_DROP: 'item:drop',
        INVENTORY_OPEN: 'inventory:open',
        INVENTORY_CLOSE: 'inventory:close',

        // Skills
        SKILL_UNLOCK: 'skill:unlock',
        SKILL_UPGRADE: 'skill:upgrade',
        SKILL_COOLDOWN_START: 'skill:cd_start',
        SKILL_COOLDOWN_END: 'skill:cd_end',

        // Map / World
        MAP_OPEN: 'map:open',
        MAP_CLOSE: 'map:close',
        ZONE_ENTER: 'zone:enter',
        ZONE_EXIT: 'zone:exit',
        CHECKPOINT_REACHED: 'checkpoint:reached',
        FAST_TRAVEL: 'world:fast_travel',

        // Scenario
        SCENARIO_START: 'scenario:start',
        SCENARIO_CLEAR: 'scenario:clear',
        SCENARIO_FAIL: 'scenario:fail',
        SYSTEM_MESSAGE: 'scenario:system_msg',

        // Constellation / Sponsors
        CONSTELLATION_FAVOR: 'constellation:favor',
        CONSTELLATION_SKILL: 'constellation:skill',

        // Save / Load
        SAVE_START: 'save:start',
        SAVE_COMPLETE: 'save:complete',
        LOAD_START: 'load:start',
        LOAD_COMPLETE: 'load:complete',

        // UI
        UI_NOTIFICATION: 'ui:notification',
        HUD_UPDATE: 'ui:hud',
        CUTSCENE_START: 'cutscene:start',
        CUTSCENE_END: 'cutscene:end',

        // Audio
        PLAY_SFX: 'audio:sfx',
        PLAY_MUSIC: 'audio:music',
        STOP_MUSIC: 'audio:stop_music',
    };

    return { on, once, off, emit, clear, getLog, EVENTS };
})();
