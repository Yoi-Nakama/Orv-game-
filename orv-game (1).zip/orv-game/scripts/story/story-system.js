// ORV Game - Story System
// Manages cutscenes, system-message overlays, and narrative events

const StorySystem = (function() {
    let messageQueue = [];
    let activeMessage = null;
    let messageTimer = 0;
    let messageDuration = 4000;
    let cutsceneActive = false;

    // UI elements
    let sysOverlay, sysText, sysSubtext, sysDivider;
    let cutsceneEl;

    function init() {
        sysOverlay = document.getElementById('system-message-overlay');
        sysText = document.getElementById('system-message-text');
        sysSubtext = document.getElementById('system-message-subtext');
        sysDivider = document.querySelector('.system-message-divider');
        cutsceneEl = document.getElementById('cutscene-overlay');

        // Listen for system message events
        EventSystem.on(EventSystem.EVENTS.SYSTEM_MESSAGE, (data) => {
            queueMessage(data);
        });
    }

    const TYPE_STYLES = {
        system: { border: '#4a9eff', glow: '#4a9eff', prefix: '◈ System', bg: 'rgba(0,0,40,0.95)' },
        scenario_clear: { border: '#c8a951', glow: '#c8a951', prefix: '✦ Scenario Clear', bg: 'rgba(20,15,0,0.95)' },
        scenario_fail: { border: '#ff3333', glow: '#ff3333', prefix: '✗ Scenario Failed', bg: 'rgba(30,0,0,0.95)' },
        boss: { border: '#ff4400', glow: '#ff4400', prefix: '⚔ Boss Event', bg: 'rgba(30,5,0,0.95)' },
        boss_phase: { border: '#ff0000', glow: '#ff0000', prefix: '‼ Phase Transition', bg: 'rgba(30,0,0,0.97)' },
        boss_enrage: { border: '#ff0000', glow: '#ff0000', prefix: '!!', bg: 'rgba(40,0,0,0.97)' },
        quest: { border: '#88ffcc', glow: '#88ffcc', prefix: '◎ Quest', bg: 'rgba(0,20,15,0.95)' },
        quest_complete: { border: '#ffcc00', glow: '#ffcc00', prefix: '★ Quest Complete', bg: 'rgba(20,15,0,0.95)' },
        companion: { border: '#88ccff', glow: '#88ccff', prefix: '◉ Companion', bg: 'rgba(0,15,30,0.95)' },
        constellation: { border: '#c8a951', glow: '#c8a951', prefix: '◇ Constellation', bg: 'rgba(15,10,0,0.95)' },
        skill: { border: '#aa88ff', glow: '#aa88ff', prefix: '◆ Skill Activated', bg: 'rgba(10,0,25,0.95)' },
        ultimate: { border: '#ffcc00', glow: '#ffcc00', prefix: '✦ ULTIMATE', bg: 'rgba(20,15,0,0.97)' },
        affinity: { border: '#ff88aa', glow: '#ff88aa', prefix: '♥ Affinity', bg: 'rgba(25,0,10,0.95)' },
    };

    function queueMessage(data) {
        messageQueue.push(data);
    }

    function update(dt) {
        if (activeMessage) {
            messageTimer -= dt * 1000;
            if (messageTimer <= 0) {
                hideMessage();
            }
        }
        if (!activeMessage && messageQueue.length > 0) {
            showNextMessage();
        }
    }

    function showNextMessage() {
        const msg = messageQueue.shift();
        if (!msg) return;
        activeMessage = msg;
        messageTimer = msg.duration || messageDuration;
        displayMessage(msg);
    }

    function displayMessage(msg) {
        if (!sysOverlay) return;
        const style = TYPE_STYLES[msg.type] || TYPE_STYLES.system;

        sysOverlay.style.display = 'flex';
        sysOverlay.style.borderColor = style.border;
        sysOverlay.style.boxShadow = `0 0 20px ${style.glow}44, inset 0 0 30px rgba(0,0,0,0.5)`;
        sysOverlay.style.background = style.bg;

        if (sysText) {
            const prefix = document.createElement('span');
            prefix.style.color = style.border;
            prefix.style.fontSize = '0.7em';
            prefix.style.display = 'block';
            prefix.style.letterSpacing = '4px';
            prefix.style.marginBottom = '4px';
            prefix.textContent = style.prefix;
            sysText.innerHTML = '';
            sysText.appendChild(prefix);
            const mainText = document.createTextNode(msg.text || '');
            sysText.appendChild(mainText);
        }
        if (sysSubtext) {
            sysSubtext.textContent = msg.subtext || '';
            sysSubtext.style.display = msg.subtext ? 'block' : 'none';
        }
        if (sysDivider) sysDivider.style.borderColor = style.border;

        // Animate in
        sysOverlay.style.animation = 'none';
        void sysOverlay.offsetWidth;
        sysOverlay.style.animation = 'systemMsgIn 0.3s ease';

        AudioSystem.playSFX('notification');
    }

    function hideMessage() {
        activeMessage = null;
        if (sysOverlay) sysOverlay.style.display = 'none';
    }

    // --- UI Notification toasts ---
    let notifContainer = null;

    function initNotifications() {
        notifContainer = document.getElementById('notification-container');
        if (!notifContainer) {
            notifContainer = document.createElement('div');
            notifContainer.id = 'notification-container';
            notifContainer.style.cssText = 'position:fixed;top:80px;right:16px;display:flex;flex-direction:column;gap:8px;pointer-events:none;z-index:900;';
            document.body.appendChild(notifContainer);
        }
        EventSystem.on(EventSystem.EVENTS.UI_NOTIFICATION, showNotification);
    }

    const NOTIF_COLORS = {
        info: '#4a9eff', success: '#00ff88', warning: '#ffcc00',
        error: '#ff4444', item: '#c8a951', quest: '#88ffcc',
        quest_complete: '#ffcc00', quest_fail: '#ff4444',
        skill: '#aa88ff', constellation: '#c8a951', companion: '#88ccff',
        objective: '#88ffcc', affinity: '#ff88aa'
    };

    function showNotification(data) {
        if (!notifContainer) return;
        const color = NOTIF_COLORS[data.type] || '#fff';
        const el = document.createElement('div');
        el.style.cssText = `
            padding:8px 14px;background:rgba(0,0,0,0.9);border-left:3px solid ${color};
            color:${color};font-family:Rajdhani,sans-serif;font-size:13px;
            border-radius:2px;animation:notifIn 0.2s ease;max-width:220px;
            box-shadow:0 0 10px ${color}44;
        `;
        // Rarity prefix for items
        if (data.rarity && data.rarity !== 'common') {
            const rc = GameConfig.rarityColors?.[data.rarity] || color;
            el.style.borderLeftColor = rc;
            el.style.color = rc;
        }
        el.textContent = data.message || '';
        notifContainer.appendChild(el);
        setTimeout(() => {
            el.style.transition = 'opacity 0.4s';
            el.style.opacity = '0';
            setTimeout(() => { if (el.parentNode) el.parentNode.removeChild(el); }, 400);
        }, data.duration || 2500);
    }

    // --- Cutscenes ---
    function playCutscene(cutsceneId) {
        // Minimal cutscene: show overlay with text slides
        const cutscenes = {
            intro_subway: [
                { text: "Kim Dokja opened the final chapter of 'Three Ways to Survive in a Ruined World'.", duration: 3000 },
                { text: "He had been the sole reader of this novel for 10 years.", duration: 3000 },
                { text: "And now... he found himself inside it.", duration: 3000 },
                { text: "The 1863rd day of the scenario. The end that only he had ever read.", duration: 4000 },
            ],
            jonghyuk_reveal: [
                { text: "Yoo Jonghyuk. The protagonist of Three Ways to Survive in a Ruined World.", duration: 3000 },
                { text: "A man who had regressed countless times, rewriting history with his bare hands.", duration: 3000 },
                { text: "He was not supposed to be here. Not yet.", duration: 3000 },
            ]
        };
        const slides = cutscenes[cutsceneId];
        if (!slides) return;
        cutsceneActive = true;
        showCutsceneSlides(slides, 0);
    }

    function showCutsceneSlides(slides, index) {
        if (index >= slides.length) {
            if (cutsceneEl) cutsceneEl.style.display = 'none';
            cutsceneActive = false;
            EventSystem.emit(EventSystem.EVENTS.CUTSCENE_END, {});
            return;
        }
        if (cutsceneEl) {
            cutsceneEl.style.display = 'flex';
            const textEl = cutsceneEl.querySelector('.cutscene-text');
            if (textEl) textEl.textContent = slides[index].text;
        }
        EventSystem.emit(EventSystem.EVENTS.CUTSCENE_START, { index });
        setTimeout(() => showCutsceneSlides(slides, index + 1), slides[index].duration || 3000);
    }

    function isCutsceneActive() { return cutsceneActive; }
    function isSystemMessageActive() { return !!activeMessage; }

    return {
        init, initNotifications, update,
        queueMessage, showNotification, hideMessage,
        playCutscene, isCutsceneActive, isSystemMessageActive
    };
})();
