// ORV Game - Constellation System
// Manages the 9 sponsor constellations, favor points, reactions, skill unlocks

const ConstellationSystem = (function() {
    let constellationFavor = {};  // constellationId -> favor (0-100)
    let activeContract = null;    // Current main sponsor
    let constellationReactions = {}; // id -> array of recent reactions
    let dokkaebiCoinRewards = 0;  // Accumulated coins from constellation favor

    const CONSTELLATIONS = GameConfig.constellations;

    function init() {
        constellationFavor = {};
        CONSTELLATIONS.forEach(c => { constellationFavor[c.id] = 0; });
        activeContract = null;
        constellationReactions = {};
    }

    // Gain favor with a constellation
    function gainFavor(constellationId, amount, reason) {
        if (!constellationFavor.hasOwnProperty(constellationId)) return;
        constellationFavor[constellationId] = Math.max(0, Math.min(100, constellationFavor[constellationId] + amount));
        const constel = CONSTELLATIONS.find(c => c.id === constellationId);

        // Add reaction
        if (!constellationReactions[constellationId]) constellationReactions[constellationId] = [];
        const reaction = generateReaction(constel, amount, reason);
        constellationReactions[constellationId].unshift({ text: reaction, time: Date.now() });
        if (constellationReactions[constellationId].length > 5) constellationReactions[constellationId].pop();

        // Show constellation message
        if (amount > 0) {
            EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
                text: `[Constellation Reaction]`,
                subtext: `${constel?.name || constellationId}: "${reaction}"`,
                type: 'constellation'
            });
        }

        // Reward coins
        const coins = Math.floor(amount * 0.5);
        if (coins > 0) {
            InventorySystem.addDokkaebiCoins(coins);
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
                message: `+${coins} Dokkaebi Coins from constellation`,
                type: 'constellation',
                duration: 2500
            });
        }

        EventSystem.emit(EventSystem.EVENTS.CONSTELLATION_FAVOR, { constellationId, favor: constellationFavor[constellationId], amount });

        // Check for skill unlocks
        checkFavorThresholds(constellationId);
    }

    function loseFavor(constellationId, amount) {
        gainFavor(constellationId, -amount, 'action');
    }

    function generateReaction(constel, amount, reason) {
        if (!constel) return 'Interesting...';
        const positiveReactions = constel.reactions?.positive || [
            'Hmm, this is entertaining.',
            'Not bad, protagonist.',
            'I\'m watching closely.',
            'Your story grows more interesting.',
            'Keep going. Don\'t disappoint me.'
        ];
        const negativeReactions = constel.reactions?.negative || [
            'Disappointing.',
            'That was boring.',
            'I expected more.',
            'Try harder, protagonist.',
        ];
        const reactions = amount >= 0 ? positiveReactions : negativeReactions;
        return reactions[Math.floor(Math.random() * reactions.length)];
    }

    function checkFavorThresholds(constellationId) {
        const constel = CONSTELLATIONS.find(c => c.id === constellationId);
        if (!constel || !constel.skillGifts) return;
        const favor = constellationFavor[constellationId];
        constel.skillGifts.forEach(gift => {
            const flagKey = `constel_gift_${constellationId}_${gift.threshold}`;
            if (favor >= gift.threshold && !QuestSystem.hasFlag(flagKey)) {
                QuestSystem.setFlag(flagKey, true);
                if (gift.skill) {
                    SkillSystem.learnSkill(gift.skill);
                    EventSystem.emit(EventSystem.EVENTS.CONSTELLATION_SKILL, {
                        constellationId, skill: gift.skill,
                        constelName: constel.name
                    });
                    EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
                        text: `[Constellation Gift]`,
                        subtext: `${constel.name} grants you the skill: ${gift.skill}`,
                        type: 'constellation'
                    });
                }
                if (gift.coins) InventorySystem.addDokkaebiCoins(gift.coins);
            }
        });
    }

    // Set active contract constellation
    function setContract(constellationId) {
        activeContract = constellationId;
        const constel = CONSTELLATIONS.find(c => c.id === constellationId);
        EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
            text: `[Contract Established]`,
            subtext: `You have entered a contract with ${constel?.name || constellationId}`,
            type: 'constellation'
        });
        // Grant contract bonuses
        if (constel?.contractBonus) {
            Object.entries(constel.contractBonus).forEach(([key, val]) => {
                if (window.GameState?.player?.stats) {
                    StatsSystem.addMod(GameState.player.stats, key, val);
                }
            });
        }
    }

    // Get constellation info for UI
    function getConstellationInfo(id) {
        const constel = CONSTELLATIONS.find(c => c.id === id);
        if (!constel) return null;
        return {
            ...constel,
            favor: constellationFavor[id] || 0,
            reactions: constellationReactions[id] || [],
            hasContract: activeContract === id
        };
    }

    function getAllConstellationInfo() {
        return CONSTELLATIONS.map(c => getConstellationInfo(c.id));
    }

    // Called when player does impressive things
    function reactToAction(actionType, value) {
        CONSTELLATIONS.forEach(c => {
            let favorChange = 0;
            switch(actionType) {
                case 'boss_kill': favorChange = 5 + Math.floor(value / 10); break;
                case 'survival': favorChange = 2; break;
                case 'dramatic_moment': favorChange = 8; break;
                case 'use_unique_skill': favorChange = 4; break;
                case 'died': favorChange = -3; break;
                case 'ran_away': favorChange = -2; break;
                case 'clever_solution': favorChange = 6; break;
                case 'read_scenario': favorChange = 3; break;
                case 'kill_count': favorChange = Math.floor(value * 0.5); break;
            }
            // Different constellations weight things differently
            if (c.id === 'demon_king_of_salvation') {
                if (actionType === 'dramatic_moment') favorChange *= 2;
                if (actionType === 'use_unique_skill') favorChange *= 1.5;
            }
            if (c.id === 'bald_general_of_justice') {
                if (actionType === 'boss_kill') favorChange *= 1.5;
            }
            if (c.id === 'outer_god') {
                favorChange = Math.abs(favorChange) * 0.2; // unpredictable
            }
            if (favorChange !== 0) {
                gainFavor(c.id, Math.floor(favorChange));
            }
        });
    }

    function getFavor(constellationId) { return constellationFavor[constellationId] || 0; }
    function getActiveContract() { return activeContract; }
    function getTotalFavor() {
        return Object.values(constellationFavor).reduce((a, b) => a + b, 0);
    }

    function serialize() {
        return { constellationFavor, activeContract, constellationReactions };
    }

    function deserialize(data) {
        if (!data) return;
        constellationFavor = data.constellationFavor || {};
        activeContract = data.activeContract || null;
        constellationReactions = data.constellationReactions || {};
    }

    return {
        init, gainFavor, loseFavor, setContract,
        getConstellationInfo, getAllConstellationInfo,
        reactToAction, getFavor, getActiveContract, getTotalFavor,
        serialize, deserialize
    };
})();
