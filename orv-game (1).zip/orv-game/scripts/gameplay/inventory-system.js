// ORV Game - Inventory System
// Manages player inventory, equipment slots, item usage, drops

const InventorySystem = (function() {
    const MAX_SLOTS = 40;
    const EQUIPMENT_SLOTS = ['weapon', 'armor', 'helmet', 'accessory1', 'accessory2', 'special'];

    let inventory = [];       // Array of { itemId, quantity, ...itemData }
    let equipment = {};       // slotName -> item
    let gold = 0;
    let dokkaebiCoins = 0;
    let constellationFragments = 0;

    function init() {
        inventory = [];
        equipment = {};
        EQUIPMENT_SLOTS.forEach(s => { equipment[s] = null; });
        gold = GameConfig.player.startGold || 0;
        dokkaebiCoins = 0;
        constellationFragments = 0;
    }

    // Get item definition
    function getItemDef(itemId) {
        return ItemsData.getItem(itemId);
    }

    // Add item to inventory
    function addItem(itemId, quantity) {
        quantity = quantity || 1;
        const def = getItemDef(itemId);
        if (!def) { console.warn('[Inventory] Unknown item:', itemId); return false; }

        // Check if stackable
        if (def.stackable !== false) {
            const existing = inventory.find(i => i.id === itemId);
            if (existing) {
                existing.quantity += quantity;
                notifyUI();
                EventSystem.emit(EventSystem.EVENTS.ITEM_PICKUP, { itemId, quantity });
                EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
                    message: `+${quantity} ${def.name}`,
                    type: 'item',
                    rarity: def.rarity,
                    duration: 2000
                });
                return true;
            }
        }

        if (inventory.length >= MAX_SLOTS) {
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, { message: 'Inventory full!', type: 'warning' });
            return false;
        }

        inventory.push({
            id: itemId,
            quantity,
            equipped: false
        });
        notifyUI();
        EventSystem.emit(EventSystem.EVENTS.ITEM_PICKUP, { itemId, quantity });
        EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
            message: `Obtained: ${def.name}`,
            type: 'item',
            rarity: def.rarity,
            duration: 2500
        });
        return true;
    }

    // Remove item
    function removeItem(itemId, quantity) {
        quantity = quantity || 1;
        const idx = inventory.findIndex(i => i.id === itemId);
        if (idx === -1) return false;
        inventory[idx].quantity -= quantity;
        if (inventory[idx].quantity <= 0) inventory.splice(idx, 1);
        notifyUI();
        return true;
    }

    // Use item
    function useItem(itemId, targetEntity) {
        const slot = inventory.find(i => i.id === itemId);
        if (!slot || slot.quantity <= 0) return false;
        const def = getItemDef(itemId);
        if (!def || def.type === 'equipment') return false;
        if (!def.usable) return false;

        // Apply item effect
        const result = applyItemEffect(def, targetEntity);
        if (result) {
            removeItem(itemId, 1);
            AudioSystem.playSFX('pickup');
            EventSystem.emit(EventSystem.EVENTS.ITEM_USE, { itemId, def });
        }
        return result;
    }

    function applyItemEffect(def, target) {
        if (!target || !target.stats) return false;
        if (def.effect) {
            if (def.effect.hp) {
                const heal = typeof def.effect.hp === 'string'
                    ? eval(def.effect.hp.replace('maxHP', target.stats.maxHP))
                    : def.effect.hp;
                target.stats.HP = Math.min(target.stats.maxHP, target.stats.HP + heal);
                ParticleSystem.emit('heal', target.x + target.width/2, target.y + target.height/2);
                ParticleSystem.emitText(`+${Math.floor(heal)} HP`, target.x + target.width/2, target.y, '#00ff88', 16);
                EventSystem.emit(EventSystem.EVENTS.HEAL_APPLIED, { amount: heal, target });
            }
            if (def.effect.mp) {
                target.stats.MP = Math.min(target.stats.maxMP, target.stats.MP + def.effect.mp);
            }
            if (def.effect.sp) {
                target.stats.SP = Math.min(target.stats.maxSP, target.stats.SP + def.effect.sp);
            }
        }
        return true;
    }

    // Equip item
    function equip(itemId) {
        const slot = inventory.find(i => i.id === itemId);
        if (!slot) return false;
        const def = getItemDef(itemId);
        if (!def || def.type !== 'equipment') return false;
        const eqSlot = def.slot;
        if (!EQUIPMENT_SLOTS.includes(eqSlot)) return false;

        // Unequip current
        if (equipment[eqSlot]) unequip(eqSlot);

        equipment[eqSlot] = { ...def, inventoryId: itemId };
        slot.equipped = true;
        applyEquipmentStats(def, 1);
        notifyUI();
        EventSystem.emit(EventSystem.EVENTS.ITEM_EQUIP, { itemId, def, slot: eqSlot });
        AudioSystem.playSFX('confirm');
        return true;
    }

    function unequip(slotName) {
        if (!equipment[slotName]) return false;
        const def = equipment[slotName];
        applyEquipmentStats(def, -1);
        const invSlot = inventory.find(i => i.id === def.id);
        if (invSlot) invSlot.equipped = false;
        equipment[slotName] = null;
        notifyUI();
        return true;
    }

    function applyEquipmentStats(def, multiplier) {
        if (!def.stats) return;
        const player = window.GameState && window.GameState.player;
        if (!player) return;
        Object.entries(def.stats).forEach(([key, val]) => {
            StatsSystem.addMod(player.stats, key, val * multiplier);
        });
        StatsSystem.compute(player.stats, player.level);
    }

    // Get equipped item in slot
    function getEquipped(slotName) { return equipment[slotName]; }
    function getAllEquipped() { return { ...equipment }; }

    // Currency
    function addGold(amount) { gold += amount; notifyUI(); }
    function spendGold(amount) {
        if (gold < amount) return false;
        gold -= amount;
        notifyUI();
        return true;
    }
    function addDokkaebiCoins(amount) { dokkaebiCoins += amount; notifyUI(); }
    function spendDokkaebiCoins(amount) {
        if (dokkaebiCoins < amount) return false;
        dokkaebiCoins -= amount;
        notifyUI();
        return true;
    }
    function addConstellationFragments(amount) { constellationFragments += amount; notifyUI(); }

    function getGold() { return gold; }
    function getDokkaebiCoins() { return dokkaebiCoins; }
    function getConstellationFragments() { return constellationFragments; }

    // Drop generation
    function generateDrops(entityDef) {
        const drops = [];
        if (!entityDef || !entityDef.drops) return drops;
        entityDef.drops.forEach(drop => {
            const roll = Math.random() * 100;
            if (roll < drop.chance) {
                const qty = drop.min === drop.max ? drop.min :
                    drop.min + Math.floor(Math.random() * (drop.max - drop.min + 1));
                drops.push({ itemId: drop.itemId, quantity: qty });
            }
        });
        return drops;
    }

    function collectDrops(drops) {
        drops.forEach(drop => {
            if (drop.type === 'gold') addGold(drop.amount);
            else if (drop.type === 'coins') addDokkaebiCoins(drop.amount);
            else addItem(drop.itemId, drop.quantity);
        });
    }

    // Get inventory for UI
    function getInventory() { return inventory.slice(); }
    function getInventoryByType(type) {
        return inventory.filter(i => {
            const def = getItemDef(i.id);
            return def && (type === 'all' || def.type === type);
        });
    }

    function hasItem(itemId) {
        return inventory.some(i => i.id === itemId && i.quantity > 0);
    }
    function getQuantity(itemId) {
        const slot = inventory.find(i => i.id === itemId);
        return slot ? slot.quantity : 0;
    }

    function notifyUI() {
        EventSystem.emit(EventSystem.EVENTS.HUD_UPDATE, { type: 'inventory' });
        // Update HUD gold display
        const goldEl = document.getElementById('hud-gold');
        if (goldEl) goldEl.textContent = gold.toLocaleString();
    }

    // Serialize for save
    function serialize() {
        return { inventory, equipment, gold, dokkaebiCoins, constellationFragments };
    }

    function deserialize(data) {
        if (!data) return;
        inventory = data.inventory || [];
        equipment = data.equipment || {};
        EQUIPMENT_SLOTS.forEach(s => { if (!equipment[s]) equipment[s] = null; });
        gold = data.gold || 0;
        dokkaebiCoins = data.dokkaebiCoins || 0;
        constellationFragments = data.constellationFragments || 0;
        notifyUI();
    }

    return {
        init, addItem, removeItem, useItem, equip, unequip,
        getEquipped, getAllEquipped, generateDrops, collectDrops,
        addGold, spendGold, addDokkaebiCoins, spendDokkaebiCoins,
        addConstellationFragments,
        getGold, getDokkaebiCoins, getConstellationFragments,
        getInventory, getInventoryByType, hasItem, getQuantity,
        serialize, deserialize
    };
})();
