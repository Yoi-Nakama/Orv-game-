// ORV Game - Leveling System
// Handles EXP gain, level-up screens, stat point allocation

const LevelingSystem = (function() {
    function gainExp(player, amount) {
        if (!player || player.level >= GameConfig.leveling.maxLevel) return;
        const bonusMult = SkillSystem.getPassiveBonuses().EXP_MULT || 1;
        const finalExp = Math.floor(amount * bonusMult * (GameConfig.leveling.expMultMods?.reader || 1));
        player.exp += finalExp;

        // Check for level-up
        const needed = StatsSystem.expToLevel(player.level);
        if (player.exp >= needed) {
            player.exp -= needed;
            levelUp(player);
        }

        // Update HUD
        updateExpHUD(player);
    }

    function levelUp(player) {
        player.level++;
        StatsSystem.applyLevelUp(player.stats, player.level, player.class);
        StatsSystem.clamp(player.stats);

        // Particles and effects
        ParticleSystem.emit('levelup', player.x + player.width/2, player.y + player.height/2);
        AudioSystem.playSFX('levelup');
        CameraSystem.shake(8, 0.5);

        // ORV-style system message
        EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
            text: `Level Up! You are now Lv.${player.level}`,
            subtext: `Stats increased. Grade: ${StatsSystem.getGrade(player.level)}`,
            type: 'system',
            duration: 3500
        });

        // Show level up screen
        showLevelUpScreen(player);

        EventSystem.emit(EventSystem.EVENTS.PLAYER_LEVEL_UP, { level: player.level, player });
        updateExpHUD(player);

        // Chain level up
        const needed = StatsSystem.expToLevel(player.level);
        if (player.exp >= needed) {
            player.exp -= needed;
            levelUp(player);
        }
    }

    function showLevelUpScreen(player) {
        const el = document.getElementById('level-up-screen');
        if (!el) return;
        const lvlEl = el.querySelector('#level-up-number');
        if (lvlEl) lvlEl.textContent = player.level;
        el.classList.add('show');
        setTimeout(() => el.classList.remove('show'), 3000);
    }

    function updateExpHUD(player) {
        const expFill = document.getElementById('hud-exp-fill');
        const expText = document.getElementById('hud-level');
        if (expFill) {
            const needed = StatsSystem.expToLevel(player.level);
            expFill.style.width = `${Math.min(100, (player.exp / needed) * 100)}%`;
        }
        if (expText) expText.textContent = `Lv.${player.level}`;
        EventSystem.emit(EventSystem.EVENTS.HUD_UPDATE, { type: 'exp' });
    }

    function updatePlayerHUD(player) {
        if (!player) return;
        const hpFill = document.getElementById('hud-hp-fill');
        const hpText = document.getElementById('hud-hp-text');
        const mpFill = document.getElementById('hud-mp-fill');
        const mpText = document.getElementById('hud-mp-text');
        const spFill = document.getElementById('hud-sp-fill');

        if (hpFill) hpFill.style.width = `${Math.max(0, StatsSystem.hpPercent(player.stats) * 100)}%`;
        if (hpText) hpText.textContent = `${Math.floor(player.stats.HP)} / ${player.stats.maxHP}`;
        if (mpFill) mpFill.style.width = `${Math.max(0, StatsSystem.mpPercent(player.stats) * 100)}%`;
        if (mpText) mpText.textContent = `${Math.floor(player.stats.MP)} / ${player.stats.maxMP}`;
        if (spFill) spFill.style.width = `${Math.max(0, StatsSystem.spPercent(player.stats) * 100)}%`;

        updateExpHUD(player);
    }

    return { gainExp, levelUp, updateExpHUD, updatePlayerHUD };
})();
