// ORV Game - Dialogue System
// Handles branching dialogue trees, choices, NPC portraits, and dialogue events

const DialogueSystem = (function() {
    let active = false;
    let currentTree = null;
    let currentNode = null;
    let currentNPC = null;
    let typingTimer = 0;
    let displayedChars = 0;
    let typingSpeed = 30; // chars per second
    let fullText = '';
    let onCompleteCallback = null;
    let choiceCallback = null;

    const TYPING_SPEED = 40;
    const FAST_TYPING = 120;

    // Dialogue UI elements (grabbed once)
    let uiElements = {};

    function initUI() {
        uiElements = {
            panel: document.getElementById('dialogue-panel'),
            portrait: document.getElementById('dialogue-portrait-canvas'),
            nameBox: document.getElementById('dialogue-name'),
            textBox: document.getElementById('dialogue-text'),
            choicesBox: document.getElementById('dialogue-choices'),
            continueHint: document.getElementById('dialogue-continue'),
        };
    }

    // Start a dialogue tree by ID
    function startDialogue(treeId, npc, onComplete) {
        initUI();
        const tree = DialoguesData.getTree(treeId);
        if (!tree) { console.warn('[DialogueSystem] Tree not found:', treeId); return; }
        if (active) endDialogue();

        active = true;
        currentTree = tree;
        currentNPC = npc;
        onCompleteCallback = onComplete || null;

        // Pause game state
        if (window.GameState) GameState.setPaused(true, 'dialogue');

        // Show panel
        if (uiElements.panel) {
            uiElements.panel.classList.add('open');
        }

        AudioSystem.playSFX('open_menu');
        EventSystem.emit(EventSystem.EVENTS.DIALOGUE_START, { treeId, npc });

        // Find and display start node
        const startNode = tree.nodes.find(n => n.id === (tree.startNode || 'start')) || tree.nodes[0];
        showNode(startNode);
    }

    function showNode(node) {
        if (!node) { endDialogue(); return; }
        currentNode = node;
        fullText = processText(node.text);
        displayedChars = 0;
        typingTimer = 0;
        typingSpeed = TYPING_SPEED;

        // Speaker name
        const speakerName = node.speaker || (currentNPC ? currentNPC.name : 'System');
        if (uiElements.nameBox) uiElements.nameBox.textContent = speakerName;

        // Clear choices while typing
        if (uiElements.choicesBox) {
            uiElements.choicesBox.innerHTML = '';
            uiElements.choicesBox.style.display = 'none';
        }
        if (uiElements.continueHint) uiElements.continueHint.style.display = 'none';
        if (uiElements.textBox) uiElements.textBox.textContent = '';

        // Draw portrait
        drawPortrait(node.speaker);

        // Trigger any node events
        if (node.event) triggerNodeEvent(node.event);
    }

    function processText(text) {
        if (!text) return '';
        // Replace player name
        const playerName = window.GameState ? GameState.player?.name || 'Kim Dokja' : 'Kim Dokja';
        return text.replace(/{player}/g, playerName).replace(/{name}/g, playerName);
    }

    function update(dt) {
        if (!active || !currentNode) return;
        // Typing effect
        if (displayedChars < fullText.length) {
            typingTimer += dt;
            const charsToShow = Math.floor(typingTimer * typingSpeed);
            if (charsToShow > displayedChars) {
                displayedChars = Math.min(fullText.length, charsToShow);
                if (uiElements.textBox) {
                    uiElements.textBox.textContent = fullText.slice(0, displayedChars);
                }
                // Play click sound occasionally
                if (displayedChars % 3 === 0) AudioSystem.playSFX('dialogue');
            }
        } else {
            // Typing complete - show choices or continue hint
            if (currentNode.choices && currentNode.choices.length > 0) {
                showChoices(currentNode.choices);
            } else if (uiElements.continueHint) {
                uiElements.continueHint.style.display = 'flex';
            }
        }
    }

    function advance() {
        if (!active) return;
        // If still typing, finish immediately
        if (displayedChars < fullText.length) {
            displayedChars = fullText.length;
            if (uiElements.textBox) uiElements.textBox.textContent = fullText;
            typingSpeed = FAST_TYPING;
            return;
        }
        // No choices - go to next node
        if (!currentNode.choices || currentNode.choices.length === 0) {
            const nextId = currentNode.next;
            if (!nextId || nextId === 'end') {
                endDialogue();
            } else {
                const nextNode = currentTree.nodes.find(n => n.id === nextId);
                showNode(nextNode);
            }
            AudioSystem.playSFX('click');
        }
    }

    function showChoices(choices) {
        if (!uiElements.choicesBox) return;
        uiElements.choicesBox.innerHTML = '';
        uiElements.choicesBox.style.display = 'flex';
        if (uiElements.continueHint) uiElements.continueHint.style.display = 'none';

        const filtered = choices.filter(c => {
            if (c.requireFlag && !QuestSystem.hasFlag(c.requireFlag)) return false;
            if (c.requireSkill && !SkillSystem.hasSkill(c.requireSkill)) return false;
            if (c.requireItem && !InventorySystem.hasItem(c.requireItem)) return false;
            return true;
        });

        filtered.forEach((choice, i) => {
            const btn = document.createElement('button');
            btn.className = 'dialogue-choice-btn';
            btn.textContent = choice.text;
            if (choice.skillCheck) {
                btn.textContent += ` [${choice.skillCheck}]`;
                btn.classList.add('skill-check');
            }
            btn.addEventListener('click', () => selectChoice(choice));
            btn.addEventListener('touchend', (e) => { e.preventDefault(); selectChoice(choice); });
            uiElements.choicesBox.appendChild(btn);
        });
    }

    function selectChoice(choice) {
        AudioSystem.playSFX('confirm');
        EventSystem.emit(EventSystem.EVENTS.DIALOGUE_CHOICE, {
            choiceId: choice.id,
            text: choice.text,
            npcId: currentNPC?.id
        });

        // Handle skill check
        if (choice.skillCheck) {
            const pass = performSkillCheck(choice.skillCheck, choice.skillCheckDC);
            const nextId = pass ? choice.nextPass : choice.nextFail;
            const nextNode = currentTree.nodes.find(n => n.id === nextId);
            showNode(nextNode || { id: 'end', text: 'The conversation ends.', speaker: 'System' });
            return;
        }

        // Trigger choice effects
        if (choice.setFlag) QuestSystem.setFlag(choice.setFlag, true);
        if (choice.giveItem) InventorySystem.addItem(choice.giveItem);
        if (choice.startQuest) QuestSystem.startQuest(choice.startQuest);
        if (choice.unlockSkill) SkillSystem.learnSkill(choice.unlockSkill);
        if (choice.affinity) applyAffinity(currentNPC?.id, choice.affinity);

        const nextId = choice.next;
        if (!nextId || nextId === 'end') {
            endDialogue();
        } else {
            const nextNode = currentTree.nodes.find(n => n.id === nextId);
            showNode(nextNode);
        }
    }

    function performSkillCheck(skillName, dc) {
        if (!window.GameState) return false;
        const player = GameState.player;
        if (!player) return false;
        const statMap = { persuasion: 'INT', deception: 'INT', intimidation: 'STR', perception: 'PER', stealth: 'AGI' };
        const stat = player.stats[statMap[skillName] || 'INT'] || 10;
        const roll = stat + Math.floor(Math.random() * 20);
        return roll >= (dc || 15);
    }

    function applyAffinity(npcId, amount) {
        if (!npcId || !window.CompanionSystem) return;
        CompanionSystem.addAffinity(npcId, amount);
    }

    function triggerNodeEvent(event) {
        switch(event.type) {
            case 'quest_start': QuestSystem.startQuest(event.data); break;
            case 'quest_complete': QuestSystem.completeQuest(event.data); break;
            case 'set_flag': QuestSystem.setFlag(event.data.key, event.data.value); break;
            case 'give_item': InventorySystem.addItem(event.data.itemId, event.data.quantity); break;
            case 'system_message': EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, event.data); break;
            case 'companion_join':
                if (window.CompanionSystem) CompanionSystem.addCompanion(event.data);
                break;
            case 'play_music': AudioSystem.playMusic(event.data); break;
        }
    }

    function drawPortrait(speakerName) {
        const canvas = uiElements.portrait;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width, h = canvas.height;
        ctx.clearRect(0, 0, w, h);

        // Gradient background
        const grd = ctx.createLinearGradient(0, 0, 0, h);
        grd.addColorStop(0, '#1a1a2e');
        grd.addColorStop(1, '#040408');
        ctx.fillStyle = grd;
        ctx.fillRect(0, 0, w, h);

        // Draw character based on name
        const colors = {
            'Kim Dokja': '#4a9eff', 'Yoo Jonghyuk': '#ff4444',
            'Lee Hyunsung': '#88aadd', 'Jung Heewon': '#ff8888',
            'Shin Yoosung': '#cc88ff', 'Han Sooyoung': '#ffcc00',
            'Bihyung': '#22cc88', 'System': '#888',
            default: '#cccccc'
        };
        const color = colors[speakerName] || colors.default;

        // Simple portrait silhouette
        ctx.fillStyle = color + '44';
        ctx.beginPath();
        ctx.arc(w/2, h * 0.4, w * 0.28, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.stroke();

        // Initial letter
        ctx.fillStyle = color;
        ctx.font = `bold ${Math.floor(w * 0.3)}px Cinzel, serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText((speakerName || '?').charAt(0).toUpperCase(), w/2, h * 0.4);

        // Glow
        ctx.shadowBlur = 20;
        ctx.shadowColor = color;
        ctx.strokeStyle = color + '88';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(w/2, h * 0.4, w * 0.3, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0;
    }

    function endDialogue() {
        active = false;
        currentTree = null;
        currentNode = null;
        if (uiElements.panel) uiElements.panel.classList.remove('open');
        if (window.GameState) GameState.setPaused(false, 'dialogue');
        EventSystem.emit(EventSystem.EVENTS.DIALOGUE_END, { npcId: currentNPC?.id });
        currentNPC = null;
        if (onCompleteCallback) {
            const cb = onCompleteCallback;
            onCompleteCallback = null;
            cb();
        }
    }

    // Quick conversation for simple NPCs without a full tree
    function quickTalk(npcId, lines, onComplete) {
        const npc = window.GameState?.world?.getNPC(npcId);
        const nodeTree = {
            id: 'quick_' + npcId,
            startNode: 'n0',
            nodes: lines.map((line, i) => ({
                id: `n${i}`,
                text: typeof line === 'string' ? line : line.text,
                speaker: typeof line === 'string' ? (npc?.name || 'NPC') : (line.speaker || npc?.name || 'NPC'),
                next: i < lines.length - 1 ? `n${i+1}` : 'end'
            }))
        };
        // Temporarily register this tree
        DialoguesData.registerTemp('quick_' + npcId, nodeTree);
        startDialogue('quick_' + npcId, npc, onComplete);
    }

    function isActive() { return active; }

    // Tap-to-advance (called from input)
    function onTap() { advance(); }

    return {
        initUI, startDialogue, endDialogue, quickTalk,
        update, advance, onTap, isActive
    };
})();
