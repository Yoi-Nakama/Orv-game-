// ORV Game - Companion System
// Manages party companions, AI behavior, affinity, follow and combat AI

const CompanionSystem = (function() {
    let companions = {};     // id -> companion entity
    let affinityMap = {};    // characterId -> affinity (0-100)
    let activeParty = [];    // ids currently following player (max 3)
    const MAX_PARTY = 3;
    const FOLLOW_DISTANCE = 80;
    const ATTACK_RANGE = 200;

    function init() {
        companions = {};
        affinityMap = {};
        activeParty = [];
    }

    function addCompanion(characterId, joinEvent) {
        const def = CharactersData.getCharacter(characterId);
        if (!def) return null;
        if (companions[characterId]) return companions[characterId]; // Already added

        const companion = createCompanionEntity(def);
        companions[characterId] = companion;

        if (activeParty.length < MAX_PARTY) activeParty.push(characterId);

        EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
            message: `${def.name} has joined your party!`,
            type: 'companion',
            duration: 4000
        });
        EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
            text: `[Companion Joined] ${def.name}`,
            subtext: def.joinDialogue || `${def.name} has decided to travel with you.`,
            type: 'companion'
        });
        return companion;
    }

    function createCompanionEntity(def) {
        const startPos = { x: 200, y: 300 };
        const stats = StatsSystem.createStats({
            STR: def.stats.STR || 10,
            AGI: def.stats.AGI || 10,
            END: def.stats.END || 10,
            INT: def.stats.INT || 10,
            LCK: def.stats.LCK || 5,
            PER: def.stats.PER || 5
        });
        StatsSystem.compute(stats, def.level || 1);
        stats.HP = stats.maxHP;
        stats.MP = stats.maxMP;
        stats.SP = stats.maxSP;

        return {
            id: def.id,
            name: def.name,
            type: def.id,
            x: startPos.x, y: startPos.y,
            width: 36, height: 48,
            stats,
            level: def.level || 1,
            class: def.class,
            skills: def.skills || [],
            state: 'follow',  // follow, combat, idle, dead
            target: null,
            vx: 0, vy: 0,
            facing: 1,
            attackCooldown: 0,
            skillCooldown: 0,
            animator: AnimationSystem.createAnimator(def.id, 'idle'),
            physBody: null,
            isCompanion: true,
            alive: true,
            deathTimer: 0,
            statusEffects: []
        };
    }

    function removeCompanion(characterId) {
        delete companions[characterId];
        activeParty = activeParty.filter(id => id !== characterId);
    }

    // Add/remove from active party
    function setInParty(characterId, inParty) {
        if (inParty) {
            if (!companions[characterId] || activeParty.length >= MAX_PARTY) return false;
            if (!activeParty.includes(characterId)) activeParty.push(characterId);
        } else {
            activeParty = activeParty.filter(id => id !== characterId);
        }
        return true;
    }

    function addAffinity(characterId, amount) {
        if (!affinityMap[characterId]) affinityMap[characterId] = 0;
        affinityMap[characterId] = Math.max(0, Math.min(100, affinityMap[characterId] + amount));
        checkAffinityThresholds(characterId);
    }

    function getAffinity(characterId) { return affinityMap[characterId] || 0; }

    function checkAffinityThresholds(characterId) {
        const aff = affinityMap[characterId];
        const def = CharactersData.getCharacter(characterId);
        if (!def || !def.affinityThresholds) return;
        def.affinityThresholds.forEach(thresh => {
            const flagKey = `affinity_${characterId}_${thresh.threshold}`;
            if (aff >= thresh.threshold && !QuestSystem.hasFlag(flagKey)) {
                QuestSystem.setFlag(flagKey, true);
                if (thresh.skill) SkillSystem.learnSkill(thresh.skill);
                if (thresh.dialogue) DialogueSystem.startDialogue(thresh.dialogue, companions[characterId]);
                EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
                    message: `${def.name} affinity increased!`,
                    type: 'affinity',
                    duration: 2500
                });
            }
        });
    }

    // Main AI update
    function update(dt, player, enemies) {
        activeParty.forEach(id => {
            const comp = companions[id];
            if (!comp) return;
            if (!comp.alive) {
                updateDead(comp, dt);
                return;
            }

            // Update cooldowns
            if (comp.attackCooldown > 0) comp.attackCooldown -= dt;
            if (comp.skillCooldown > 0) comp.skillCooldown -= dt;

            // Update animation
            AnimationSystem.update(comp.animator, dt);

            // State machine
            switch (comp.state) {
                case 'follow': updateFollowState(comp, dt, player, enemies); break;
                case 'combat': updateCombatState(comp, dt, player, enemies); break;
                case 'idle': break;
            }

            // Clamp position
            comp.x += comp.vx * dt;
            comp.y += comp.vy * dt;
            comp.vx *= 0.8;
            comp.vy *= 0.8;
        });
    }

    function updateFollowState(comp, dt, player, enemies) {
        if (!player) return;
        // Check for nearby enemies
        if (enemies) {
            const nearest = findNearestEnemy(comp, enemies, ATTACK_RANGE * 1.5);
            if (nearest) {
                comp.target = nearest;
                comp.state = 'combat';
                return;
            }
        }
        // Follow player
        const dx = (player.x + player.width/2) - (comp.x + comp.width/2);
        const dy = (player.y + player.height/2) - (comp.y + comp.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);
        const OFFSET = 50 + activeParty.indexOf(comp.id) * 30;
        if (dist > FOLLOW_DISTANCE) {
            const speed = Math.min(250, dist * 2);
            comp.vx = (dx / dist) * speed * 0.7;
            comp.vy = (dy / dist) * speed * 0.7;
            comp.facing = dx > 0 ? 1 : -1;
            comp.animator.flipX = comp.facing < 0;
            AnimationSystem.play(comp.animator, dist > 100 ? 'run' : 'walk');
        } else {
            AnimationSystem.play(comp.animator, 'idle');
        }
    }

    function updateCombatState(comp, dt, player, enemies) {
        // Validate target
        if (!comp.target || !comp.target.alive) {
            comp.target = enemies ? findNearestEnemy(comp, enemies, ATTACK_RANGE * 2) : null;
            if (!comp.target) { comp.state = 'follow'; return; }
        }
        // Move toward target
        const dx = (comp.target.x + comp.target.width/2) - (comp.x + comp.width/2);
        const dy = (comp.target.y + comp.target.height/2) - (comp.y + comp.height/2);
        const dist = Math.sqrt(dx*dx + dy*dy);
        comp.facing = dx > 0 ? 1 : -1;
        comp.animator.flipX = comp.facing < 0;

        const attackRange = 60;
        if (dist > attackRange) {
            comp.vx = (dx / dist) * 200;
            comp.vy = (dy / dist) * 200;
            AnimationSystem.play(comp.animator, 'run');
        } else {
            comp.vx = 0; comp.vy = 0;
            if (comp.attackCooldown <= 0) {
                performCompanionAttack(comp, comp.target);
                AnimationSystem.play(comp.animator, 'attack', true);
            } else {
                AnimationSystem.play(comp.animator, 'idle');
            }
        }
    }

    function performCompanionAttack(comp, target) {
        const dmg = Math.floor(comp.stats.ATK * (0.8 + Math.random() * 0.4));
        CombatSystem.applyDamage(target, dmg, 'physical', comp);
        comp.attackCooldown = 1.2;
        // Use skill occasionally
        if (comp.skillCooldown <= 0 && Math.random() < 0.3 && comp.skills.length > 0) {
            const skillId = comp.skills[Math.floor(Math.random() * comp.skills.length)];
            useCompanionSkill(comp, skillId, target);
        }
    }

    function useCompanionSkill(comp, skillId, target) {
        const def = SkillsData.getSkill(skillId);
        if (!def) return;
        if (comp.stats.MP < (def.mpCost || 0)) return;
        comp.stats.MP -= (def.mpCost || 0);
        comp.skillCooldown = def.cooldown || 8;
        const cx = comp.x + comp.width/2;
        const cy = comp.y + comp.height/2;
        ParticleSystem.emit(def.particleKey || 'hit_normal', cx, cy);
        if (def.damage && target) {
            const dmg = Math.floor((comp.stats.ATK + comp.stats.MATK) * 0.8);
            CombatSystem.applyDamage(target, dmg, def.damageType || 'physical', comp);
        }
    }

    function updateDead(comp, dt) {
        comp.deathTimer += dt;
        if (comp.deathTimer > 30) {
            // Revive with 1 HP after 30 seconds
            comp.alive = true;
            comp.deathTimer = 0;
            comp.state = 'follow';
            comp.stats.HP = Math.floor(comp.stats.maxHP * 0.1);
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
                message: `${comp.name} has recovered.`,
                type: 'companion',
                duration: 2000
            });
        }
    }

    function findNearestEnemy(comp, enemies, maxRange) {
        let nearest = null, minDist = maxRange * maxRange;
        enemies.forEach(enemy => {
            if (!enemy.alive) return;
            const dx = enemy.x - comp.x, dy = enemy.y - comp.y;
            const d2 = dx*dx + dy*dy;
            if (d2 < minDist) { minDist = d2; nearest = enemy; }
        });
        return nearest;
    }

    function draw(ctx) {
        activeParty.forEach(id => {
            const comp = companions[id];
            if (!comp) return;
            const alpha = comp.alive ? 1 : 0.4;
            ctx.globalAlpha = alpha;
            AnimationSystem.draw(ctx, comp.animator, comp.x, comp.y, comp.width, comp.height);

            // HP bar
            if (comp.alive && comp.stats.HP < comp.stats.maxHP) {
                const barW = comp.width;
                ctx.fillStyle = '#300';
                ctx.fillRect(comp.x, comp.y - 8, barW, 4);
                ctx.fillStyle = '#0f0';
                ctx.fillRect(comp.x, comp.y - 8, barW * StatsSystem.hpPercent(comp.stats), 4);
            }

            // Name label
            ctx.fillStyle = '#aaddff';
            ctx.font = '10px Rajdhani';
            ctx.textAlign = 'center';
            ctx.fillText(comp.name.split(' ')[0], comp.x + comp.width/2, comp.y - 12);
            ctx.globalAlpha = 1;
        });
    }

    function getActiveParty() { return activeParty.map(id => companions[id]).filter(Boolean); }
    function getCompanion(id) { return companions[id]; }
    function hasCompanion(id) { return !!companions[id]; }
    function isInParty(id) { return activeParty.includes(id); }

    function serialize() {
        const compData = {};
        Object.entries(companions).forEach(([id, c]) => {
            compData[id] = { stats: c.stats, level: c.level, alive: c.alive };
        });
        return { companions: compData, affinityMap, activeParty };
    }

    function deserialize(data) {
        if (!data) return;
        affinityMap = data.affinityMap || {};
        activeParty = data.activeParty || [];
        if (data.companions) {
            Object.entries(data.companions).forEach(([id, saved]) => {
                const def = CharactersData.getCharacter(id);
                if (def) {
                    const comp = createCompanionEntity(def);
                    Object.assign(comp.stats, saved.stats || {});
                    comp.level = saved.level || 1;
                    comp.alive = saved.alive !== false;
                    companions[id] = comp;
                }
            });
        }
    }

    return {
        init, addCompanion, removeCompanion, setInParty,
        addAffinity, getAffinity,
        update, draw,
        getActiveParty, getCompanion, hasCompanion, isInParty,
        serialize, deserialize
    };
})();
