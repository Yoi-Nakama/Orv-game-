// ORV Game - Stats System
// Manages base stats, modifiers, equipment bonuses, and derived values

const StatsSystem = (function() {
    // Create a fresh stats object for a character
    function createStats(base) {
        return {
            // Primary stats
            STR: base.STR || 5,
            AGI: base.AGI || 5,
            END: base.END || 5,
            INT: base.INT || 5,
            LCK: base.LCK || 5,
            PER: base.PER || 5,
            // Derived (computed)
            maxHP: 0, HP: 0,
            maxMP: 0, MP: 0,
            maxSP: 0, SP: 0,  // Stamina/Spirit
            ATK: 0, DEF: 0,
            MATK: 0, MDEF: 0,
            SPEED: 0, CRIT: 0, CRITDMG: 0,
            EVASION: 0, ACCURACY: 0, BLOCK: 0,
            // Flat modifiers (from equipment/buffs)
            mods: createMods(),
            // Multiplier modifiers
            multMods: createMultMods()
        };
    }

    function createMods() {
        return {
            STR: 0, AGI: 0, END: 0, INT: 0, LCK: 0, PER: 0,
            HP: 0, MP: 0, SP: 0,
            ATK: 0, DEF: 0, MATK: 0, MDEF: 0,
            SPEED: 0, CRIT: 0, CRITDMG: 0, EVASION: 0, ACCURACY: 0
        };
    }

    function createMultMods() {
        return {
            HP: 1, MP: 1, ATK: 1, DEF: 1, MATK: 1, MDEF: 1,
            SPEED: 1, CRIT: 1, CRITDMG: 1, EXP: 1
        };
    }

    // Compute all derived stats from base + modifiers
    function compute(stats, level) {
        const lvl = level || 1;
        const S = stats;
        const M = S.mods;
        const X = S.multMods;

        // Effective primary stats
        const effSTR = S.STR + M.STR;
        const effAGI = S.AGI + M.AGI;
        const effEND = S.END + M.END;
        const effINT = S.INT + M.INT;
        const effLCK = S.LCK + M.LCK;
        const effPER = S.PER + M.PER;

        // Derived formulas (ORV-inspired)
        S.maxHP = Math.floor((100 + effEND * 15 + lvl * 10 + M.HP) * X.HP);
        S.maxMP = Math.floor((50 + effINT * 10 + effLCK * 2 + M.MP) * X.MP);
        S.maxSP = Math.floor((80 + effEND * 8 + effAGI * 5 + M.SP));
        S.ATK = Math.floor((effSTR * 3 + lvl * 2 + M.ATK) * X.ATK);
        S.DEF = Math.floor((effEND * 2 + effSTR * 0.5 + M.DEF) * X.DEF);
        S.MATK = Math.floor((effINT * 4 + effPER * 1 + M.MATK) * X.MATK);
        S.MDEF = Math.floor((effINT * 1.5 + effEND * 0.5 + M.MDEF) * X.MDEF);
        S.SPEED = Math.floor((effAGI * 2.5 + effPER * 0.5 + M.SPEED) * X.SPEED);
        S.CRIT = Math.min(95, Math.floor((effLCK * 0.5 + effPER * 0.3 + M.CRIT) * X.CRIT));
        S.CRITDMG = Math.floor((150 + effSTR * 0.5 + effLCK * 0.5 + M.CRITDMG) * (X.CRITDMG || 1));
        S.EVASION = Math.min(80, Math.floor(effAGI * 0.4 + effPER * 0.2 + M.EVASION));
        S.ACCURACY = Math.floor(80 + effPER * 0.5 + effAGI * 0.2 + M.ACCURACY);
        S.BLOCK = Math.floor(effEND * 0.3);

        return S;
    }

    // Clamp HP/MP/SP to their max values
    function clamp(stats) {
        if (stats.HP > stats.maxHP) stats.HP = stats.maxHP;
        if (stats.HP < 0) stats.HP = 0;
        if (stats.MP > stats.maxMP) stats.MP = stats.maxMP;
        if (stats.MP < 0) stats.MP = 0;
        if (stats.SP > stats.maxSP) stats.SP = stats.maxSP;
        if (stats.SP < 0) stats.SP = 0;
    }

    // Apply buff/debuff modifier
    function addMod(stats, key, value) {
        if (stats.mods.hasOwnProperty(key)) {
            stats.mods[key] += value;
        }
    }

    function removeMod(stats, key, value) {
        if (stats.mods.hasOwnProperty(key)) {
            stats.mods[key] -= value;
        }
    }

    function addMultMod(stats, key, multiplier) {
        if (stats.multMods.hasOwnProperty(key)) {
            stats.multMods[key] *= multiplier;
        }
    }

    function removeMultMod(stats, key, multiplier) {
        if (stats.multMods.hasOwnProperty(key) && multiplier !== 0) {
            stats.multMods[key] /= multiplier;
        }
    }

    // --- Leveling ---
    function expToLevel(level) {
        return Math.floor(GameConfig.leveling.baseExp * Math.pow(GameConfig.leveling.expMultiplier, level - 1));
    }

    function levelToExp(level) {
        // Total exp required to reach this level
        let total = 0;
        for (let i = 1; i < level; i++) total += expToLevel(i);
        return total;
    }

    function getStatGainsForLevel(entityClass) {
        const gains = GameConfig.leveling.statGainsPerLevel;
        return gains[entityClass] || gains.default;
    }

    function applyLevelUp(stats, level, entityClass) {
        const gains = getStatGainsForLevel(entityClass);
        stats.STR += gains.STR || 0;
        stats.AGI += gains.AGI || 0;
        stats.END += gains.END || 0;
        stats.INT += gains.INT || 0;
        stats.LCK += gains.LCK || 0;
        stats.PER += gains.PER || 0;
        compute(stats, level);
        // Restore HP/MP/SP on level up
        stats.HP = stats.maxHP;
        stats.MP = stats.maxMP;
        stats.SP = stats.maxSP;
        return stats;
    }

    // --- Regen ---
    function applyRegen(stats, dt) {
        if (stats.HP > 0) {
            const hpRegen = stats.maxHP * GameConfig.combat.hpRegenRate * dt;
            const mpRegen = stats.maxMP * GameConfig.combat.mpRegenRate * dt;
            const spRegen = stats.maxSP * GameConfig.combat.spRegenRate * dt;
            stats.HP = Math.min(stats.maxHP, stats.HP + hpRegen);
            stats.MP = Math.min(stats.maxMP, stats.MP + mpRegen);
            stats.SP = Math.min(stats.maxSP, stats.SP + spRegen);
        }
    }

    // Get HP percentage
    function hpPercent(stats) {
        return stats.maxHP > 0 ? stats.HP / stats.maxHP : 0;
    }
    function mpPercent(stats) {
        return stats.maxMP > 0 ? stats.MP / stats.maxMP : 0;
    }
    function spPercent(stats) {
        return stats.maxSP > 0 ? stats.SP / stats.maxSP : 0;
    }

    // Get grade from stats/level (ORV grades)
    function getGrade(level) {
        if (level >= 90) return 'SS';
        if (level >= 75) return 'S';
        if (level >= 60) return 'A+';
        if (level >= 50) return 'A';
        if (level >= 40) return 'B+';
        if (level >= 30) return 'B';
        if (level >= 20) return 'C';
        if (level >= 10) return 'D';
        if (level >= 5) return 'E';
        return 'F';
    }

    // Build enemy stats from EnemiesData definition
    function buildEnemyStats(enemyDef, level) {
        const s = createStats({
            STR: enemyDef.stats?.STR || 10,
            AGI: enemyDef.stats?.AGI || 8,
            END: enemyDef.stats?.END || 8,
            INT: enemyDef.stats?.INT || 5,
            LCK: enemyDef.stats?.LCK || 3,
            PER: enemyDef.stats?.PER || 5
        });
        compute(s, level || 1);
        // Override with explicit HP/ATK if defined
        if (enemyDef.stats?.HP) s.maxHP = enemyDef.stats.HP;
        if (enemyDef.stats?.ATK) s.ATK = enemyDef.stats.ATK;
        if (enemyDef.stats?.DEF) s.DEF = enemyDef.stats.DEF;
        s.HP = s.maxHP;
        s.MP = s.maxMP;
        s.SP = s.maxSP;
        return s;
    }

    return {
        createStats, compute, clamp,
        addMod, removeMod, addMultMod, removeMultMod,
        expToLevel, levelToExp, getStatGainsForLevel, applyLevelUp,
        applyRegen, hpPercent, mpPercent, spPercent,
        getGrade, buildEnemyStats, createMods, createMultMods
    };
})();
