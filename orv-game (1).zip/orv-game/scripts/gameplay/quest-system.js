// ORV Game - Quest System
// Manages quest tracking, objectives, completion states, and rewards

const QuestSystem = (function() {
    let activeQuests = {};    // questId -> quest state
    let completedQuests = {};
    let failedQuests = {};
    let questFlags = {};      // Global flags for quest conditions

    function init() {
        activeQuests = {};
        completedQuests = {};
        failedQuests = {};
        questFlags = {};
        // Bind events
        bindEvents();
    }

    function bindEvents() {
        EventSystem.on(EventSystem.EVENTS.COMBAT_KILL, (data) => {
            if (data.enemy) checkKillObjectives(data.enemy.id || data.enemy.type);
        });
        EventSystem.on(EventSystem.EVENTS.ZONE_ENTER, (data) => {
            checkLocationObjectives(data.zoneId);
            checkTriggerObjectives('enter_zone', data.zoneId);
        });
        EventSystem.on(EventSystem.EVENTS.ITEM_PICKUP, (data) => {
            checkItemObjectives(data.itemId, data.quantity);
        });
        EventSystem.on(EventSystem.EVENTS.DIALOGUE_END, (data) => {
            checkTriggerObjectives('talk_to', data.npcId);
        });
        EventSystem.on(EventSystem.EVENTS.BOSS_DEATH, (data) => {
            checkKillObjectives(data.bossId);
            setFlag(`boss_killed_${data.bossId}`, true);
        });
        EventSystem.on(EventSystem.EVENTS.SCENARIO_CLEAR, (data) => {
            setFlag(`scenario_cleared_${data.scenarioId}`, true);
            checkTriggerObjectives('clear_scenario', data.scenarioId);
        });
    }

    // Start a quest
    function startQuest(questId) {
        if (activeQuests[questId] || completedQuests[questId]) return false;
        const def = QuestsData.getQuest(questId);
        if (!def) { console.warn('[QuestSystem] Unknown quest:', questId); return false; }

        // Check requirements
        if (!meetsRequirements(def.requirements)) return false;

        activeQuests[questId] = {
            id: questId,
            startTime: Date.now(),
            objectives: {},
            currentStage: 0
        };

        // Initialize objective counters
        if (def.objectives) {
            def.objectives.forEach(obj => {
                activeQuests[questId].objectives[obj.id] = {
                    current: 0,
                    required: obj.required || 1,
                    completed: false,
                    type: obj.type,
                    target: obj.target
                };
            });
        }

        EventSystem.emit(EventSystem.EVENTS.QUEST_START, { questId, def });
        EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
            text: `[Quest Started] ${def.name}`,
            subtext: def.description,
            type: 'quest'
        });
        EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
            message: `New Quest: ${def.name}`,
            type: 'quest',
            duration: 3000
        });
        updateQuestUI();
        return true;
    }

    // Update objective progress
    function updateObjective(questId, objectiveId, amount) {
        if (!activeQuests[questId]) return;
        const quest = activeQuests[questId];
        const def = QuestsData.getQuest(questId);
        const obj = quest.objectives[objectiveId];
        if (!obj || obj.completed) return;

        obj.current = Math.min(obj.required, obj.current + (amount || 1));

        EventSystem.emit(EventSystem.EVENTS.QUEST_UPDATE, { questId, objectiveId, current: obj.current, required: obj.required });

        if (obj.current >= obj.required) {
            obj.completed = true;
            const objDef = def.objectives.find(o => o.id === objectiveId);
            EventSystem.emit(EventSystem.EVENTS.OBJECTIVE_COMPLETE, { questId, objectiveId, label: objDef?.label });
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
                message: `Objective complete: ${objDef?.label || objectiveId}`,
                type: 'objective',
                duration: 2500
            });
            // Check if all objectives done
            checkQuestCompletion(questId);
        }
        updateQuestUI();
    }

    function checkQuestCompletion(questId) {
        const quest = activeQuests[questId];
        if (!quest) return;
        const allDone = Object.values(quest.objectives).every(o => o.completed);
        if (allDone) completeQuest(questId);
    }

    function completeQuest(questId) {
        if (!activeQuests[questId]) return false;
        const def = QuestsData.getQuest(questId);
        completedQuests[questId] = { ...activeQuests[questId], completedTime: Date.now() };
        delete activeQuests[questId];

        // Grant rewards
        if (def.rewards) grantRewards(def.rewards);

        EventSystem.emit(EventSystem.EVENTS.QUEST_COMPLETE, { questId, def });
        EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
            text: `[Quest Completed] ${def.name}`,
            subtext: def.completionText || 'Quest objectives fulfilled.',
            type: 'quest_complete'
        });
        EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
            message: `Quest Complete: ${def.name}`,
            type: 'quest_complete',
            duration: 4000
        });

        // Unlock follow-up quests
        if (def.unlocks) {
            def.unlocks.forEach(qid => {
                if (QuestsData.getQuest(qid)) startQuest(qid);
            });
        }

        setFlag(`quest_complete_${questId}`, true);
        updateQuestUI();
        return true;
    }

    function failQuest(questId, reason) {
        if (!activeQuests[questId]) return false;
        const def = QuestsData.getQuest(questId);
        failedQuests[questId] = { ...activeQuests[questId], failedTime: Date.now(), reason };
        delete activeQuests[questId];

        EventSystem.emit(EventSystem.EVENTS.QUEST_FAIL, { questId, def, reason });
        EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
            message: `Quest Failed: ${def.name}`,
            type: 'quest_fail',
            duration: 3000
        });
        setFlag(`quest_failed_${questId}`, true);
        updateQuestUI();
        return true;
    }

    function grantRewards(rewards) {
        if (rewards.exp) {
            if (window.GameState && GameState.player) {
                GameState.player.gainExp(rewards.exp);
            }
        }
        if (rewards.gold) InventorySystem.addGold(rewards.gold);
        if (rewards.coins) InventorySystem.addDokkaebiCoins(rewards.coins);
        if (rewards.items) {
            rewards.items.forEach(item => {
                InventorySystem.addItem(item.itemId || item, item.quantity || 1);
            });
        }
        if (rewards.skills) {
            rewards.skills.forEach(sid => SkillSystem.learnSkill(sid));
        }
        if (rewards.title) {
            if (window.GameState && GameState.player) {
                GameState.player.addTitle(rewards.title);
            }
        }
    }

    // Objective check helpers
    function checkKillObjectives(enemyId) {
        Object.keys(activeQuests).forEach(questId => {
            const def = QuestsData.getQuest(questId);
            if (!def) return;
            def.objectives.forEach(obj => {
                if (obj.type === 'kill' && (obj.target === enemyId || obj.target === 'any')) {
                    updateObjective(questId, obj.id, 1);
                }
            });
        });
    }

    function checkLocationObjectives(zoneId) {
        Object.keys(activeQuests).forEach(questId => {
            const def = QuestsData.getQuest(questId);
            if (!def) return;
            def.objectives.forEach(obj => {
                if (obj.type === 'reach' && obj.target === zoneId) {
                    updateObjective(questId, obj.id);
                }
            });
        });
    }

    function checkItemObjectives(itemId, quantity) {
        Object.keys(activeQuests).forEach(questId => {
            const def = QuestsData.getQuest(questId);
            if (!def) return;
            def.objectives.forEach(obj => {
                if (obj.type === 'collect' && obj.target === itemId) {
                    updateObjective(questId, obj.id, quantity || 1);
                }
            });
        });
    }

    function checkTriggerObjectives(type, target) {
        Object.keys(activeQuests).forEach(questId => {
            const def = QuestsData.getQuest(questId);
            if (!def) return;
            def.objectives.forEach(obj => {
                if (obj.type === type && (obj.target === target || obj.target === 'any')) {
                    updateObjective(questId, obj.id);
                }
            });
        });
    }

    // Flag system
    function setFlag(key, value) { questFlags[key] = value; }
    function getFlag(key) { return questFlags[key]; }
    function hasFlag(key) { return questFlags.hasOwnProperty(key) && questFlags[key]; }

    function meetsRequirements(reqs) {
        if (!reqs) return true;
        if (reqs.level && window.GameState && GameState.player?.level < reqs.level) return false;
        if (reqs.questComplete && !completedQuests[reqs.questComplete]) return false;
        if (reqs.flag && !hasFlag(reqs.flag)) return false;
        return true;
    }

    // Get active quest info for HUD tracker
    function getActiveQuestSummary() {
        return Object.keys(activeQuests).map(qid => {
            const def = QuestsData.getQuest(qid);
            const state = activeQuests[qid];
            return {
                id: qid,
                name: def.name,
                objectives: def.objectives.map(obj => ({
                    label: obj.label,
                    current: state.objectives[obj.id]?.current || 0,
                    required: obj.required || 1,
                    completed: state.objectives[obj.id]?.completed || false
                }))
            };
        });
    }

    function updateQuestUI() {
        EventSystem.emit(EventSystem.EVENTS.HUD_UPDATE, { type: 'quests' });
    }

    function isActive(questId) { return !!activeQuests[questId]; }
    function isCompleted(questId) { return !!completedQuests[questId]; }
    function isFailed(questId) { return !!failedQuests[questId]; }
    function getActiveQuests() { return { ...activeQuests }; }
    function getCompletedQuests() { return { ...completedQuests }; }

    function serialize() {
        return { activeQuests, completedQuests, failedQuests, questFlags };
    }

    function deserialize(data) {
        if (!data) return;
        activeQuests = data.activeQuests || {};
        completedQuests = data.completedQuests || {};
        failedQuests = data.failedQuests || {};
        questFlags = data.questFlags || {};
        updateQuestUI();
    }

    return {
        init, startQuest, updateObjective, completeQuest, failQuest,
        setFlag, getFlag, hasFlag, isActive, isCompleted, isFailed,
        getActiveQuests, getCompletedQuests, getActiveQuestSummary,
        checkKillObjectives, checkTriggerObjectives,
        serialize, deserialize
    };
})();
