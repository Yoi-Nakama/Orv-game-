// ORV Game - Skill System
// Manages player/companion skills, cooldowns, upgrades, passive effects

const SkillSystem = (function() {
    let knownSkills = {};   // skillId -> { level, cooldownTimer, unlocked }
    let skillSlots = [null, null, null, null, null]; // HUD skill bar
    let passives = [];       // Active passive skill ids

    function init() {
        knownSkills = {};
        skillSlots = [null, null, null, null, null];
        passives = [];
    }

    // Learn a new skill
    function learnSkill(skillId) {
        if (knownSkills[skillId]) {
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, { message: 'Skill already known.', type: 'info' });
            return false;
        }
        const def = SkillsData.getSkill(skillId);
        if (!def) { console.warn('[SkillSystem] Unknown skill:', skillId); return false; }

        knownSkills[skillId] = { level: 1, cooldownTimer: 0, unlocked: true };

        // Passive skills activate automatically
        if (def.type === 'passive') passives.push(skillId);

        // Auto-assign to first empty slot
        const emptySlot = skillSlots.findIndex(s => s === null);
        if (emptySlot !== -1 && def.type !== 'passive') {
            skillSlots[emptySlot] = skillId;
        }

        EventSystem.emit(EventSystem.EVENTS.SKILL_UNLOCK, { skillId, def });
        EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
            message: `Learned: ${def.name}`,
            type: 'skill',
            duration: 3000
        });
        AudioSystem.playSFX('skill');
        updateHUD();
        return true;
    }

    // Upgrade a skill
    function upgradeSkill(skillId) {
        if (!knownSkills[skillId]) return false;
        const def = SkillsData.getSkill(skillId);
        if (!def) return false;
        const current = knownSkills[skillId];
        const maxLevel = def.upgrades ? def.upgrades.length + 1 : 5;
        if (current.level >= maxLevel) {
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, { message: 'Skill at max level!', type: 'info' });
            return false;
        }
        current.level++;
        EventSystem.emit(EventSystem.EVENTS.SKILL_UPGRADE, { skillId, level: current.level });
        EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
            message: `${def.name} upgraded to Lv.${current.level}!`,
            type: 'skill',
            duration: 2500
        });
        return true;
    }

    // Use a skill
    function useSkill(skillId, caster, targets, worldX, worldY) {
        if (!knownSkills[skillId]) return false;
        const state = knownSkills[skillId];
        if (!state.unlocked) return false;
        const def = SkillsData.getSkill(skillId);
        if (!def) return false;

        // Check cooldown
        if (state.cooldownTimer > 0) {
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, {
                message: `${def.name} not ready! (${state.cooldownTimer.toFixed(1)}s)`,
                type: 'warning',
                duration: 1000
            });
            return false;
        }

        // Check MP cost
        const mpCost = getSkillMPCost(def, state.level);
        if (caster.stats && caster.stats.MP < mpCost) {
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, { message: 'Not enough MP!', type: 'warning' });
            return false;
        }

        // Check SP cost
        const spCost = def.spCost || 0;
        if (caster.stats && caster.stats.SP < spCost) {
            EventSystem.emit(EventSystem.EVENTS.UI_NOTIFICATION, { message: 'Not enough Stamina!', type: 'warning' });
            return false;
        }

        // Deduct resources
        if (caster.stats) {
            caster.stats.MP -= mpCost;
            caster.stats.SP -= spCost;
        }

        // Execute skill
        executeSkill(def, state.level, caster, targets, worldX, worldY);

        // Set cooldown
        const cd = getSkillCooldown(def, state.level);
        state.cooldownTimer = cd;

        EventSystem.emit(EventSystem.EVENTS.PLAYER_SKILL_USE, { skillId, def, level: state.level });
        EventSystem.emit(EventSystem.EVENTS.SKILL_COOLDOWN_START, { skillId, duration: cd });
        updateHUD();
        return true;
    }

    function executeSkill(def, level, caster, targets, worldX, worldY) {
        const cx = caster.x + (caster.width || 32) / 2;
        const cy = caster.y + (caster.height || 32) / 2;

        // Particles
        const particleKey = def.particleKey || 'skill_fire';
        ParticleSystem.emit(particleKey, cx, cy);

        // Sound
        AudioSystem.playSFX('skill');

        // Combat effects
        if (def.damage && targets) {
            const targetsArr = Array.isArray(targets) ? targets : [targets];
            targetsArr.forEach(target => {
                if (!target || target === caster) return;
                const dmg = evalDamageFormula(def.damage, caster, target, level);
                CombatSystem.applyDamage(target, dmg, def.damageType || 'physical', caster);
            });
        }

        // Area damage
        if (def.aoeRadius && window.GameState) {
            const radius = def.aoeRadius;
            const allEnemies = GameState.world ? GameState.world.getEnemiesInRadius(cx, cy, radius) : [];
            allEnemies.forEach(enemy => {
                const dmg = evalDamageFormula(def.damage, caster, enemy, level);
                CombatSystem.applyDamage(enemy, dmg, def.damageType || 'physical', caster);
            });
            ParticleSystem.emit(particleKey, cx, cy, { spread: radius * 0.5, count: 20 });
        }

        // Heal effect
        if (def.heal) {
            const healAmt = evalHealFormula(def.heal, caster, level);
            caster.stats.HP = Math.min(caster.stats.maxHP, caster.stats.HP + healAmt);
            ParticleSystem.emit('heal', cx, cy);
            ParticleSystem.emitText(`+${Math.floor(healAmt)}`, cx, cy - 20, '#00ff88', 18);
        }

        // Status effect on targets
        if (def.statusApply && targets) {
            const t = Array.isArray(targets) ? targets : [targets];
            t.forEach(target => {
                if (target) CombatSystem.applyStatus(target, def.statusApply, def.statusDuration || 3);
            });
        }

        // Special skill effects
        if (def.special) {
            handleSpecialSkill(def.special, caster, targets, level);
        }

        // Camera shake for powerful skills
        if (def.cameraShake) {
            CameraSystem.shake(def.cameraShake.magnitude || 5, def.cameraShake.duration || 0.3);
        }
    }

    function handleSpecialSkill(special, caster, targets, level) {
        switch(special) {
            case 'fourth_wall':
                // Kim Dokja's unique skill - absorbs narrative damage
                CombatSystem.applyBuff(caster, {
                    id: 'fourth_wall',
                    name: 'Fourth Wall',
                    damageAbsorb: 0.5,
                    duration: 10
                });
                ParticleSystem.emit('fourth_wall', caster.x + 16, caster.y + 16, { count: 30 });
                EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
                    text: "Kim Dokja's Fourth Wall skill activates. The narrative itself becomes a shield.",
                    type: 'skill'
                });
                break;
            case 'three_ways_to_survive':
                // Ultimate skill - temporary omniscience
                CombatSystem.applyBuff(caster, {
                    id: 'omniscience',
                    name: 'Three Ways to Survive',
                    atkMultiplier: 2.0,
                    speedMultiplier: 2.0,
                    invincible: true,
                    duration: 30
                });
                CameraSystem.shake(15, 1.0);
                EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
                    text: "Three Ways to Survive. The scenario that Kim Dokja has read a thousand times.",
                    type: 'ultimate'
                });
                break;
            case 'regression_memory':
                // Yoo Jonghyuk - gains power from memories
                CombatSystem.applyBuff(caster, {
                    id: 'regression_power',
                    name: 'Regression Memory',
                    atkMultiplier: 1.5 + level * 0.1,
                    duration: 15
                });
                break;
            case 'prophecy':
                // Reveals enemy weaknesses
                if (window.GameState && GameState.combatTarget) {
                    GameState.combatTarget.weaknessRevealed = true;
                }
                break;
        }
    }

    function evalDamageFormula(formula, caster, target, level) {
        if (!formula) return 0;
        if (typeof formula === 'number') return formula;
        try {
            const ATK = caster.stats ? caster.stats.ATK : 10;
            const MATK = caster.stats ? caster.stats.MATK : 10;
            const INT = caster.stats ? caster.stats.INT : 10;
            const STR = caster.stats ? caster.stats.STR : 10;
            const LVL = level || 1;
            return Math.max(1, Math.floor(eval(formula)));
        } catch(e) { return 10; }
    }

    function evalHealFormula(formula, caster, level) {
        if (!formula) return 0;
        if (typeof formula === 'number') return formula;
        try {
            const maxHP = caster.stats ? caster.stats.maxHP : 100;
            const INT = caster.stats ? caster.stats.INT : 10;
            const LVL = level || 1;
            return Math.max(1, Math.floor(eval(formula)));
        } catch(e) { return 10; }
    }

    function getSkillMPCost(def, level) {
        const base = def.mpCost || 0;
        const reduction = (level - 1) * 2;
        return Math.max(0, base - reduction);
    }

    function getSkillCooldown(def, level) {
        const base = def.cooldown || 0;
        const reduction = (level - 1) * 0.5;
        return Math.max(0.5, base - reduction);
    }

    // Update cooldown timers
    function update(dt) {
        Object.values(knownSkills).forEach((state, idx) => {
            if (state.cooldownTimer > 0) {
                state.cooldownTimer -= dt;
                if (state.cooldownTimer <= 0) {
                    state.cooldownTimer = 0;
                    // Find skill id
                    const skillId = Object.keys(knownSkills)[idx];
                    EventSystem.emit(EventSystem.EVENTS.SKILL_COOLDOWN_END, { skillId });
                }
            }
        });
        updateHUDCooldowns();
    }

    function updateHUD() {
        // Update skill bar UI
        skillSlots.forEach((skillId, i) => {
            const el = document.getElementById(`skill-slot-${i + 1}`);
            if (!el) return;
            if (skillId) {
                const def = SkillsData.getSkill(skillId);
                if (def) {
                    el.querySelector('.skill-icon')?.setAttribute('data-skill', skillId);
                    el.querySelector('.skill-name')?.textContent && (el.querySelector('.skill-name').textContent = def.name.slice(0, 8));
                }
            }
        });
    }

    function updateHUDCooldowns() {
        skillSlots.forEach((skillId, i) => {
            if (!skillId) return;
            const state = knownSkills[skillId];
            if (!state) return;
            const el = document.getElementById(`skill-slot-${i + 1}`);
            if (!el) return;
            const cdOverlay = el.querySelector('.skill-cd');
            if (cdOverlay) {
                if (state.cooldownTimer > 0) {
                    const def = SkillsData.getSkill(skillId);
                    const maxCd = getSkillCooldown(def, state.level);
                    cdOverlay.style.display = 'flex';
                    cdOverlay.textContent = state.cooldownTimer.toFixed(1);
                    el.style.setProperty('--cd-progress', `${(state.cooldownTimer / maxCd) * 100}%`);
                } else {
                    cdOverlay.style.display = 'none';
                }
            }
        });
    }

    function setSkillSlot(slotIndex, skillId) {
        if (slotIndex < 0 || slotIndex >= skillSlots.length) return;
        skillSlots[slotIndex] = skillId;
        updateHUD();
    }

    function getKnownSkills() { return { ...knownSkills }; }
    function getSkillSlots() { return skillSlots.slice(); }
    function hasSkill(skillId) { return !!knownSkills[skillId]; }
    function getSkillLevel(skillId) { return knownSkills[skillId]?.level || 0; }
    function getPassives() { return passives.slice(); }
    function getCooldownTimer(skillId) { return knownSkills[skillId]?.cooldownTimer || 0; }

    // Get passive bonuses (called by stats system)
    function getPassiveBonuses() {
        const bonuses = {};
        passives.forEach(skillId => {
            const def = SkillsData.getSkill(skillId);
            const lvl = knownSkills[skillId]?.level || 1;
            if (def && def.passiveBonus) {
                Object.entries(def.passiveBonus).forEach(([key, val]) => {
                    bonuses[key] = (bonuses[key] || 0) + val * lvl;
                });
            }
        });
        return bonuses;
    }

    // Give starting skills based on character class
    function initStartingSkills(characterClass) {
        const startSkills = {
            reader: ['basic_attack', 'prophecy_of_the_reader', 'calm_mindset', 'fourth_wall'],
            regressor: ['basic_attack', 'regression_memory', 'steel_constitution'],
            warrior: ['basic_attack', 'power_strike', 'shield_wall'],
            swordsman: ['basic_attack', 'power_strike', 'dodge_roll'],
            default: ['basic_attack', 'dodge_roll']
        };
        const skills = startSkills[characterClass] || startSkills.default;
        skills.forEach(sid => learnSkill(sid));
    }

    function serialize() {
        return { knownSkills, skillSlots, passives };
    }

    function deserialize(data) {
        if (!data) return;
        knownSkills = data.knownSkills || {};
        skillSlots = data.skillSlots || [null, null, null, null, null];
        passives = data.passives || [];
        updateHUD();
    }

    return {
        init, learnSkill, upgradeSkill, useSkill, update,
        setSkillSlot, getKnownSkills, getSkillSlots,
        hasSkill, getSkillLevel, getPassives, getCooldownTimer,
        getPassiveBonuses, initStartingSkills,
        serialize, deserialize
    };
})();
