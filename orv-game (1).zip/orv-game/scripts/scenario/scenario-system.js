// ORV Game - Scenario System
// Manages active scenario state, objectives, timers, and scenario events

const ScenarioSystem = (function() {
    let currentScenario = null;
    let completedScenarios = [];
    let scenarioTimer = null;
    let scenarioTimerEl = null;

    function init() {
        currentScenario = null;
        completedScenarios = [];
        scenarioTimerEl = document.getElementById('scenario-timer');
    }

    function startScenario(scenarioId) {
        const def = ScenariosData.getScenario(scenarioId);
        if (!def) { console.warn('[ScenarioSystem] Unknown scenario:', scenarioId); return false; }
        if (completedScenarios.includes(scenarioId)) {
            console.log('[ScenarioSystem] Already completed:', scenarioId);
        }

        currentScenario = {
            id: scenarioId,
            def,
            startTime: Date.now(),
            objectives: {},
            hiddenObjectives: {},
            timeLimit: def.timeLimit || null,
            timeElapsed: 0,
            cleared: false
        };

        // Init objectives — handle both 'required' and 'total' field names
        def.objectives.forEach(obj => {
            currentScenario.objectives[obj.id] = {
                ...obj,
                current: obj.progress || 0,
                completed: false,
                required: obj.required || obj.total || 1
            };
        });
        if (def.hiddenObjectives) {
            def.hiddenObjectives.forEach(obj => {
                currentScenario.hiddenObjectives[obj.id] = {
                    ...obj,
                    current: obj.progress || 0,
                    completed: false,
                    required: obj.required || obj.total || 1
                };
            });
        }

        // Show scenario start screen
        showScenarioStart(def);

        EventSystem.emit(EventSystem.EVENTS.SCENARIO_START, { scenarioId, def });

        // Spawn scenario enemies
        if (def.enemySpawns) {
            setTimeout(() => {
                def.enemySpawns.forEach(spawn => {
                    for (let i = 0; i < (spawn.count || 1); i++) {
                        WorldSystem.spawnEnemy(spawn.enemyId,
                            spawn.x + (Math.random()-0.5)*80,
                            spawn.y + (Math.random()-0.5)*80
                        );
                    }
                });
            }, 2000);
        }

        // Spawn boss if scenario has one — support both 'bossFight' and 'boss' fields
        const bossId = def.bossFight?.bossId || def.boss;
        if (bossId) {
            const bossX = def.bossFight?.x || 600;
            const bossY = def.bossFight?.y || 300;
            const bossDelay = def.bossFight?.delay || 5000;
            setTimeout(() => {
                WorldSystem.spawnBoss(bossId, bossX, bossY);
            }, bossDelay);
        }

        // Story events
        if (def.storyEvents) {
            def.storyEvents.forEach(event => {
                setTimeout(() => triggerStoryEvent(event), (event.delay || 0) * 1000);
            });
        }

        return true;
    }

    function showScenarioStart(def) {
        const overlay = document.getElementById('scenario-start');
        if (!overlay) return;
        const title = overlay.querySelector('.scenario-title');
        const desc = overlay.querySelector('.scenario-desc');
        const grade = overlay.querySelector('.scenario-grade');
        if (title) title.textContent = def.name;
        if (desc) desc.textContent = def.systemMessage || def.description;
        if (grade) grade.textContent = def.difficulty || '';
        overlay.classList.add('show');
        setTimeout(() => overlay.classList.remove('show'), 4000);
    }

    function triggerStoryEvent(event) {
        switch(event.type) {
            case 'system_message':
                EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
                    text: event.text,
                    subtext: event.subtext,
                    type: event.style || 'system'
                });
                break;
            case 'dialogue':
                if (event.treeId) DialogueSystem.startDialogue(event.treeId, null);
                break;
            case 'spawn_enemy':
                WorldSystem.spawnEnemy(event.enemyId, event.x, event.y);
                break;
            case 'spawn_boss':
                WorldSystem.spawnBoss(event.bossId, event.x, event.y);
                break;
            case 'cutscene':
                if (window.StorySystem) StorySystem.playCutscene(event.cutsceneId);
                break;
            case 'music':
                AudioSystem.playMusic(event.track);
                break;
            case 'camera_shake':
                CameraSystem.shake(event.magnitude || 10, event.duration || 0.5);
                break;
            case 'add_companion':
                CompanionSystem.addCompanion(event.characterId);
                break;
        }
    }

    function update(dt) {
        if (!currentScenario) return;
        currentScenario.timeElapsed += dt;

        // Timer countdown
        if (currentScenario.timeLimit) {
            const remaining = currentScenario.timeLimit - currentScenario.timeElapsed;
            updateTimerHUD(remaining);
            if (remaining <= 0) {
                failScenario('time_expired');
                return;
            }
            // Warning at 20% time left
            if (remaining / currentScenario.timeLimit < 0.2) {
                if (scenarioTimerEl) scenarioTimerEl.classList.add('urgent');
            }
        }

        // Check auto-complete conditions
        checkAutoComplete();
    }

    function checkAutoComplete() {
        if (!currentScenario || currentScenario.cleared) return;
        const def = currentScenario.def;
        // Support both 'bossFight' and 'boss' field names
        const bossId = def.bossFight?.bossId || def.boss;
        if (bossId && QuestSystem.hasFlag(`boss_killed_${bossId}`)) {
            clearScenario();
            return;
        }
        // Kill-all objective
        if (def.clearCondition === 'kill_all' || def.clearConditions?.includes('kill_all')) {
            const enemies = WorldSystem.getEnemies().filter(e => e.alive);
            if (enemies.length === 0 && currentScenario.timeElapsed > 5) {
                clearScenario();
            }
        }
    }

    function updateObjective(objectiveId, amount) {
        if (!currentScenario) return;
        const obj = currentScenario.objectives[objectiveId] || currentScenario.hiddenObjectives[objectiveId];
        if (!obj || obj.completed) return;
        obj.current = Math.min(obj.required || 1, obj.current + (amount || 1));
        if (obj.current >= (obj.required || 1)) {
            obj.completed = true;
            EventSystem.emit(EventSystem.EVENTS.OBJECTIVE_COMPLETE, { objectiveId, scenarioId: currentScenario.id });
        }
        // Check if all main objectives done
        const allDone = Object.values(currentScenario.objectives).every(o => o.completed);
        if (allDone) clearScenario();
    }

    function clearScenario() {
        if (!currentScenario || currentScenario.cleared) return;
        currentScenario.cleared = true;
        const def = currentScenario.def;

        // Grant rewards
        if (def.rewards) {
            if (def.rewards.exp) window.GameState?.player?.gainExp(def.rewards.exp);
            if (def.rewards.gold) InventorySystem.addGold(def.rewards.gold);
            if (def.rewards.coins) InventorySystem.addDokkaebiCoins(def.rewards.coins);
            if (def.rewards.items) {
                def.rewards.items.forEach(item => InventorySystem.addItem(item.itemId || item, item.quantity || 1));
            }
            if (def.rewards.skillUnlock) SkillSystem.learnSkill(def.rewards.skillUnlock);
        }

        completedScenarios.push(currentScenario.id);
        EventSystem.emit(EventSystem.EVENTS.SCENARIO_CLEAR, { scenarioId: currentScenario.id, def });
        EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
            text: `[Scenario Clear] ${def.name}`,
            subtext: `Reward: ${def.rewards?.exp || 0} EXP, ${def.rewards?.gold || 0} Gold`,
            type: 'scenario_clear'
        });
        QuestSystem.setFlag(`scenario_cleared_${currentScenario.id}`, true);
        ConstellationSystem.reactToAction('survival', 1);

        hideTimerHUD();
        // Auto-start next scenario
        if (def.nextScenario) {
            setTimeout(() => startScenario(def.nextScenario), 5000);
        }
        currentScenario = null;
    }

    function failScenario(reason) {
        if (!currentScenario) return;
        EventSystem.emit(EventSystem.EVENTS.SCENARIO_FAIL, { scenarioId: currentScenario.id, reason });
        EventSystem.emit(EventSystem.EVENTS.SYSTEM_MESSAGE, {
            text: `[Scenario Failed] ${currentScenario.def.name}`,
            subtext: reason === 'time_expired' ? 'Time limit exceeded.' : 'You have failed the scenario.',
            type: 'scenario_fail'
        });
        hideTimerHUD();
        currentScenario = null;
    }

    function updateTimerHUD(remaining) {
        if (!scenarioTimerEl) return;
        if (remaining < 0) { hideTimerHUD(); return; }
        const minutes = Math.floor(remaining / 60);
        const seconds = Math.floor(remaining % 60);
        scenarioTimerEl.textContent = `${minutes}:${seconds.toString().padStart(2,'0')}`;
        scenarioTimerEl.style.display = 'block';
    }

    function hideTimerHUD() {
        if (scenarioTimerEl) scenarioTimerEl.style.display = 'none';
    }

    function isActive() { return !!currentScenario; }
    function getCurrent() { return currentScenario; }
    function isCompleted(id) { return completedScenarios.includes(id); }

    function serialize() { return { completedScenarios, currentScenarioId: currentScenario?.id }; }
    function deserialize(data) {
        if (!data) return;
        completedScenarios = data.completedScenarios || [];
        if (data.currentScenarioId) startScenario(data.currentScenarioId);
    }

    return {
        init, startScenario, update, updateObjective,
        clearScenario, failScenario,
        isActive, getCurrent, isCompleted,
        serialize, deserialize
    };
})();
