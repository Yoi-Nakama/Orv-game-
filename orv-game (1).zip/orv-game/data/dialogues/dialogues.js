// ============================================
// DIALOGUES DATA - ORV
// ============================================
'use strict';

const DialoguesData = {

  // ========== BIHYUNG ==========
  bihyung_main: {
    id: 'bihyung_main',
    speaker: 'bihyung',
    lines: [
      { text: 'Ohoho! A new Scenario has begun! Welcome to the new world, earthlings!', portrait: '👺😁' },
      { text: 'I am Bihyung, your designated Dokkaebi. Think of me as your... game master.', portrait: '👺' },
      { text: 'Now listen carefully. In this world, constellations watch your every move. Do something interesting, earn Dokkaebi Coins. Boring? You get nothing.', portrait: '👺😏' },
      { text: 'The rules are simple: Complete scenarios, survive, earn coins, grow stronger. Fail a scenario... well, let\'s just say the penalty varies.', portrait: '👺' },
      { text: 'Oh, and you — Kim Dokja, was it? The constellations are... unusually interested in you already. Try not to disappoint them.', portrait: '👺🤔' },
    ],
    choices: [
      { text: 'What are these scenarios exactly?', next: 'bihyung_explain_scenarios' },
      { text: 'What happens if I die?', next: 'bihyung_explain_death' },
      { text: 'I already know all of this.', next: 'bihyung_surprise_reaction' },
    ],
  },

  bihyung_explain_scenarios: {
    id: 'bihyung_explain_scenarios',
    speaker: 'bihyung',
    lines: [
      { text: 'Scenarios are tests created by the constellations for their entertainment.', portrait: '👺' },
      { text: 'Each scenario has objectives, rules, rewards, and penalties. Clear them to advance.', portrait: '👺' },
      { text: 'Some scenarios are mandatory — the Main Scenarios. Others are optional sub-scenarios that offer extra rewards.', portrait: '👺😏' },
      { text: 'The harder the scenario, the better the reward. But fail... and you might lose more than you expect.', portrait: '👺😈' },
    ],
  },

  bihyung_surprise_reaction: {
    id: 'bihyung_surprise_reaction',
    speaker: 'bihyung',
    lines: [
      { text: '...Hoh? You already know?', portrait: '👺😲' },
      { text: 'That\'s... unusual. Most earthlings are completely lost when the scenario begins.', portrait: '👺🤔' },
      { text: 'The constellations are going to love you. Or fear you. Possibly both.', portrait: '👺😏' },
      { text: 'Very well. I\'ll be watching closely, Reader.', portrait: '👺' },
    ],
    constellationReaction: 'Constellations notice Kim Dokja\'s unusual knowledge. Favor increased with Demon King of Salvation.',
  },

  // ========== YOO JONGHYUK ==========
  jonghyuk_first_meet: {
    id: 'jonghyuk_first_meet',
    speaker: 'yoo_jonghyuk',
    lines: [
      { text: '...', portrait: '⚔😐' },
      { text: 'You. You\'re different from the others.', portrait: '⚔😐' },
      { text: 'Your eyes — you know something. What is it?', portrait: '⚔😒' },
    ],
    choices: [
      { text: 'I know about you, Yoo Jonghyuk.', next: 'jonghyuk_reveal_knowledge', relationshipGain: -10 },
      { text: 'I\'m just trying to survive.', next: 'jonghyuk_dismissal', relationshipGain: 5 },
      { text: 'Everyone dies eventually. Even you.', next: 'jonghyuk_combat_trigger', danger: true },
    ],
  },

  jonghyuk_reveal_knowledge: {
    id: 'jonghyuk_reveal_knowledge',
    speaker: 'yoo_jonghyuk',
    lines: [
      { text: '...How do you know my name?', portrait: '⚔😤' },
      { text: 'We\'ve never met. I\'m certain of it.', portrait: '⚔😤' },
      { text: 'I\'ve lived through countless iterations of this scenario. You were never among the survivors.', portrait: '⚔😠' },
    ],
    choices: [
      { text: 'I read about you. In a story.', next: 'jonghyuk_story_reaction' },
      { text: 'Let\'s just cooperate. We both want to survive.', next: 'jonghyuk_reluctant_alliance' },
    ],
  },

  jonghyuk_reluctant_alliance: {
    id: 'jonghyuk_reluctant_alliance',
    speaker: 'yoo_jonghyuk',
    lines: [
      { text: '...Cooperation.', portrait: '⚔😐' },
      { text: 'Hmph. Don\'t slow me down, and don\'t get in my way.', portrait: '⚔' },
      { text: 'If you become a liability, I will leave you behind. That is not a threat. It is a fact.', portrait: '⚔' },
    ],
    result: 'yoo_jonghyuk joins as a companion (minimal affinity)',
    companionJoin: 'yoo_jonghyuk',
  },

  // ========== LEE HYUNSUNG ==========
  hyunsung_first_meet: {
    id: 'hyunsung_first_meet',
    speaker: 'lee_hyunsung',
    lines: [
      { text: 'Ah — a survivor! Thank God. Are you hurt?', portrait: '🛡😊' },
      { text: 'I\'m Lee Hyunsung. Former Sergeant, 1st Division. I\'ve been trying to keep people safe but...', portrait: '🛡😟' },
      { text: 'There are too many of them. And people are panicking. Do you know what\'s happening?', portrait: '🛡😟' },
    ],
    choices: [
      { text: 'Yes. We\'re in a scenario. I\'ll explain.', next: 'hyunsung_explanation_grateful', relationshipGain: 20 },
      { text: 'No idea. Let\'s just survive.', next: 'hyunsung_join_group', relationshipGain: 10 },
    ],
  },

  hyunsung_explanation_grateful: {
    id: 'hyunsung_explanation_grateful',
    speaker: 'lee_hyunsung',
    lines: [
      { text: 'Scenarios... monsters... constellations watching us like a show?', portrait: '🛡😮' },
      { text: 'That\'s... a lot to take in. But I believe you.', portrait: '🛡😌' },
      { text: 'If you know what\'s coming... please let me help. I\'ll protect everyone I can.', portrait: '🛡😤' },
    ],
    result: 'Lee Hyunsung joins with higher initial affinity',
    companionJoin: 'lee_hyunsung',
    affinityBonus: 20,
  },

  // ========== SCENARIO INTRO DIALOGUES ==========
  scenario_01_intro: {
    id: 'scenario_01_intro',
    type: 'cutscene',
    lines: [
      { text: '[Kim Dokja is sitting in the subway, reading the final chapter of "Three Ways to Survive in a Ruined World" on his phone.]' },
      { text: '"Finally... I finished it. I\'m the only person in the world who read it to the end."' },
      { text: '[The train suddenly lurches. The lights go out. When they come back on, the world has changed.]' },
      { text: '[System windows appear before every person on the train. Screaming begins.]' },
      { text: '[Kim Dokja alone remains calm. He has read this moment. He knows exactly what is happening.]' },
      { text: '"...So it began."' },
    ],
  },

  scenario_01_clear: {
    id: 'scenario_01_clear',
    type: 'cutscene',
    lines: [
      { text: '[You emerge from the subway into the chaos of transformed Seoul.]' },
      { text: '[Bihyung, the Dokkaebi, floats in front of you, grinning.]' },
      { text: '"Impressive! The first survivor to clear the subway scenario solo! The constellations are very pleased!"' },
      { text: '[A cascade of Dokkaebi Coins rains down. Somewhere, unseen beings are watching with immense interest.]' },
      { text: '[Kim Dokja thinks: The story has truly begun. And I am inside it.]' },
    ],
  },

  // ========== KIM NAMWOON ==========
  namwoon_confrontation: {
    id: 'namwoon_confrontation',
    speaker: 'kim_namwoon',
    lines: [
      { text: 'Hey! You! Drop whatever you\'ve got. This is our turf now.', portrait: '😤' },
      { text: 'The scenario started and you think the old rules still apply? Ha!', portrait: '😤' },
    ],
    choices: [
      { text: '[Use Web of Lies] You don\'t want to do this. I know where the real treasure is.', next: 'namwoon_convinced', requirement: 'skill_web_of_lies', relationshipGain: 0 },
      { text: '[Fight] I don\'t have time for this.', next: 'namwoon_fight', triggerCombat: true },
      { text: 'Fine. Take it.', next: 'namwoon_takes_stuff', relationshipGain: -20, loseItem: true },
    ],
  },

  namwoon_convinced: {
    id: 'namwoon_convinced',
    speaker: 'kim_namwoon',
    lines: [
      { text: '...You know where? Like, actually know?', portrait: '😲' },
      { text: 'Fine. Lead the way. But if you\'re lying...', portrait: '😒' },
    ],
    result: 'Kim Namwoon follows as a temporary companion',
    temporaryCompanion: 'kim_namwoon',
    affinityBonus: 15,
  },
};

if (typeof window !== 'undefined') window.DialoguesData = DialoguesData;
