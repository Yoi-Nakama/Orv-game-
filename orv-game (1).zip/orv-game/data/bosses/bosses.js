// ============================================
// BOSSES DATA - Omniscient Reader's Viewpoint
// All major scenario bosses from the novel
// ============================================
'use strict';

const BossesData = {

  // ========== EARLY GAME BOSSES ==========

  king_of_trolls: {
    id: 'king_of_trolls',
    name: 'King of Trolls',
    title: '[ Intermediate Boss ]',
    grade: 'D+',
    scenario: 'scenario_03_trolls_bridge',
    portrait: '👑🧌',
    description: 'The ruler of the subway trolls. Massive in size and strength. Guards the passage between subway stations.',
    lore: 'When the scenario transformed the Seoul subway system, this ancient troll woke from centuries of sleep beneath the Han River.',
    hp: 3500, maxHP: 3500,
    atk: 80, def: 50, spd: 25,
    exp: 500, coins: 300,
    phases: [
      {
        phase: 1, name: 'Enraged King',
        hpThreshold: 1.0,
        skills: ['ground_slam', 'roar', 'boulder_throw', 'regeneration'],
        description: 'Standard combat phase',
      },
      {
        phase: 2, name: 'Berserker King',
        hpThreshold: 0.5,
        skills: ['berserk_mode', 'ground_shatter', 'troll_call', 'regeneration_burst'],
        description: 'Enters berserk at 50% HP. Calls backup trolls. Regeneration increases.',
        buffs: ['atk_up_30', 'spd_up_20'],
      }
    ],
    drops: [
      { itemId: 'troll_king_crown', chance: 1.0, type: 'guaranteed' },
      { itemId: 'troll_king_core', chance: 0.6 },
      { itemId: 'strength_essence', chance: 0.4 },
      { itemId: 'coins_500', chance: 1.0 },
    ],
    introDialogue: 'GRAAAAHHHH! INTRUDERS ON KING\'S BRIDGE! KILL ALL!',
    defeatDialogue: '...Impossible... King... falls...',
    arenaSize: { width: 600, height: 300 },
    music: 'boss_troll',
    weaknesses: ['fire', 'light'],
    resistances: ['physical', 'blunt'],
    mechanics: [
      'Ground Slam creates AOE shockwave — dodge sideways',
      'At 50% HP, 3 backup trolls spawn from the sides',
      'Regeneration restores 50 HP per 3 seconds — deal damage fast',
    ],
  },

  dragon_lord_fafnir: {
    id: 'dragon_lord_fafnir',
    name: 'Dragon Lord Fafnir',
    title: '[ Mid-Game Boss | Scenario 7 ]',
    grade: 'B+',
    scenario: 'scenario_07_dragon_mountain',
    portrait: '🐉',
    description: 'An ancient dragon lord who lords over the scenario zone "Dragon\'s Peak." One of the most powerful non-human entities encountered in the early-mid game.',
    lore: 'Fafnir was once a Norse constellation\'s champion. When the constellation fell, he became a rogue dragon lord bound to Earth.',
    hp: 18000, maxHP: 18000,
    atk: 200, def: 150, spd: 80,
    exp: 3500, coins: 2000,
    phases: [
      {
        phase: 1, name: 'Dragon Lord Awakened',
        hpThreshold: 1.0,
        skills: ['dragon_breath_fire', 'wing_strike', 'claw_combo', 'scale_hardening'],
        description: 'Standard attacks. Predictable patterns.',
      },
      {
        phase: 2, name: 'Dragon Lord Enraged',
        hpThreshold: 0.7,
        skills: ['corrupted_breath', 'dragon_nova', 'tail_sweep_wide', 'aerial_dive'],
        description: 'Gains air attacks. Breath becomes multi-directional.',
        buffs: ['atk_up_25'],
      },
      {
        phase: 3, name: 'Final Dragon Roar',
        hpThreshold: 0.3,
        skills: ['dragon_extinction_breath', 'meteor_summon', 'dragon_armor', 'death_spiral'],
        description: 'Final phase. All attacks become lethal. Calls meteor shower.',
        buffs: ['atk_up_50', 'def_up_30', 'spd_up_20'],
      }
    ],
    drops: [
      { itemId: 'dragon_lord_heart', chance: 1.0, type: 'guaranteed' },
      { itemId: 'dragon_lord_scale', chance: 1.0 },
      { itemId: 'ancient_dragon_soul', chance: 0.5 },
      { itemId: 'legendary_weapon_box', chance: 0.3 },
    ],
    introDialogue: 'Insignificant mortals... you dare to challenge a Dragon Lord? Then I shall teach you true despair!',
    defeatDialogue: 'Remarkable... a mere mortal defeated me... The constellations... will take note...',
    arenaSize: { width: 1200, height: 800 },
    music: 'boss_dragon',
    weaknesses: ['holy', 'dragon_bane'],
    resistances: ['fire', 'physical'],
    immunities: ['burn', 'fear'],
    mechanics: [
      'Phase 1: Stay close to avoid breath attack hitbox',
      'Phase 2: Wing Strike covers half the arena — move to the opposite side',
      'Phase 3: Meteor Shower covers 60% of arena — identify safe zones quickly',
      'Dragon Armor reduces all damage by 50% — use armor-piercing skills',
    ],
    rewards: {
      storyText: 'Dragon Lord Fafnir has been defeated. The mountains tremble as centuries of accumulated power dissipates.',
      unlocks: ['dragon_slayer_title', 'dragon_mountain_area'],
    },
  },

  demon_king_asmodeus: {
    id: 'demon_king_asmodeus',
    name: 'Demon King Asmodeus',
    title: '[ Scenario 10 Boss | Demon Realm Gate ]',
    grade: 'A',
    scenario: 'scenario_10_demon_realm',
    portrait: '👿',
    description: 'One of the three demon kings who rules a portion of the demon realm. Has been leaking demonic power into Seoul through hidden gates.',
    lore: 'Asmodeus is a constellation-backed demon king. His true goal is to consume enough human souls to ascend to a higher-tier being.',
    hp: 45000, maxHP: 45000,
    atk: 350, def: 220, spd: 120,
    exp: 12000, coins: 8000,
    phases: [
      {
        phase: 1, name: 'Demon King Manifest',
        hpThreshold: 1.0,
        skills: ['hellfire_storm', 'demon_sword', 'darkness_prison', 'soul_drain'],
        description: 'High damage output. Tests basic dodging.',
      },
      {
        phase: 2, name: 'Demonic Transformation',
        hpThreshold: 0.6,
        skills: ['demon_true_form', 'chaos_eruption', 'nightmare_realm', 'possession_wave'],
        description: 'Transforms into true demon form. Size doubles. Attacks cover more area.',
        buffs: ['atk_up_40', 'def_up_30'],
        arena: 'expands',
      },
      {
        phase: 3, name: 'Soul Devourer',
        hpThreshold: 0.25,
        skills: ['devour_soul', 'apocalypse_flame', 'demon_king_authority', 'final_judgment'],
        description: 'Final phase. Steals buffs from party. Can one-shot unprepared players.',
        buffs: ['atk_up_60', 'spd_up_30', 'all_resist_up'],
      }
    ],
    drops: [
      { itemId: 'demon_king_horn', chance: 1.0, type: 'guaranteed' },
      { itemId: 'asmodeus_seal', chance: 1.0 },
      { itemId: 'demon_king_heart', chance: 0.4 },
      { itemId: 'legendary_armor_box', chance: 0.25 },
      { itemId: 'constellation_fragment', chance: 0.1 },
    ],
    introDialogue: 'Heh... so the Reader has come this far. I\'ve heard of you from the constellations. Let us see if your knowledge is worth anything against a true Demon King.',
    defeatDialogue: 'Impossible... my power... my eternal life... taken by a mere human who only read about us...',
    arenaSize: { width: 2000, height: 1200 },
    music: 'boss_demon_king',
    weaknesses: ['holy', 'divine_word'],
    resistances: ['fire', 'dark', 'physical', 'magic'],
    immunities: ['fear', 'poison', 'curse', 'stun'],
    constellationInvolved: 'demon_king', // Demon King of Salvation constellation watches this
    mechanics: [
      'Phase 1: Hellfire Storm rains 20 projectiles — stay mobile',
      'Phase 2: Nightmare Realm alters the arena — landmarks shift',
      'Phase 3: Devour Soul removes your strongest active buff — maintain multiple buffs',
      'Demon King Authority: If HP drops below 5000, triggers instant shield — must be broken with party DPS',
    ],
    rewards: {
      storyText: 'Asmodeus falls. The demon realm gate begins to close. Coins rain from the sky as constellations applaud.',
      unlocks: ['demon_slayer_title', 'demonic_arts_skill_tree', 'hell_gate_area_cleared'],
    },
  },

  // ========== STORY CRITICAL BOSSES ==========

  secretive_plotter_avatar: {
    id: 'secretive_plotter_avatar',
    name: 'Avatar of the Secretive Plotter',
    title: '[ Story Boss | Constellation Arc ]',
    grade: 'A+',
    scenario: 'scenario_constellation_arc',
    portrait: '🎭',
    description: 'A manifestation of the Secretive Plotter constellation — an avatar sent to test Kim Dokja\'s resolve.',
    lore: 'The Secretive Plotter is one of the most enigmatic constellations. Its avatar uses temporal manipulation and knowledge of all timelines.',
    hp: 80000, maxHP: 80000,
    atk: 500, def: 350, spd: 200,
    exp: 30000, coins: 20000,
    phases: [
      {
        phase: 1, name: 'Observation',
        hpThreshold: 1.0,
        skills: ['timeline_read', 'counter_attack', 'probability_slash'],
        description: 'Reads your moves and counters. Unpredictable.',
      },
      {
        phase: 2, name: 'Interference',
        hpThreshold: 0.5,
        skills: ['story_rewrite', 'timeline_collapse', 'fate_sever', 'regression_echo'],
        description: 'Begins altering the battlefield. Previous safe spots become dangerous.',
      },
      {
        phase: 3, name: 'True Form',
        hpThreshold: 0.15,
        skills: ['omniscience_burst', 'ending_decree', 'author_authority'],
        description: 'Reveals true power. Uses knowledge of all possible outcomes.',
      }
    ],
    drops: [
      { itemId: 'plotter_memory_fragment', chance: 1.0 },
      { itemId: 'constellation_star_fragment', chance: 1.0 },
      { itemId: 'ultimate_skill_book', chance: 0.5 },
    ],
    isStoryBoss: true,
    postBattleDialogue: 'You truly are... remarkable. Very well. I acknowledge you.',
    mechanics: [
      'Counter Attack triggers after every 3rd hit you land — vary your timing',
      'Story Rewrite scrambles skill button positions — memorize new layout',
      'Fate Sever cuts one skill from your bar permanently until next save — protect your most important skill',
    ],
  },

  yoo_jonghyuk_corrupted: {
    id: 'yoo_jonghyuk_corrupted',
    name: 'Corrupted Yoo Jonghyuk',
    title: '[ Story Boss | Regression Paradox ]',
    grade: 'S',
    scenario: 'scenario_regression_paradox',
    portrait: '⚔💀',
    description: 'Yoo Jonghyuk consumed by regression paradox energy. This is not truly him — but his accumulated rage and pain given form.',
    lore: 'Every regression leaves scars. The accumulated trauma of thousands of attempts to save the world has created a shadow self.',
    hp: 150000, maxHP: 150000,
    atk: 750, def: 500, spd: 300,
    exp: 80000, coins: 50000,
    phases: [
      {
        phase: 1, name: 'Shadow of the Regressor',
        hpThreshold: 1.0,
        skills: ['regression_cut', 'memory_blade', 'steel_constitution_active'],
        description: 'Uses Yoo Jonghyuk\'s base skills with corrupted energy.',
      },
      {
        phase: 2, name: 'Thousand Regression Memories',
        hpThreshold: 0.6,
        skills: ['all_timeline_strike', 'paradox_explosion', 'regression_storm'],
        description: 'Channels power from all timelines simultaneously.',
        buffs: ['all_stats_up_50'],
      },
      {
        phase: 3, name: 'Final Iteration',
        hpThreshold: 0.2,
        skills: ['ending_slash', 'regression_erasure', 'true_hero_light'],
        description: 'Last phase. The "true" Yoo Jonghyuk breaks through — this phase requires a specific action to complete.',
        specialMechanic: 'To break corruption, use "Speak to him" option when prompted.',
      }
    ],
    drops: [
      { itemId: 'regressor_memory_crystal', chance: 1.0 },
      { itemId: 'yoo_jonghyuk_sword_fragment', chance: 0.7 },
      { itemId: 'paradox_gem', chance: 0.5 },
    ],
    isStoryBoss: true,
    specialEnding: true, // Has a unique ending sequence
    defeatMethod: 'combat_plus_story_action',
    music: 'boss_yoo_jonghyuk',
    mechanics: [
      'His attacks mirror skills you\'ve used — diversify your combat approach',
      'At Phase 3, choose "Speak to him" option instead of attacking to access true ending',
      'Paradox Explosion has global range — only survived with specific barrier skills',
    ],
  },

  // ========== OPTIONAL / HIDDEN BOSSES ==========

  outer_god_fragment: {
    id: 'outer_god_fragment',
    name: 'Outer God Fragment',
    title: '[ Hidden Boss | ???? ]',
    grade: 'SS',
    scenario: 'hidden_scenario_outer_god',
    portrait: '🌀',
    description: 'A fragment of an incomprehensible being from beyond the constellation system. Reality warps around it.',
    lore: 'The Outer Gods exist outside the system. They are neither constellations nor demons. They are something else entirely.',
    hp: 500000, maxHP: 500000,
    atk: 1200, def: 800, spd: 400,
    exp: 500000, coins: 100000,
    isHidden: true,
    unlockCondition: 'Complete all main scenarios + 80% side quests',
    phases: [
      {
        phase: 1, name: 'Reality Distortion',
        hpThreshold: 1.0,
        skills: ['reality_warp', 'void_blast', 'dimensional_tear'],
        description: 'Alters the laws of physics in the arena.',
      },
      {
        phase: 2, name: 'True Form',
        hpThreshold: 0.3,
        skills: ['end_of_story', 'existence_erasure', 'outer_law'],
        description: 'All conventional rules break. Requires maximum preparation.',
      }
    ],
    drops: [
      { itemId: 'outer_god_eye', chance: 1.0, type: 'guaranteed' },
      { itemId: 'divine_creation_material', chance: 1.0 },
      { itemId: 'myth_weapon_fragment', chance: 0.8 },
    ],
    music: 'boss_outer_god',
    mechanics: [
      'Reality Warp inverts movement controls temporarily',
      'Existence Erasure removes all equipped gear temporarily',
      'Void Blast has no counter — must dodge using precise timing',
    ],
  },
};

if (typeof window !== 'undefined') window.BossesData = BossesData;
