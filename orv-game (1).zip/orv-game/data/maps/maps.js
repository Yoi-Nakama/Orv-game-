// ============================================
// MAPS DATA - ORV
// ============================================
'use strict';

const MapsData = {

  subway_line_2: {
    id: 'subway_line_2',
    name: 'Seoul Metro Line 2',
    displayName: '서울 지하철 2호선',
    type: 'dungeon',
    theme: 'underground',
    bgColor: '#0a0a14',
    accentColor: '#3a6a4a',
    width: 2400, height: 600,
    music: 'bgm_subway',
    ambience: 'sfx_subway_ambient',
    lighting: 'dim_emergency',
    zones: [
      { id: 'zone_train_car', name: 'Train Car', x: 0, y: 200, w: 600, h: 200, type: 'start' },
      { id: 'zone_platform', name: 'Platform', x: 600, y: 200, w: 800, h: 200, type: 'combat' },
      { id: 'zone_tunnel', name: 'Tunnel', x: 1400, y: 200, w: 600, h: 200, type: 'combat' },
      { id: 'zone_exit', name: 'Emergency Exit', x: 2000, y: 100, w: 400, h: 400, type: 'exit' },
    ],
    spawns: [
      { enemy: 'subway_troll', zone: 'zone_platform', count: 3, respawn: false },
      { enemy: 'subway_troll', zone: 'zone_tunnel', count: 2, respawn: false },
    ],
    npcs: [
      { id: 'trapped_passenger_1', x: 200, y: 280, dialogue: 'help_passenger' },
      { id: 'trapped_passenger_2', x: 450, y: 290, dialogue: 'help_passenger' },
      { id: 'bihyung', x: 2100, y: 200, dialogue: 'bihyung_main', isQuestGiver: true },
    ],
    exits: [
      { id: 'to_seoul_streets', x: 2380, y: 280, target: 'seoul_streets', label: 'Exit to Seoul' },
    ],
    tilemap: 'subway',
    discoverable: true,
    scenario: 'scenario_01_three_ways',
  },

  seoul_streets: {
    id: 'seoul_streets',
    name: 'Seoul City Streets',
    displayName: '서울 거리',
    type: 'open_world',
    theme: 'urban_apocalypse',
    bgColor: '#0d0d1a',
    accentColor: '#3a3a5a',
    width: 5000, height: 3000,
    music: 'bgm_seoul_chaos',
    ambience: 'sfx_city_ambient',
    lighting: 'day_apocalypse',
    zones: [
      { id: 'zone_residential', name: 'Residential Area', x: 0, y: 0, w: 1500, h: 1500, type: 'exploration' },
      { id: 'zone_commercial', name: 'Commercial District', x: 1500, y: 0, w: 2000, h: 1500, type: 'combat' },
      { id: 'zone_subway_exit', name: 'Near Subway Exit', x: 0, y: 1500, w: 800, h: 1500, type: 'start' },
      { id: 'zone_shelter', name: 'Survivor Shelter', x: 800, y: 1500, w: 1200, h: 1500, type: 'safe' },
      { id: 'zone_danger', name: 'High Danger Zone', x: 3500, y: 0, w: 1500, h: 3000, type: 'high_difficulty' },
    ],
    spawns: [
      { enemy: 'fire_rat', zone: 'zone_commercial', count: 8, respawn: true, respawnTime: 60 },
      { enemy: 'dark_spirit', zone: 'zone_danger', count: 4, respawn: true, respawnTime: 120 },
      { enemy: 'mutant_lion', zone: 'zone_danger', count: 2, respawn: true, respawnTime: 300 },
    ],
    npcs: [
      { id: 'lee_hyunsung', x: 900, y: 1600, dialogue: 'hyunsung_first_meet', isCompanion: true },
      { id: 'kim_namwoon', x: 1600, y: 200, dialogue: 'namwoon_confrontation', isHostile: true },
      { id: 'survivor_trader', x: 850, y: 1700, dialogue: 'trader_generic', isShopkeeper: true, shop: 'scenario_shop' },
    ],
    exits: [
      { id: 'to_han_bridge', x: 2500, y: 2900, target: 'han_river_bridge', label: 'Han River Bridge' },
      { id: 'to_subway', x: 0, y: 1600, target: 'subway_line_2', label: 'Subway Entrance' },
    ],
    secrets: [
      { id: 'underground_market_entrance', x: 1200, y: 800, reveal: 'sq_05_black_market' },
    ],
    discoverable: true,
    scenario: 'scenario_02_seoul_streets',
  },

  han_river_bridge: {
    id: 'han_river_bridge',
    name: 'Han River Bridge',
    displayName: '한강 다리',
    type: 'dungeon',
    theme: 'bridge_battle',
    bgColor: '#080c18',
    accentColor: '#2a4a7c',
    width: 3000, height: 800,
    music: 'bgm_troll_bridge',
    lighting: 'night_moonlit',
    zones: [
      { id: 'zone_bridge_start', name: 'South Entrance', x: 0, y: 200, w: 600, h: 400, type: 'start' },
      { id: 'zone_bridge_main', name: 'Bridge Main', x: 600, y: 200, w: 1600, h: 400, type: 'combat' },
      { id: 'zone_troll_king', name: 'Troll King\'s Territory', x: 1600, y: 100, w: 800, h: 600, type: 'boss' },
      { id: 'zone_bridge_north', name: 'North Side', x: 2400, y: 200, w: 600, h: 400, type: 'exit' },
    ],
    boss: { id: 'king_of_trolls', x: 2000, y: 400 },
    spawns: [
      { enemy: 'subway_troll', zone: 'zone_bridge_main', count: 5, respawn: false },
    ],
    exits: [
      { id: 'back_to_seoul', x: 0, y: 400, target: 'seoul_streets', label: 'Back to Seoul' },
      { id: 'north_seoul', x: 2980, y: 400, target: 'north_district', label: 'North Seoul', locked: true, unlockCondition: 'defeat_troll_king' },
    ],
    scenario: 'scenario_03_trolls_bridge',
  },

  dragon_mountain: {
    id: 'dragon_mountain',
    name: "Dragon's Peak",
    displayName: '용의 봉우리',
    type: 'dungeon',
    theme: 'mountain_dragon',
    bgColor: '#14080a',
    accentColor: '#8b2a2a',
    width: 4000, height: 3000,
    music: 'bgm_dragon_mountain',
    lighting: 'volcanic_glow',
    zones: [
      { id: 'zone_foot', name: 'Mountain Foot', x: 0, y: 2400, w: 1000, h: 600, type: 'start' },
      { id: 'zone_slope', name: 'Dragon\'s Slope', x: 0, y: 1200, w: 2000, h: 1200, type: 'combat' },
      { id: 'zone_caverns', name: 'Dragon Caverns', x: 1200, y: 600, w: 1600, h: 600, type: 'exploration' },
      { id: 'zone_peak', name: 'Dragon\'s Peak Summit', x: 1500, y: 0, w: 1000, h: 600, type: 'boss' },
    ],
    boss: { id: 'dragon_lord_fafnir', x: 2000, y: 300 },
    spawns: [
      { enemy: 'corrupted_dragon_spawn', zone: 'zone_slope', count: 4, respawn: true },
      { enemy: 'fire_rat', zone: 'zone_caverns', count: 10, respawn: true },
    ],
    exits: [
      { id: 'back_to_city', x: 0, y: 2700, target: 'seoul_streets', label: 'Back to Seoul' },
    ],
    scenario: 'scenario_07_dragon_mountain',
  },

  demon_realm_gate: {
    id: 'demon_realm_gate',
    name: 'Demon Realm Gate',
    displayName: '마계의 문',
    type: 'final_dungeon',
    theme: 'demonic',
    bgColor: '#1a0408',
    accentColor: '#8b1a1a',
    width: 5000, height: 4000,
    music: 'bgm_demon_realm',
    lighting: 'hellfire',
    zones: [
      { id: 'zone_approach', name: 'Gate Approach', x: 0, y: 1500, w: 1000, h: 1000, type: 'combat' },
      { id: 'zone_gate', name: 'The Gate', x: 1000, y: 1000, w: 2000, h: 2000, type: 'boss_approach' },
      { id: 'zone_throne', name: 'Demon King\'s Throne', x: 2500, y: 1500, w: 1500, h: 1000, type: 'final_boss' },
      { id: 'zone_inner_gate', name: 'Inner Gate Mechanism', x: 4000, y: 1500, w: 1000, h: 1000, type: 'objective' },
    ],
    boss: { id: 'demon_king_asmodeus', x: 3200, y: 2000 },
    spawns: [
      { enemy: 'demon_soldier', zone: 'zone_approach', count: 6, respawn: true },
      { enemy: 'demon_soldier', zone: 'zone_gate', count: 8, respawn: true },
    ],
    isClimax: true,
    scenario: 'scenario_10_demon_realm',
  },

  constellation_realm: {
    id: 'constellation_realm',
    name: 'Constellation Realm',
    displayName: '별자리 영역',
    type: 'special',
    theme: 'cosmic',
    bgColor: '#02020a',
    accentColor: '#6a3aff',
    width: 3000, height: 3000,
    music: 'bgm_constellation',
    lighting: 'starfield',
    isTranscendent: true,
    scenario: 'scenario_08_constellation_trial',
  },
};

// World map layout for the overworld map UI
const WorldMapData = {
  regions: [
    { id: 'subway_line_2', label: 'Subway Line 2', x: 200, y: 300, discovered: true, type: 'dungeon' },
    { id: 'seoul_streets', label: 'Seoul Streets', x: 300, y: 250, discovered: false, type: 'open' },
    { id: 'han_river_bridge', label: 'Han River Bridge', x: 300, y: 350, discovered: false, type: 'dungeon' },
    { id: 'north_district', label: 'North Seoul', x: 250, y: 200, discovered: false, type: 'open' },
    { id: 'dragon_mountain', label: "Dragon's Peak", x: 150, y: 150, discovered: false, type: 'dungeon' },
    { id: 'demon_realm_gate', label: 'Demon Realm Gate', x: 400, y: 150, discovered: false, type: 'final' },
    { id: 'constellation_realm', label: '???', x: 350, y: 100, discovered: false, type: 'special' },
  ],
  connections: [
    { from: 'subway_line_2', to: 'seoul_streets' },
    { from: 'seoul_streets', to: 'han_river_bridge' },
    { from: 'han_river_bridge', to: 'north_district' },
    { from: 'north_district', to: 'dragon_mountain' },
    { from: 'north_district', to: 'demon_realm_gate' },
  ],
};

if (typeof window !== 'undefined') {
  window.MapsData = MapsData;
  window.WorldMapData = WorldMapData;
}
