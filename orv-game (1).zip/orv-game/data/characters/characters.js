// ============================================
// CHARACTERS DATA - Omniscient Reader's Viewpoint
// All major characters from the novel
// ============================================
'use strict';

const CharactersData = {

  // ---- MAIN CHARACTER ----
  kim_dokja: {
    id: 'kim_dokja',
    name: 'Kim Dokja',
    nameKR: '김독자',
    title: 'Omniscient Reader',
    role: 'player',
    portrait: '📖',
    description: 'The sole reader of "Three Ways to Survive in a Ruined World." His knowledge of the novel grants him unique foresight. He is the only person who read the story to its end.',
    class: 'Reader',
    faction: 'Neutral',
    stats: {
      STR: 5, AGI: 6, END: 8, INT: 15,
      LCK: 20, PER: 25, ACC: 10, DEF: 3, ATK: 8, SPD: 6,
      HP: 100, MP: 100, SP: 100,
    },
    startingSkills: ['prophecy_of_the_reader', 'web_of_lies', 'calm_mindset'],
    startingItems: ['smartphone', 'subway_card', 'salary_mans_lunch'],
    backstory: 'An ordinary company worker who spent 10 years reading a web novel. When the world turned into a scenario, only he knew what would happen next.',
    favoriteConstellation: 'demon_king',
    uniquePassive: 'Omniscient Reader: Can perceive hidden information about scenarios, enemies, and items that other characters cannot.',
  },

  // ---- MAIN COMPANIONS ----
  yoo_jonghyuk: {
    id: 'yoo_jonghyuk',
    name: 'Yoo Jonghyuk',
    nameKR: '유중혁',
    title: 'Regressor',
    role: 'companion',
    portrait: '⚔',
    description: 'The protagonist of "Three Ways to Survive." A regressor who has repeated the apocalyptic scenario multiple times. Possesses overwhelming physical ability and combat expertise.',
    class: 'Regressor',
    faction: 'Independent',
    stats: {
      STR: 95, AGI: 90, END: 92, INT: 75,
      LCK: 5, PER: 80, ACC: 85, DEF: 70, ATK: 90, SPD: 88,
      HP: 500, MP: 300, SP: 400,
    },
    startingSkills: ['regression_memory', 'sword_of_divine_retribution', 'fourth_wall', 'steel_constitution', 'iron_will'],
    personality: 'cold',
    affinity: 0,
    affinityEvents: ['save_from_troll', 'share_information', 'survive_together'],
    uniquePassive: 'Regression Memory: Remembers all skills and knowledge from previous regressions. Cannot be surprised.',
    joinCondition: 'After scenario_03_trolls_bridge',
  },

  lee_hyunsung: {
    id: 'lee_hyunsung',
    name: 'Lee Hyunsung',
    nameKR: '이현성',
    title: 'Steel Sword',
    role: 'companion',
    portrait: '🛡',
    description: 'A former military officer. Loyal, strong, and dependable. He becomes one of Kim Dokja\'s most reliable companions.',
    class: 'Warrior',
    faction: 'Kim Dokja Company',
    stats: {
      STR: 70, AGI: 45, END: 80, INT: 35,
      LCK: 20, PER: 40, ACC: 55, DEF: 75, ATK: 65, SPD: 40,
      HP: 400, MP: 100, SP: 350,
    },
    startingSkills: ['steel_defense', 'shield_bash', 'military_discipline', 'iron_body'],
    personality: 'loyal',
    affinity: 30,
    joinCondition: 'After first_subway_escape',
  },

  jung_heewon: {
    id: 'jung_heewon',
    name: 'Jung Heewon',
    nameKR: '정희원',
    title: 'Swords Master',
    role: 'companion',
    portrait: '🗡',
    description: 'A woman with exceptional sword talent. Sharp-tongued but fiercely loyal to those she considers her people. Former member of the Mino Soft.',
    class: 'Swordsman',
    faction: 'Kim Dokja Company',
    stats: {
      STR: 65, AGI: 80, END: 60, INT: 50,
      LCK: 30, PER: 60, ACC: 75, DEF: 45, ATK: 70, SPD: 78,
      HP: 320, MP: 150, SP: 380,
    },
    startingSkills: ['sword_mastery', 'quick_draw', 'dual_wielding', 'critical_strike'],
    personality: 'sarcastic',
    affinity: 10,
    joinCondition: 'After rescue_from_fire_scenario',
  },

  lee_jihye: {
    id: 'lee_jihye',
    name: 'Lee Jihye',
    nameKR: '이지혜',
    title: 'Admiral of the Seas',
    role: 'companion',
    portrait: '⚓',
    description: 'A high school student who becomes a powerful naval commander. Student of Yoo Jonghyuk. Brave and determined.',
    class: 'Admiral',
    faction: 'Kim Dokja Company',
    stats: {
      STR: 50, AGI: 65, END: 55, INT: 60,
      LCK: 40, PER: 65, ACC: 70, DEF: 40, ATK: 58, SPD: 60,
      HP: 280, MP: 200, SP: 300,
    },
    startingSkills: ['naval_command', 'ocean_call', 'fleet_admiral', 'storm_blade'],
    personality: 'energetic',
    affinity: 20,
    joinCondition: 'After sea_scenario_arc',
  },

  shin_yoosung: {
    id: 'shin_yoosung',
    name: 'Shin Yoosung',
    nameKR: '신유성',
    title: 'Demon King\'s Vessel',
    role: 'companion',
    portrait: '👧',
    description: 'A child who possesses great power. Related to the Demon King of Salvation. Her full potential is unlocked only under specific conditions.',
    class: 'Vessel',
    faction: 'Kim Dokja Company',
    stats: {
      STR: 20, AGI: 35, END: 40, INT: 70,
      LCK: 60, PER: 80, ACC: 50, DEF: 20, ATK: 30, SPD: 45,
      HP: 200, MP: 400, SP: 200,
    },
    startingSkills: ['demon_stigma', 'vessel_of_chaos', 'innocent_light'],
    personality: 'gentle',
    affinity: 40,
    joinCondition: 'After rescue_from_demon_realm',
  },

  han_sooyoung: {
    id: 'han_sooyoung',
    name: 'Han Sooyoung',
    nameKR: '한수영',
    title: 'Secretive Plotter',
    role: 'companion',
    portrait: '✍',
    description: 'A writer who also read the novel "Three Ways to Survive." Rivals Kim Dokja in knowledge and cunning. Her real identity and motivations are complex.',
    class: 'Plotter',
    faction: 'Variable',
    stats: {
      STR: 15, AGI: 55, END: 40, INT: 90,
      LCK: 35, PER: 85, ACC: 60, DEF: 25, ATK: 35, SPD: 50,
      HP: 230, MP: 450, SP: 250,
    },
    startingSkills: ['plot_twist', 'narrative_control', 'regression_author', 'thousand_year_king'],
    personality: 'cunning',
    affinity: -10,
    joinCondition: 'After plot_reveal_arc',
    uniquePassive: 'Story Knowledge: Like Kim Dokja, has foreknowledge of events but from the author\'s perspective.',
  },

  // ---- KEY NPCs ----
  kim_namwoon: {
    id: 'kim_namwoon',
    name: 'Kim Namwoon',
    nameKR: '김남운',
    title: 'The Thug',
    role: 'npc_hostile',
    portrait: '😤',
    description: 'A delinquent who quickly adapts to the apocalypse. Can become an ally or remain hostile depending on player choices.',
    class: 'Street Fighter',
    faction: 'Neutral',
    stats: {
      STR: 45, AGI: 40, END: 50, INT: 20,
      LCK: 15, PER: 25, ACC: 35, DEF: 35, ATK: 48, SPD: 42,
      HP: 250, MP: 50, SP: 300,
    },
    canBecomeAlly: true,
    allyCondition: 'Spare and demonstrate strength',
  },

  lee_gilyoung: {
    id: 'lee_gilyoung',
    name: 'Lee Gilyoung',
    nameKR: '이길영',
    title: 'Bug King',
    role: 'companion',
    portrait: '🐛',
    description: 'A child who gains the unique ability to communicate with and control insects. Devoted to Kim Dokja.',
    class: 'Bug King',
    faction: 'Kim Dokja Company',
    stats: {
      STR: 15, AGI: 40, END: 30, INT: 60,
      LCK: 50, PER: 70, ACC: 45, DEF: 15, ATK: 20, SPD: 38,
      HP: 180, MP: 300, SP: 200,
    },
    startingSkills: ['insect_command', 'swarm_attack', 'bug_king_stigma'],
    personality: 'timid_but_brave',
    affinity: 50,
  },

  jang_hayoung: {
    id: 'jang_hayoung',
    name: 'Jang Hayoung',
    nameKR: '장하영',
    title: 'Sole Conqueror',
    role: 'companion',
    portrait: '🌸',
    description: 'A former internet celebrity who discovers her unique talent for mimicking others\' abilities. Cheerful but hiding pain.',
    class: 'Mimic',
    faction: 'Kim Dokja Company',
    stats: {
      STR: 35, AGI: 60, END: 45, INT: 65,
      LCK: 40, PER: 55, ACC: 60, DEF: 35, ATK: 40, SPD: 62,
      HP: 240, MP: 280, SP: 260,
    },
    startingSkills: ['mimicry', 'sole_conqueror_stigma', 'identity_copy'],
    personality: 'bubbly',
    affinity: 25,
  },

  // ---- ANTAGONISTS ----
  kim_dokja_dokkaebi: {
    id: 'bihyung',
    name: 'Bihyung',
    nameKR: '비형',
    title: 'Dokkaebi',
    role: 'npc_neutral',
    portrait: '👺',
    description: 'The Dokkaebi (goblin-like entity) assigned to Kim Dokja\'s scenario group. Acts as the narrator and rule enforcer for scenarios.',
    class: 'Dokkaebi',
    faction: 'Dokkaebi',
    stats: {
      STR: 30, AGI: 80, END: 50, INT: 85,
      LCK: 60, PER: 90, ACC: 70, DEF: 40, ATK: 45, SPD: 100,
      HP: 350, MP: 600, SP: 300,
    },
    isQuestGiver: true,
    dialogueTree: 'bihyung_main',
  },
};

// Faction data
const FactionData = {
  kim_dokja_company: {
    id: 'kim_dokja_company',
    name: "Kim Dokja's Company",
    members: ['kim_dokja', 'lee_hyunsung', 'jung_heewon', 'lee_jihye', 'shin_yoosung', 'lee_gilyoung'],
    description: 'The core group of survivors led by Kim Dokja',
    perks: ['shared_exp_bonus', 'morale_buff', 'companion_synergy'],
  },
  regressors_group: {
    id: 'regressors_group',
    name: "Regressor's Group",
    members: ['yoo_jonghyuk'],
    description: 'Yoo Jonghyuk and those he chose to bring along',
    perks: ['combat_experience', 'scenario_foreknowledge'],
  },
  constellations: {
    id: 'constellations',
    name: 'Constellations',
    members: [],
    description: 'Transcendent beings who watch the scenarios',
    perks: ['divine_favor', 'nebula_coins'],
  },
  dokkaebi: {
    id: 'dokkaebi',
    name: 'Dokkaebi',
    members: ['bihyung'],
    description: 'Scenario administrators',
    perks: [],
  },
};

if (typeof window !== 'undefined') {
  window.CharactersData = CharactersData;
  window.FactionData = FactionData;
}
