// ORV Game - Data Tables
// Drop tables, probability helpers, reward templates, loot tiers

const TablesData = (function() {
    // Rarity weights for random loot rolls
    const RARITY_WEIGHTS = {
        common: 60, uncommon: 25, rare: 10, epic: 4, legendary: 0.9, mythic: 0.1
    };

    function rollRarity(luckMod) {
        const luck = luckMod || 0;
        const w = { ...RARITY_WEIGHTS };
        if (luck > 0) {
            w.common = Math.max(30, w.common - luck * 2);
            w.uncommon += luck * 0.5;
            w.rare += luck * 0.3;
            w.epic += luck * 0.15;
            w.legendary += luck * 0.04;
            w.mythic += luck * 0.01;
        }
        const total = Object.values(w).reduce((a, b) => a + b, 0);
        let roll = Math.random() * total;
        for (const [rarity, weight] of Object.entries(w)) {
            roll -= weight;
            if (roll <= 0) return rarity;
        }
        return 'common';
    }

    function rollDrop(dropTable, luckMod) {
        const drops = [];
        dropTable.forEach(entry => {
            const chance = Math.min(100, entry.chance + (luckMod || 0) * 0.5);
            if (Math.random() * 100 < chance) {
                const qty = entry.min === entry.max ? entry.min :
                    entry.min + Math.floor(Math.random() * (entry.max - entry.min + 1));
                drops.push({ itemId: entry.itemId, quantity: qty });
            }
        });
        return drops;
    }

    // Scenario reward templates
    const SCENARIO_REWARDS = {
        tutorial: { exp: 100, gold: 50, coins: 5 },
        easy: { exp: 300, gold: 150, coins: 10 },
        medium: { exp: 800, gold: 400, coins: 25 },
        hard: { exp: 2000, gold: 1000, coins: 50 },
        very_hard: { exp: 5000, gold: 2500, coins: 100 },
        extreme: { exp: 12000, gold: 6000, coins: 200 },
        endgame: { exp: 30000, gold: 15000, coins: 500 }
    };

    function getScenarioRewards(difficulty) {
        return { ...SCENARIO_REWARDS[difficulty] || SCENARIO_REWARDS.medium };
    }

    // Enemy EXP table by grade
    const EXP_BY_GRADE = {
        'F': 10, 'E': 25, 'D': 60, 'C': 150, 'B': 400, 'A': 1000, 'S': 3000, 'SS': 10000
    };

    function getEnemyExp(grade, level) {
        const base = EXP_BY_GRADE[grade] || 20;
        return Math.floor(base * (1 + (level || 1) * 0.1));
    }

    // Dokkaebi Coin cost table
    const SHOP_PRICES = {
        small_hp_potion: { coins: 1, gold: 100 },
        medium_hp_potion: { coins: 3, gold: 300 },
        large_hp_potion: { coins: 8, gold: 800 },
        mana_potion: { coins: 2, gold: 200 },
        skill_reset_tome: { coins: 50 },
        stat_boost_scroll: { coins: 20 },
        constellation_offering: { coins: 10 },
    };

    function getPrice(itemId, currency) {
        const p = SHOP_PRICES[itemId];
        if (!p) return null;
        return currency === 'coins' ? p.coins : p.gold;
    }

    return { rollRarity, rollDrop, getScenarioRewards, getEnemyExp, getPrice, RARITY_WEIGHTS };
})();

// Extend data systems with helper methods if not already present
if (typeof DialoguesData !== 'undefined') {
    const _tempTrees = {};
    DialoguesData.registerTemp = function(id, tree) { _tempTrees[id] = tree; };
    const _origGetTree = DialoguesData.getTree;
    DialoguesData.getTree = function(id) {
        return _tempTrees[id] || (_origGetTree ? _origGetTree.call(DialoguesData, id) : null);
    };
}
