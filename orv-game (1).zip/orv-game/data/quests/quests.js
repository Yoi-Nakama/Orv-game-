// ============================================
// QUESTS DATA - ORV
// ============================================
'use strict';

const QuestsData = {

  // ========== MAIN QUESTS (follow scenario arc) ==========
  mq_01_reader_awakens: {
    id: 'mq_01_reader_awakens', type: 'main', name: 'The Reader Awakens',
    giver: 'system', location: 'subway_line_2',
    description: 'The scenario has begun. As the only reader who finished "Three Ways to Survive", you know what must be done. Escape the subway — and survive.',
    objectives: [
      { id: 'o1', text: 'Understand the System Interface', type: 'tutorial', done: false },
      { id: 'o2', text: 'Move to the subway exit', type: 'move', target: 'subway_exit', done: false },
      { id: 'o3', text: 'Defeat 3 Subway Trolls', type: 'kill', target: 'subway_troll', progress: 0, total: 3, done: false },
    ],
    rewards: { exp: 200, coins: 50, items: ['small_hp_potion', 'small_hp_potion'] },
    followup: 'mq_02_meet_bihyung',
    unlocks: ['sq_01_save_the_passengers'],
  },

  mq_02_meet_bihyung: {
    id: 'mq_02_meet_bihyung', type: 'main', name: 'The Dokkaebi Appears',
    giver: 'bihyung', location: 'subway_exit_area',
    description: 'The Dokkaebi named Bihyung has appeared to explain the rules of the new world. Listen carefully.',
    objectives: [
      { id: 'o1', text: 'Speak with Bihyung', type: 'dialogue', target: 'bihyung', done: false },
      { id: 'o2', text: 'Complete Bihyung\'s tutorial', type: 'dialogue_complete', done: false },
    ],
    rewards: { exp: 100, dokkaebi_coins: 30 },
    followup: 'mq_03_first_battle',
  },

  mq_03_first_battle: {
    id: 'mq_03_first_battle', type: 'main', name: 'Trial by Combat',
    giver: 'system', location: 'seoul_streets',
    description: 'The streets are dangerous. Prove you can survive in this new world.',
    objectives: [
      { id: 'o1', text: 'Defeat 10 enemies', type: 'kill_any', progress: 0, total: 10, done: false },
      { id: 'o2', text: 'Use a skill in combat', type: 'skill_use', done: false },
      { id: 'o3', text: 'Level up to Level 5', type: 'level', target: 5, done: false },
    ],
    rewards: { exp: 500, coins: 100, items: ['power_strike_book'] },
    followup: 'mq_04_troll_bridge',
  },

  mq_04_troll_bridge: {
    id: 'mq_04_troll_bridge', type: 'main', name: 'Bridge of Trolls',
    giver: 'lee_hyunsung', location: 'han_river_bridge',
    description: 'Lee Hyunsung says the only route south is blocked by the King of Trolls. The bridge must be cleared.',
    objectives: [
      { id: 'o1', text: 'Reach the Han River Bridge', type: 'move', target: 'han_river_bridge', done: false },
      { id: 'o2', text: 'Defeat the King of Trolls', type: 'boss_kill', target: 'king_of_trolls', done: false },
      { id: 'o3', text: 'Escort survivors across the bridge', type: 'escort', done: false },
    ],
    rewards: { exp: 2000, coins: 500, items: ['troll_king_crown'], companionUnlock: 'yoo_jonghyuk' },
    followup: 'mq_05_city_of_survivors',
  },

  // ========== SIDE QUESTS ==========
  sq_01_save_the_passengers: {
    id: 'sq_01_save_the_passengers', type: 'side', name: 'No One Left Behind',
    giver: 'anonymous_passenger', location: 'subway_line_2',
    description: 'There are still passengers trapped in the subway cars. Save them before the trolls reach them.',
    objectives: [
      { id: 'o1', text: 'Save trapped passengers (0/5)', type: 'rescue', target: 'trapped_passenger', progress: 0, total: 5, done: false },
    ],
    timeLimit: 300, // 5 minutes
    rewards: { exp: 300, coins: 80, dokkaebi_coins: 20, constellationFavor: { great_sage: 50 } },
    failText: 'The passengers were not saved in time.',
  },

  sq_02_kims_journal: {
    id: 'sq_02_kims_journal', type: 'side', name: 'The Reader\'s Journal',
    giver: 'kim_dokja', location: 'any',
    description: 'As Kim Dokja, record key events as they match the novel. Update your mental notes.',
    objectives: [
      { id: 'o1', text: 'Witness 5 events matching the novel', type: 'witness_event', progress: 0, total: 5, done: false },
    ],
    rewards: { exp: 500, skills: ['prophecy_of_the_reader_upgrade'] },
    isJournalQuest: true,
  },

  sq_03_find_companions: {
    id: 'sq_03_find_companions', type: 'side', name: 'Finding People',
    giver: 'kim_dokja', location: 'seoul_streets',
    description: 'In the novel, Kim Dokja gathers specific companions. Find them.',
    objectives: [
      { id: 'o1', text: 'Recruit Lee Hyunsung', type: 'recruit', target: 'lee_hyunsung', done: false },
      { id: 'o2', text: 'Recruit Jung Heewon', type: 'recruit', target: 'jung_heewon', done: false },
      { id: 'o3', text: 'Find Lee Gilyoung', type: 'find', target: 'lee_gilyoung', done: false },
    ],
    rewards: { exp: 1500, coins: 300, title: 'Company Commander' },
  },

  sq_04_constellation_offerings: {
    id: 'sq_04_constellation_offerings', type: 'side', name: 'Offerings to the Stars',
    giver: 'bihyung', location: 'any',
    description: 'Constellations are watching. Complete spectacular deeds to earn their favor and coins.',
    objectives: [
      { id: 'o1', text: 'Perform 3 "dramatic" actions in combat', type: 'dramatic_action', progress: 0, total: 3, done: false },
      { id: 'o2', text: 'Earn 100 Dokkaebi Coins', type: 'currency', target: 100, done: false },
    ],
    repeatable: true, repeatCooldown: 86400,
    rewards: { dokkaebi_coins: 50, constellationFavor: { demon_king: 100, bald_general: 50 } },
  },

  sq_05_black_market: {
    id: 'sq_05_black_market', type: 'side', name: 'Underground Network',
    giver: 'unknown_trader', location: 'underground_market',
    description: 'A secretive trader claims to have items that the official Dokkaebi shop doesn\'t carry.',
    objectives: [
      { id: 'o1', text: 'Find the Underground Market', type: 'discover', target: 'underground_market', done: false },
      { id: 'o2', text: 'Trade with the black market (any 1 item)', type: 'trade', done: false },
    ],
    rewards: { exp: 400, unlockShop: 'black_market' },
  },

  sq_06_gilyoungs_pets: {
    id: 'sq_06_gilyoungs_pets', type: 'side', name: 'Lee Gilyoung\'s Bug Army',
    giver: 'lee_gilyoung', location: 'seoul_streets',
    description: 'Lee Gilyoung wants to understand his Bug King ability. Help him practice.',
    objectives: [
      { id: 'o1', text: 'Defeat 20 enemies with Gilyoung\'s abilities', type: 'kill_with_companion', target: 'lee_gilyoung', progress: 0, total: 20, done: false },
      { id: 'o2', text: 'Protect Gilyoung in 2 difficult battles', type: 'protect_companion', target: 'lee_gilyoung', progress: 0, total: 2, done: false },
    ],
    rewards: { exp: 800, companionAffinity: { lee_gilyoung: 50 }, companionSkillUpgrade: { lee_gilyoung: 'insect_command' } },
    requiresCompanion: 'lee_gilyoung',
  },

  sq_07_heewons_past: {
    id: 'sq_07_heewons_past', type: 'side', name: 'Jung Heewon\'s Shadow',
    giver: 'jung_heewon', location: 'mino_soft_building',
    description: 'Jung Heewon wants to return to her old company. Something happened there she won\'t talk about.',
    objectives: [
      { id: 'o1', text: 'Escort Jung Heewon to Mino Soft', type: 'escort', target: 'mino_soft_building', done: false },
      { id: 'o2', text: 'Clear the monsters from the building', type: 'clear_area', target: 'mino_soft_building', done: false },
      { id: 'o3', text: 'Wait for Heewon (watch the cutscene)', type: 'wait', done: false },
    ],
    rewards: { exp: 600, companionAffinity: { jung_heewon: 80 }, companionSkillUpgrade: { jung_heewon: 'critical_strike' } },
    requiresCompanion: 'jung_heewon',
    cutscene: 'heewon_past_reveal',
  },

  sq_08_jonghyuks_trial: {
    id: 'sq_08_jonghyuks_trial', type: 'side', name: 'The Regressor\'s Test',
    giver: 'yoo_jonghyuk', location: 'training_arena',
    description: 'Yoo Jonghyuk will only truly cooperate if Kim Dokja can prove himself. He proposes a sparring match.',
    objectives: [
      { id: 'o1', text: 'Spar with Yoo Jonghyuk', type: 'duel', target: 'yoo_jonghyuk', done: false },
      { id: 'o2', text: 'Survive for 3 minutes', type: 'survive_time', duration: 180, done: false },
    ],
    rewards: { exp: 1000, companionAffinity: { yoo_jonghyuk: 60 } },
    requiresCompanion: 'yoo_jonghyuk',
    specialNote: 'You cannot actually "win" this fight — only survive is required.',
  },

  // ========== CHAIN QUESTS ==========
  cq_01_dokkaebi_favor_chain: {
    id: 'cq_01_dokkaebi_favor_chain', type: 'chain', name: 'Earning Dokkaebi Coins - Chain',
    steps: ['cq_01a', 'cq_01b', 'cq_01c'],
    description: 'A series of tasks that increase your Dokkaebi Coin income.',
  },
  cq_01a: {
    id: 'cq_01a', type: 'chain_step', name: 'First Coins',
    parentChain: 'cq_01_dokkaebi_favor_chain',
    giver: 'bihyung', location: 'any',
    objectives: [{ id: 'o1', text: 'Earn 50 Dokkaebi Coins', type: 'currency_total', target: 50, done: false }],
    rewards: { dokkaebi_coins: 20 }, next: 'cq_01b',
  },
  cq_01b: {
    id: 'cq_01b', type: 'chain_step', name: 'Constellation Entertainer',
    parentChain: 'cq_01_dokkaebi_favor_chain',
    giver: 'bihyung', location: 'any',
    objectives: [{ id: 'o1', text: 'Make a constellation laugh (dramatic action)', type: 'dramatic_action', done: false }],
    rewards: { dokkaebi_coins: 50, constellationFavor: { demon_king: 200 } }, next: 'cq_01c',
  },
  cq_01c: {
    id: 'cq_01c', type: 'chain_step', name: 'The Coin Master',
    parentChain: 'cq_01_dokkaebi_favor_chain',
    giver: 'bihyung', location: 'any',
    objectives: [{ id: 'o1', text: 'Earn 500 Dokkaebi Coins total', type: 'currency_total', target: 500, done: false }],
    rewards: { dokkaebi_coins: 100, title: 'Coin Master', special: 'Unlocks Bihyung\'s special item list' },
  },

  // ========== HIDDEN QUESTS ==========
  hq_01_the_true_protagonist: {
    id: 'hq_01_the_true_protagonist', type: 'hidden', name: '???',
    description: 'A hidden quest that unlocks when you understand the truth about the story.',
    unlockCondition: 'Reach 80 affinity with Yoo Jonghyuk + complete Regression Paradox (save ending)',
    objectives: [
      { id: 'o1', text: '???', type: 'hidden', done: false },
    ],
    rewards: { skills: ['three_ways_to_survive'], title: 'True Protagonist', exp: 99999 },
  },
};

if (typeof window !== 'undefined') window.QuestsData = QuestsData;
