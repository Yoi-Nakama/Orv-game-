// ============================================
// ITEMS DATA - ORV
// ============================================
'use strict';

const ItemsData = {

  // ========== STARTING / COMMON ITEMS ==========
  smartphone: {
    id: 'smartphone', name: 'Smartphone', icon: '📱', rarity: 'common',
    type: 'quest', stackable: false, description: 'Kim Dokja\'s smartphone with "Three Ways to Survive" saved. Contains all the knowledge of the novel.',
    cannotDrop: true, cannotSell: true,
    special: 'Allows accessing story notes from the novel for hints',
  },
  subway_card: {
    id: 'subway_card', name: 'Subway Card', icon: '🎫', rarity: 'common',
    type: 'key', stackable: false, description: 'A transit card for the Seoul subway. Might open locked gates.',
    effect: 'Opens early subway barriers', sellPrice: 1,
  },
  salary_mans_lunch: {
    id: 'salary_mans_lunch', name: 'Salary Man\'s Lunch', icon: '🍱', rarity: 'common',
    type: 'consumable', stackable: true, maxStack: 10, description: 'A pre-packed lunch from before the scenario.',
    effect: 'Restores 30 HP', sellPrice: 2,
    useEffect: { hp: 30 },
  },
  small_hp_potion: {
    id: 'small_hp_potion', name: 'Small HP Potion', icon: '🧪', rarity: 'common',
    type: 'consumable', stackable: true, maxStack: 20, description: 'A basic healing potion.',
    effect: 'Restores 60 HP', sellPrice: 10, buyPrice: 20,
    useEffect: { hp: 60 },
  },
  medium_hp_potion: {
    id: 'medium_hp_potion', name: 'Medium HP Potion', icon: '🔴', rarity: 'uncommon',
    type: 'consumable', stackable: true, maxStack: 20, description: 'A stronger healing potion.',
    effect: 'Restores 200 HP', sellPrice: 50, buyPrice: 100,
    useEffect: { hp: 200 },
  },
  large_hp_potion: {
    id: 'large_hp_potion', name: 'Large HP Potion', icon: '❤', rarity: 'rare',
    type: 'consumable', stackable: true, maxStack: 10, description: 'Fully restores HP.',
    effect: 'Fully restores HP', sellPrice: 200, buyPrice: 500,
    useEffect: { hp: 9999 },
  },
  mana_potion: {
    id: 'mana_potion', name: 'Mana Potion', icon: '💙', rarity: 'common',
    type: 'consumable', stackable: true, maxStack: 20, description: 'Restores MP.',
    effect: 'Restores 80 MP', sellPrice: 15, buyPrice: 30,
    useEffect: { mp: 80 },
  },
  dokkaebi_coin: {
    id: 'dokkaebi_coin', name: 'Dokkaebi Coin', icon: '🪙', rarity: 'special',
    type: 'currency', stackable: true, maxStack: 99999, description: 'The currency used in the scenario system. Used to purchase items, skills, and blessings from Dokkaebi.',
    cannotSell: true,
  },
  constellation_fragment: {
    id: 'constellation_fragment', name: 'Constellation Fragment', icon: '⭐', rarity: 'epic',
    type: 'special', stackable: true, maxStack: 100, description: 'A shard of power from a constellation. Can be used to increase constellation favor or craft constellation-tier items.',
    sellPrice: 1000,
  },

  // ========== WEAPONS ==========
  iron_dagger: {
    id: 'iron_dagger', name: 'Iron Dagger', icon: '🗡', rarity: 'common',
    type: 'weapon', subtype: 'dagger', stackable: false, description: 'A basic iron dagger. Nothing fancy.',
    stats: { ATK: 12, SPD: 5, ACC: 3 }, sellPrice: 20, buyPrice: 80,
    requirements: { STR: 8 },
  },
  steel_sword: {
    id: 'steel_sword', name: 'Steel Sword', icon: '⚔', rarity: 'uncommon',
    type: 'weapon', subtype: 'sword', stackable: false, description: 'A well-crafted steel sword. Standard issue for capable fighters.',
    stats: { ATK: 28, STR: 5 }, sellPrice: 80, buyPrice: 300,
    requirements: { STR: 20, level: 5 },
  },
  bone_sword: {
    id: 'bone_sword', name: 'Bone Sword', icon: '🦴', rarity: 'uncommon',
    type: 'weapon', subtype: 'sword', stackable: false, description: 'A sword made from hardened monster bone. Oddly durable.',
    stats: { ATK: 22, PER: 5 }, sellPrice: 60, buyPrice: 200,
    requirements: { STR: 15 },
  },
  troll_king_crown: {
    id: 'troll_king_crown', name: 'Troll King\'s Crown', icon: '👑', rarity: 'rare',
    type: 'armor', subtype: 'helmet', stackable: false, description: 'The crown of the King of Trolls. Grants authority over lesser trolls.',
    stats: { DEF: 20, STR: 10, END: 8 },
    special: 'Lesser trolls will not attack while wearing this crown',
    sellPrice: 500,
  },
  dragon_scale_armor: {
    id: 'dragon_scale_armor', name: 'Dragon Scale Armor', icon: '🛡🐉', rarity: 'epic',
    type: 'armor', subtype: 'body', stackable: false, description: 'Crafted from Fafnir\'s scales. Provides immense protection.',
    stats: { DEF: 80, END: 20, fireResist: 0.5 },
    requirements: { level: 30, END: 50 },
    sellPrice: 5000,
  },
  demon_king_sword: {
    id: 'demon_king_sword', name: 'Demon King\'s Blade', icon: '😈⚔', rarity: 'legendary',
    type: 'weapon', subtype: 'greatsword', stackable: false, description: 'Forged from Asmodeus\'s demonic essence. Burns with hellfire.',
    stats: { ATK: 150, STR: 30, INT: 20, fireATK: 50 },
    special: 'Attacks deal additional fire damage equal to 20% of ATK',
    requirements: { level: 50, STR: 80 },
    sellPrice: 20000,
  },
  three_ways_novel: {
    id: 'three_ways_novel', name: '"Three Ways to Survive in a Ruined World"', icon: '📕', rarity: 'unique',
    type: 'special', stackable: false, description: 'The original web novel. The source of all Kim Dokja\'s knowledge. The only copy that was read to completion.',
    cannotDrop: true, cannotSell: true, cannotEquip: true,
    special: 'Reading specific chapters grants bonus EXP and hints for upcoming scenarios',
    passiveBonus: { INT: 5, PER: 10, LCK: 5 },
  },

  // ========== MATERIALS ==========
  troll_hide: { id: 'troll_hide', name: 'Troll Hide', icon: '🧌🪵', rarity: 'common', type: 'material', stackable: true, maxStack: 99, description: 'Rough hide from a troll. Used in crafting.', sellPrice: 5 },
  dragon_blood: { id: 'dragon_blood', name: 'Dragon Blood', icon: '🩸🐉', rarity: 'rare', type: 'material', stackable: true, maxStack: 20, description: 'A vial of dragon blood. Highly magical.', sellPrice: 800 },
  spirit_essence: { id: 'spirit_essence', name: 'Spirit Essence', icon: '👻✨', rarity: 'uncommon', type: 'material', stackable: true, maxStack: 50, description: 'Crystallized spirit energy.', sellPrice: 80 },
  infernal_ore: { id: 'infernal_ore', name: 'Infernal Ore', icon: '🔥⛏', rarity: 'rare', type: 'material', stackable: true, maxStack: 30, description: 'Ore from the demon realm. Burns with eternal fire.', sellPrice: 600 },

  // ========== BOSS DROPS ==========
  troll_king_core: { id: 'troll_king_core', name: 'Troll King Core', icon: '💎🧌', rarity: 'rare', type: 'special', stackable: true, maxStack: 5, description: 'The condensed essence of the Troll King\'s power. Can be used to craft powerful troll-type equipment or consumed for EXP.', sellPrice: 2000, useEffect: { exp: 1000 } },
  dragon_lord_heart: { id: 'dragon_lord_heart', name: 'Dragon Lord Heart', icon: '💎🐉', rarity: 'legendary', type: 'special', stackable: false, description: 'Fafnir\'s petrified heart. Contains immense dragon power.', sellPrice: 15000 },
  demon_king_horn: { id: 'demon_king_horn', name: 'Demon King Horn', icon: '👿📯', rarity: 'legendary', type: 'special', stackable: false, description: 'One of Asmodeus\'s great horns. Symbol of demon royalty.', sellPrice: 30000 },
  outer_god_eye: { id: 'outer_god_eye', name: 'Outer God\'s Eye', icon: '👁🌀', rarity: 'myth', type: 'special', stackable: false, description: 'The eye of a fragment of an Outer God. Incomprehensible. Gazing into it reveals glimpses of alternate timelines.', cannotSell: true, special: 'Equipping reveals hidden paths and secret areas on the world map' },
};

// Shop inventories
const ShopData = {
  scenario_shop: {
    name: 'Scenario Shop',
    currency: 'dokkaebi_coin',
    items: ['small_hp_potion', 'mana_potion', 'medium_hp_potion', 'iron_dagger', 'steel_sword', 'shield_wall', 'fireball'],
  },
  black_market: {
    name: 'Black Market',
    currency: 'coins',
    items: ['large_hp_potion', 'constellation_fragment', 'bone_sword'],
    unlock: 'Find the trader NPC in underground market',
  },
};

if (typeof window !== 'undefined') {
  window.ItemsData = ItemsData;
  window.ShopData = ShopData;
}

// Getter API
ItemsData.getItem = function(id) {
  return ItemsData[id] || null;
};
